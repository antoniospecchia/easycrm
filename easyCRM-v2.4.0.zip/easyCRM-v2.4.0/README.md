# easyCRM — Simple, Private, Local CRM

**Version 2.4.0** · MIT licence · free to use, personally and commercially

easyCRM is a small contact manager that runs entirely on your own computer.
No cloud, no account, no subscription: your data is a single file (`crm.db`) in the easyCRM folder.

## What it does

- **Contacts** with email, phone, website, company and tags
- **Companies**: contacts are linked to a company; click a company to see its people
- **Tasks** per contact, with due dates (overdue / today / upcoming / completed)
- **Interaction log**: calls, emails, meetings
- **Notes thread** per contact
- **Documents** per contact: web links (Google Docs, Drive…) or **files on your computer**, opened with their usual app
- **Follow-up** 🔔: contacts you haven't been in touch with for 30 days are flagged automatically; **Done** marks them as contacted today
- **Archive** 📦 to keep the list clean
- **Activity at a glance**: each card shows the next task, the last interaction and the latest note
- **Tag window**: click a contact's tags to add, remove or create tags; a tag picker with search keeps them consistent
- **Email from easyCRM**: click an address, or tick many contacts and click **📧 Email** — your mail app opens with them in BCC. easyCRM then offers to record it (interaction, completed task, Last contact today)
- **Bulk actions**: email, tag, archive, flag, add tasks or delete several contacts at once. In the table, click the left strip of a row to tick it, press and slide to tick many, or Shift+click for a range
- **Search and filter** by text, tag, follow-up and archived; the box at the top shows which group you are browsing
- **Grid and table views**
- **CSV import / export**, a **full backup** and **one-click restore**

## Download

Get the latest version from the **Releases** page:

👉 **<https://github.com/antoniospecchia/easyCRM/releases/latest>**

Under **Assets**, click **`easyCRM-v2.4.0.zip`** (the version number changes with each release).

> Use the ZIP from **Releases**, not the green **Code → Download ZIP** button: the Releases ZIP is the tested version, and on Mac/Linux it keeps the start files ready to run.

To be told when a new version comes out: on the GitHub page click **Watch → Custom → Releases** (needs a free GitHub account).

## Installation

You need **Node.js 20 or newer**, the free engine easyCRM runs on. Install the **LTS** version (the one marked "Recommended") from <https://nodejs.org>.

### Windows

1. Install Node.js LTS from <https://nodejs.org>. Keep the default options.
2. Download the easyCRM ZIP (see [Download](#download) above).
3. Right-click the ZIP → **Extract All…** and choose a folder, e.g. `Documents\easyCRM`.
4. Open the extracted folder and double-click **`install.bat`**.
   If Windows shows "Windows protected your PC", click **More info → Run anyway**.
5. When the installation finishes, answer `y` to start easyCRM. Your browser opens at <http://localhost:3000>.

**Every day after that:** double-click **`start-easyCRM.bat`**. Keep the black window open while you use easyCRM; close it to stop.

### macOS

1. Install Node.js LTS from <https://nodejs.org>.
2. Download the easyCRM ZIP (see [Download](#download) above) and double-click it to extract it, e.g. into `Documents`.
3. Open **Terminal**, type `cd ` (with a space), drag the easyCRM folder onto the Terminal window, press Enter, then run:
   ```bash
   ./install.sh
   ```
4. **Every day after that:** double-click **`start-easyCRM.command`**.
   The first time, macOS may block it: right-click the file → **Open** → **Open**.

### Linux

Needs a recent Linux (2024 or newer, e.g. Ubuntu 24.04, Debian 13, Fedora 39+). On older systems the database component does not start; use easyCRM 2.0 there.

```bash
cd easyCRM
./install.sh
./start.sh
```

## Your data

- Everything lives in **`crm.db`** inside the easyCRM folder. **To back up, close easyCRM and copy that file somewhere safe.** (The **💾 Backup** button saves a JSON copy of all your data, which **♻️ Restore** can load back in.)
- easyCRM only listens on your own computer (`127.0.0.1`); other devices on your network cannot open it.
- **To restore a backup file**: click **♻️ Restore** and choose a file made with **💾 Backup**. easyCRM shows what is in it, saves your current data in the `backups` folder, then replaces everything with the backup.
- **Files attached to contacts** stay where they are on your computer; easyCRM only remembers their location. Backups contain that location, not the files themselves — keep your own copies of important documents.
- To start again from empty: close easyCRM, then run `npm run reset` in the folder (it asks you to type `YES`).

### Importing contacts (CSV)

The first row must hold column names. Recognised columns: `Name`, `Email`, `Phone`, `Company`, `Website`, `Notes`, `Tags`. Only `Name` is required. Comma- or semicolon-separated files both work.

```
Name,Email,Phone,Company,Website,Notes,Tags
Jane Doe,jane@example.com,+44 20 1234 5678,ACME Ltd,https://acme.example,Met at expo,"client,vip"
```

## Updating to a new version

Your contacts live in one file, **`crm.db`**. Updating means: unzip the new version into its own folder and copy that file across. Your old folder stays untouched, so it is also your backup.

**Which version do I have?** When easyCRM starts, its window shows a line like `Version: 2.4.0`.

### Windows

1. **Close easyCRM**: close the black easyCRM window.
2. **Download** the new ZIP (see [Download](#download)), right-click it → **Extract All…** → choose `Documents`. This creates a new folder named after the version, e.g. `easyCRM-v2.4.0`. Never extract it into your old folder.
3. **Copy your data**: open your **old** easyCRM folder, copy **`crm.db`** and paste it into the **new** folder.
4. **Install**: in the new folder, double-click **`install.bat`** (new versions may need new components).
5. **Start** with **`start-easyCRM.bat`** from the new folder, and press **Ctrl+F5** in the browser so it loads the new screens.
6. Check your contacts are all there. Keep the old folder for a few weeks, then delete it.

### macOS

1. **Close easyCRM**: in its Terminal window press **Ctrl+C**, then close the window.
2. **Download** the new ZIP and double-click it. This creates a new folder named after the version, e.g. `easyCRM-v2.4.0`. Move it to `Documents` if you like.
3. **Copy your data**: copy **`crm.db`** from the old folder into the new one (hold **Option** while dragging, so it is copied, not moved).
4. **Install**: open Terminal, type `cd ` (with a space), drag the **new** folder onto the window, press Enter, then run `./install.sh`.
5. **Start** with **`start-easyCRM.command`** from the new folder, and press **Cmd+Shift+R** in the browser.
6. Check your contacts are all there. Keep the old folder for a few weeks, then delete it.

### Linux

```bash
# stop easyCRM first (Ctrl+C in its terminal), then:
unzip ~/Downloads/easyCRM-v2.4.0.zip -d ~
cp ~/easyCRM/crm.db ~/easyCRM-v2.4.0/      # adjust the old folder name if needed
cd ~/easyCRM-v2.4.0 && ./install.sh
```

The first time the new version opens your `crm.db`, it adds anything new it needs automatically. Nothing is deleted. Going **back** to an older version afterwards is not supported; use the untouched old folder for that.

## Troubleshooting

| Problem | What to do |
|---|---|
| "Node.js is not installed" | Install Node.js LTS from nodejs.org, then close and reopen the installer. |
| Linux: `GLIBC_2.38 not found` when starting | Your Linux is too old for this version's database component. Upgrade to a 2024+ release (e.g. Ubuntu 24.04), or use easyCRM 2.0. |
| "easyCRM needs Node.js 20 or newer" | Install the current **LTS** version from nodejs.org, then run the installer again. |
| Installation fails with red `gyp` / `sqlite3` errors | Your Node.js is too new or too old for the database component. Install the **LTS** version, delete the `node_modules` folder and run the installer again. |
| My contacts are missing after an update | You probably started the new folder without copying `crm.db` into it. Close easyCRM, copy `crm.db` from the old folder into the new one (replace the empty one), and start again. |
| "Port 3000 is already in use" | easyCRM is probably already running in another window. Close it and start again. |
| The page doesn't open by itself | Open <http://localhost:3000> in your browser. |
| Changes don't show after an upgrade | Hard-refresh the page: `Ctrl+F5` (Windows) or `Cmd+Shift+R` (Mac). |

## Known limitations

- Single user, no login: anyone who can use your computer can open easyCRM.
- Tags cannot contain a comma (commas separate tags).
- All contacts load at once; comfortable up to a few thousand.

## Credits

Created by **Antonio Specchia** — <https://easycrm.me>
Built with Node.js, Express, SQLite and plain JavaScript.

Bug reports and ideas: <https://github.com/antoniospecchia/easyCRM/issues>
