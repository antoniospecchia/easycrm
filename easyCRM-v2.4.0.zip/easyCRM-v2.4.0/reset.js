#!/usr/bin/env node
/**
 * easyCRM reset — deletes the database so easyCRM starts empty next time.
 * Works on Windows, macOS and Linux. Asks for confirmation first.
 */
const fs = require('fs');
const path = require('path');
const readline = require('readline');

const dbPath = path.join(__dirname, 'crm.db');

if (!fs.existsSync(dbPath)) {
    console.log('No database found — easyCRM is already empty.');
    process.exit(0);
}

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
rl.question('⚠️  This will DELETE all your contacts, tasks and notes. Make a backup first!\nType YES to continue: ', (answer) => {
    rl.close();
    if (answer.trim() !== 'YES') {
        console.log('Cancelled. Your data is safe.');
        process.exit(0);
    }
    try {
        fs.unlinkSync(dbPath);
        console.log('✅ Database deleted. Start easyCRM again to begin with an empty CRM.');
    } catch (err) {
        console.error('❌ Could not delete the database. Is easyCRM still running? Close it and try again.');
        process.exit(1);
    }
});
