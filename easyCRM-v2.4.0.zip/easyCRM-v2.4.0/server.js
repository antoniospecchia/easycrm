/**
 * easyCRM Server
 * Version: 2.4.0
 * Date: October 2026
 * License: MIT
 */

const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');
const { execFile, spawn } = require('child_process');

const app = express();
const PORT = process.env.PORT || 3000;
// Listen on this computer only, so nobody else on your network can open your CRM
const HOST = '127.0.0.1';

// Middleware
app.use(express.json({ limit: '50mb' }));   // v2.2: large enough for a full backup file (restore)
app.use(express.text({ type: 'text/csv', limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Initialize SQLite database
const db = new sqlite3.Database(path.join(__dirname, 'crm.db'), (err) => {
    if (err) {
        console.error('Error opening database:', err);
    } else {
        console.log('Connected to SQLite database');
        initializeDatabase();
    }
});

// Initialize database tables
function initializeDatabase() {
    db.serialize(() => {
        // Contacts table with needs_follow_up and archived fields
        db.run(`
            CREATE TABLE IF NOT EXISTS contacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT,
                phone TEXT,
                company TEXT,
                notes TEXT,
                tags TEXT,
                last_contact DATE,
                needs_follow_up INTEGER DEFAULT 0,
                archived INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        
        // Add archived column if it doesn't exist (for existing databases)
        db.run(`ALTER TABLE contacts ADD COLUMN archived INTEGER DEFAULT 0`, (err) => {});

        // Add website column if it doesn't exist (for existing databases)
        db.run(`ALTER TABLE contacts ADD COLUMN website TEXT`, (err) => {});

        // Companies table
        db.run(`
            CREATE TABLE IF NOT EXISTS companies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Add company_id to contacts
        db.run(`ALTER TABLE contacts ADD COLUMN company_id INTEGER REFERENCES companies(id)`, (err) => {});

        // Tasks table
        db.run(`
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                contact_id INTEGER,
                title TEXT NOT NULL,
                description TEXT,
                due_date DATE,
                priority TEXT DEFAULT 'medium',
                status TEXT DEFAULT 'pending',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
            )
        `);

        // Interactions table
        db.run(`
            CREATE TABLE IF NOT EXISTS interactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                contact_id INTEGER,
                type TEXT NOT NULL,
                notes TEXT,
                date DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
            )
        `);

        // Notes table
        db.run(`
            CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                contact_id INTEGER,
                content TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
            )
        `);

        // Documents table (NEW in v7.1.0)
        db.run(`
            CREATE TABLE IF NOT EXISTS documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                contact_id INTEGER,
                title TEXT NOT NULL,
                url TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
            )
        `);

        // v2.2: documents can be a web link ('link') or a file on this computer ('file')
        db.run(`ALTER TABLE documents ADD COLUMN kind TEXT DEFAULT 'link'`, (err) => {});

        console.log('Database tables initialized');
        
        // Run company migration after tables are ready
        migrateCompanyData();
    });
}

// One-time migration: move company text field to companies table + company_id FK
function migrateCompanyData() {
    // Check if any contacts need migration (have company text but no company_id)
    db.all(`SELECT DISTINCT TRIM(company) as company_name FROM contacts WHERE company IS NOT NULL AND TRIM(company) != '' AND company_id IS NULL`, (err, rows) => {
        if (err || !rows || rows.length === 0) return;
        
        console.log(`Migrating ${rows.length} unique company names...`);
        
        // Deduplicate case-insensitively: pick first occurrence as canonical
        const seen = new Map(); // lowercase -> canonical name
        rows.forEach(r => {
            const lower = r.company_name.toLowerCase();
            if (!seen.has(lower)) {
                seen.set(lower, r.company_name);
            }
        });
        
        let done = 0;
        const total = seen.size;
        
        seen.forEach((canonicalName, lowerName) => {
            // Insert company (ignore if already exists from previous partial migration)
            db.run(`INSERT OR IGNORE INTO companies (name) VALUES (?)`, [canonicalName], function(err) {
                // Now get the company id (whether just inserted or already existed)
                db.get(`SELECT id FROM companies WHERE name = ?`, [canonicalName], (err, company) => {
                    if (!company) { done++; return; }
                    // Update all contacts whose trimmed lowercase company matches
                    db.run(`UPDATE contacts SET company_id = ? WHERE LOWER(TRIM(company)) = ? AND company_id IS NULL`,
                        [company.id, lowerName], function() {
                            done++;
                            if (done === total) {
                                console.log(`Company migration complete: ${total} companies created`);
                            }
                        }
                    );
                });
            });
        });
    });
}

// Update follow-up flags based on last contact date
function updateFollowUpFlags() {
    const sql = `
        UPDATE contacts 
        SET needs_follow_up = CASE 
            WHEN last_contact IS NULL OR date(last_contact) < date('now', '-30 days') THEN 1 
            ELSE 0 
        END
    `;
    db.run(sql);
}

// ============ CONTACT ENDPOINTS ============

// Get all contacts
app.get('/api/contacts', (req, res) => {
    updateFollowUpFlags(); // Update flags before returning
    
    const search = req.query.search || '';
    const tag = req.query.tag || '';
    
    let sql = `
        SELECT c.*, co.name as company_name,
            -- Activity summary shown on the contact cards (v2.1)
            (SELECT COUNT(*) FROM tasks t WHERE t.contact_id = c.id AND t.status = 'pending') AS open_tasks,
            (SELECT t.title FROM tasks t WHERE t.contact_id = c.id AND t.status = 'pending'
                ORDER BY t.due_date IS NULL, t.due_date, t.id LIMIT 1) AS next_task_title,
            (SELECT t.due_date FROM tasks t WHERE t.contact_id = c.id AND t.status = 'pending'
                ORDER BY t.due_date IS NULL, t.due_date, t.id LIMIT 1) AS next_task_due,
            (SELECT i.type FROM interactions i WHERE i.contact_id = c.id ORDER BY i.date DESC, i.id DESC LIMIT 1) AS last_interaction_type,
            (SELECT i.date FROM interactions i WHERE i.contact_id = c.id ORDER BY i.date DESC, i.id DESC LIMIT 1) AS last_interaction_date,
            (SELECT substr(i.notes, 1, 200) FROM interactions i WHERE i.contact_id = c.id ORDER BY i.date DESC, i.id DESC LIMIT 1) AS last_interaction_notes,
            (SELECT substr(n.content, 1, 200) FROM notes n WHERE n.contact_id = c.id ORDER BY n.created_at DESC, n.id DESC LIMIT 1) AS latest_note
        FROM contacts c
        LEFT JOIN companies co ON c.company_id = co.id
        WHERE (c.name LIKE ? OR c.email LIKE ? OR co.name LIKE ? OR c.notes LIKE ?)
    `;
    const params = [`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`];
    
    if (tag) {
        sql += ` AND c.tags LIKE ?`;
        params.push(`%${tag}%`);
    }
    
    sql += ` ORDER BY c.created_at DESC`;
    
    db.all(sql, params, (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// Get single contact with all related data
app.get('/api/contacts/:id', (req, res) => {
    const contactId = req.params.id;
    const response = {};
    
    db.get('SELECT c.*, co.name as company_name FROM contacts c LEFT JOIN companies co ON c.company_id = co.id WHERE c.id = ?', [contactId], (err, contact) => {
        if (err || !contact) {
            res.status(404).json({ error: 'Contact not found' });
            return;
        }
        response.contact = contact;
        
        db.all('SELECT * FROM tasks WHERE contact_id = ? ORDER BY due_date', [contactId], (err, tasks) => {
            response.tasks = tasks || [];
            
            db.all('SELECT * FROM interactions WHERE contact_id = ? ORDER BY date DESC', [contactId], (err, interactions) => {
                response.interactions = interactions || [];
                
                db.all('SELECT * FROM notes WHERE contact_id = ? ORDER BY created_at DESC', [contactId], (err, notes) => {
                    response.notes = notes || [];
                    
                    db.all('SELECT * FROM documents WHERE contact_id = ? ORDER BY created_at DESC', [contactId], (err, documents) => {
                        response.documents = (documents || []).map(d =>
                            d.kind === 'file' ? { ...d, exists: fileExists(d.url) } : d);
                        res.json(response);
                    });
                });
            });
        });
    });
});

// Create contact
app.post('/api/contacts', (req, res) => {
    const { name, email, phone, company, website, notes, tags } = req.body;
    const companyName = company ? company.trim() : null;
    
    const insertContact = (companyId) => {
        const sql = `
            INSERT INTO contacts (name, email, phone, company, company_id, website, notes, tags, last_contact)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        `;
        db.run(sql, [name, email, phone, companyName, companyId, website || null, notes, tags], function(err) {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            res.json({ id: this.lastID, message: 'Contact created successfully' });
        });
    };

    if (companyName) {
        // Find or create company
        db.get('SELECT id FROM companies WHERE LOWER(name) = LOWER(?)', [companyName], (err, row) => {
            if (row) {
                insertContact(row.id);
            } else {
                db.run('INSERT INTO companies (name) VALUES (?)', [companyName], function(err) {
                    insertContact(err ? null : this.lastID);
                });
            }
        });
    } else {
        insertContact(null);
    }
});

// Update contact
app.put('/api/contacts/:id', (req, res) => {
    const { name, email, phone, company, website, notes, tags } = req.body;
    const contactId = req.params.id;
    const companyName = company ? company.trim() : null;
    
    const updateContact = (companyId) => {
        const sql = `
            UPDATE contacts 
            SET name = ?, email = ?, phone = ?, company = ?, company_id = ?, website = ?, notes = ?, tags = ?, 
                updated_at = datetime('now')
            WHERE id = ?
        `;
        db.run(sql, [name, email, phone, companyName, companyId, website || null, notes, tags, contactId], function(err) {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            res.json({ message: 'Contact updated successfully' });
        });
    };

    if (companyName) {
        db.get('SELECT id FROM companies WHERE LOWER(name) = LOWER(?)', [companyName], (err, row) => {
            if (row) {
                updateContact(row.id);
            } else {
                db.run('INSERT INTO companies (name) VALUES (?)', [companyName], function(err) {
                    updateContact(err ? null : this.lastID);
                });
            }
        });
    } else {
        updateContact(null);
    }
});

// Delete contact
app.delete('/api/contacts/:id', (req, res) => {
    db.run('DELETE FROM contacts WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Contact deleted successfully' });
    });
});

// Mark contact for follow-up
app.post('/api/contacts/mark-followup/:id', (req, res) => {
    const sql = `UPDATE contacts SET needs_follow_up = 1, last_contact = date('now', '-31 days') WHERE id = ?`;
    
    db.run(sql, [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Contact marked for follow-up' });
    });
});

// Unmark contact follow-up
app.post('/api/contacts/unmark-followup/:id', (req, res) => {
    const sql = `UPDATE contacts SET needs_follow_up = 0, last_contact = datetime('now') WHERE id = ?`;
    
    db.run(sql, [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Follow-up removed' });
    });
});

// Archive contact
app.post('/api/contacts/:id/archive', (req, res) => {
    db.run('UPDATE contacts SET archived = 1 WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Contact archived' });
    });
});

// Unarchive contact
app.post('/api/contacts/:id/unarchive', (req, res) => {
    db.run('UPDATE contacts SET archived = 0 WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Contact unarchived' });
    });
});

// Bulk delete
app.post('/api/contacts/bulk-delete', (req, res) => {
    const { ids } = req.body;
    
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
        res.status(400).json({ error: 'No contact IDs provided' });
        return;
    }
    
    const placeholders = ids.map(() => '?').join(',');
    const sql = `DELETE FROM contacts WHERE id IN (${placeholders})`;
    
    db.run(sql, ids, function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: `${this.changes} contacts deleted successfully` });
    });
});

// Bulk update tags
app.post('/api/contacts/bulk-update-tags', (req, res) => {
    const { ids, tags, action } = req.body;
    
    if (!ids || !Array.isArray(ids)) {
        res.status(400).json({ error: 'No contact IDs provided' });
        return;
    }
    
    const placeholders = ids.map(() => '?').join(',');
    
    if (action === 'replace') {
        const sql = `UPDATE contacts SET tags = ? WHERE id IN (${placeholders})`;
        db.run(sql, [tags, ...ids], function(err) {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            res.json({ message: 'Tags updated' });
        });
    } else if (action === 'remove') {
        const tagsToRemove = tags.split(',').map(t => t.trim().toLowerCase()).filter(Boolean);
        db.all(`SELECT id, tags FROM contacts WHERE id IN (${placeholders})`, ids, (err, rows) => {
            if (err) { res.status(500).json({ error: err.message }); return; }
            let updated = 0;
            rows.forEach(row => {
                const existing = row.tags ? row.tags.split(',').map(t => t.trim()) : [];
                const filtered = existing.filter(t => !tagsToRemove.includes(t.toLowerCase())).join(',');
                db.run('UPDATE contacts SET tags = ? WHERE id = ?', [filtered, row.id], () => {
                    updated++;
                    if (updated === rows.length) {
                        res.json({ message: `Tags removed from ${updated} contacts` });
                    }
                });
            });
        });
    } else {
        // Add tags to existing ones
        db.all(`SELECT id, tags FROM contacts WHERE id IN (${placeholders})`, ids, (err, rows) => {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            const newTags = tags.split(',').map(t => t.trim()).filter(Boolean);
            let updated = 0;
            rows.forEach(row => {
                const existing = row.tags ? row.tags.split(',').map(t => t.trim()) : [];
                const merged = [...new Set([...existing, ...newTags])].join(',');
                db.run('UPDATE contacts SET tags = ? WHERE id = ?', [merged, row.id], () => {
                    updated++;
                    if (updated === rows.length) {
                        res.json({ message: `Tags added to ${updated} contacts` });
                    }
                });
            });
        });
    }
});

// Bulk archive
app.post('/api/contacts/bulk-archive', (req, res) => {
    const { ids } = req.body;
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
        res.status(400).json({ error: 'No contact IDs provided' });
        return;
    }
    const placeholders = ids.map(() => '?').join(',');
    db.run(`UPDATE contacts SET archived = 1 WHERE id IN (${placeholders})`, ids, function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: `${this.changes} contacts archived` });
    });
});

// Bulk toggle follow-up
app.post('/api/contacts/bulk-followup', (req, res) => {
    const { ids, action } = req.body;
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
        res.status(400).json({ error: 'No contact IDs provided' });
        return;
    }
    const placeholders = ids.map(() => '?').join(',');
    const value = action === 'unmark' ? 0 : 1;
    const lastContact = action === 'unmark' ? "datetime('now')" : "date('now', '-31 days')";
    db.run(`UPDATE contacts SET needs_follow_up = ${value}, last_contact = ${lastContact} WHERE id IN (${placeholders})`, ids, function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: `${this.changes} contacts updated` });
    });
});

// Bulk create task
app.post('/api/contacts/bulk-task', (req, res) => {
    const { ids, title, description, due_date, priority } = req.body;
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
        res.status(400).json({ error: 'No contact IDs provided' });
        return;
    }
    let created = 0;
    let errors = 0;
    ids.forEach(id => {
        db.run(`INSERT INTO tasks (contact_id, title, description, due_date, priority, status) VALUES (?, ?, ?, ?, ?, 'pending')`,
            [id, title, description || null, due_date || null, priority || 'medium'],
            (err) => {
                if (err) errors++;
                else created++;
                if (created + errors === ids.length) {
                    res.json({ message: `Task created for ${created} contacts` });
                }
            }
        );
    });
});

// ============ TASK ENDPOINTS ============

// Get all tasks
app.get('/api/tasks', (req, res) => {
    const sql = `
        SELECT t.*, c.name as contact_name 
        FROM tasks t
        LEFT JOIN contacts c ON t.contact_id = c.id
        ORDER BY t.due_date ASC, t.priority DESC
    `;
    
    db.all(sql, [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// Get single task
app.get('/api/tasks/:id', (req, res) => {
    db.get('SELECT * FROM tasks WHERE id = ?', [req.params.id], (err, row) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        if (!row) {
            res.status(404).json({ error: 'Task not found' });
            return;
        }
        res.json(row);
    });
});

// Create task
app.post('/api/tasks', (req, res) => {
    const { contact_id, title, description, due_date, priority } = req.body;
    
    const sql = `
        INSERT INTO tasks (contact_id, title, description, due_date, priority, status)
        VALUES (?, ?, ?, ?, ?, 'pending')
    `;
    
    db.run(sql, [contact_id, title, description, due_date, priority || 'medium'], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ id: this.lastID, message: 'Task created successfully' });
    });
});

// Update task
app.put('/api/tasks/:id', (req, res) => {
    const { title, description, due_date, priority, status } = req.body;
    
    const sql = `
        UPDATE tasks 
        SET title = ?, description = ?, due_date = ?, priority = ?, status = ?
        WHERE id = ?
    `;
    
    db.run(sql, [title, description, due_date, priority, status, req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Task updated successfully' });
    });
});

// Update task status
app.patch('/api/tasks/:id/status', (req, res) => {
    const { status } = req.body;
    
    db.run('UPDATE tasks SET status = ? WHERE id = ?', [status, req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Task status updated' });
    });
});

// Delete task
app.delete('/api/tasks/:id', (req, res) => {
    db.run('DELETE FROM tasks WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Task deleted successfully' });
    });
});

// ============ INTERACTION ENDPOINTS ============

// Add interaction
// v2.4: log the same interaction (e.g. a bulk email) on many contacts at once
app.post('/api/interactions/bulk', (req, res) => {
    const { ids, type, notes } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) return res.status(400).json({ error: 'No contacts given' });
    let failed = null;
    db.serialize(() => {
        db.run('BEGIN TRANSACTION');
        const ins = db.prepare('INSERT INTO interactions (contact_id, type, notes) VALUES (?, ?, ?)');
        const upd = db.prepare("UPDATE contacts SET last_contact = datetime('now'), needs_follow_up = 0 WHERE id = ?");
        // optional: also add a task already marked as done (shows under Tasks → Completed)
        const task = req.body.doneTask ? db.prepare("INSERT INTO tasks (contact_id, title, due_date, priority, status) VALUES (?, ?, date('now'), 'medium', 'completed')") : null;
        ids.forEach(id => {
            ins.run([id, type || 'email', notes || ''], e => { if (e) failed = e; });
            upd.run([id], e => { if (e) failed = e; });
            if (task) task.run([id, String(req.body.doneTask)], e => { if (e) failed = e; });
        });
        ins.finalize(); upd.finalize(); if (task) task.finalize();
        db.get('SELECT 1', () => {
            if (failed) return db.run('ROLLBACK', () => res.status(500).json({ error: failed.message }));
            db.run('COMMIT', e => e ? res.status(500).json({ error: e.message }) : res.json({ logged: ids.length }));
        });
    });
});

app.post('/api/interactions', (req, res) => {
    const { contact_id, type, notes } = req.body;
    
    const sql = `INSERT INTO interactions (contact_id, type, notes) VALUES (?, ?, ?)`;
    
    db.run(sql, [contact_id, type, notes], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        // Update last contact date
        db.run('UPDATE contacts SET last_contact = datetime("now") WHERE id = ?', [contact_id]);
        
        res.json({ id: this.lastID, message: 'Interaction logged successfully' });
    });
});

// Update interaction
app.put('/api/interactions/:id', (req, res) => {
    const { type, notes } = req.body;
    
    db.run('UPDATE interactions SET type = ?, notes = ? WHERE id = ?', 
        [type, notes, req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Interaction updated' });
    });
});

// Delete interaction
app.delete('/api/interactions/:id', (req, res) => {
    db.run('DELETE FROM interactions WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Interaction deleted' });
    });
});

// ============ NOTE ENDPOINTS ============

// Add note
app.post('/api/notes', (req, res) => {
    const { contact_id, content } = req.body;
    
    db.run('INSERT INTO notes (contact_id, content) VALUES (?, ?)', 
        [contact_id, content], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ id: this.lastID, message: 'Note added' });
    });
});

// Update note
app.put('/api/notes/:id', (req, res) => {
    const { content } = req.body;
    
    db.run('UPDATE notes SET content = ? WHERE id = ?', [content, req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Note updated' });
    });
});

// Delete note
app.delete('/api/notes/:id', (req, res) => {
    db.run('DELETE FROM notes WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Note deleted' });
    });
});

// ============ DOCUMENT ENDPOINTS ============

// Add document
app.post('/api/documents', (req, res) => {
    const { contact_id, title, url } = req.body;
    const kind = req.body.kind === 'file' ? 'file' : 'link';
    const problem = kind === 'file' ? checkLocalPath(url) : null;
    if (problem) return res.status(400).json({ error: problem });
    
    db.run('INSERT INTO documents (contact_id, title, url, kind) VALUES (?, ?, ?, ?)', 
        [contact_id, title, kind === 'file' ? normalisePath(url) : url, kind], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ id: this.lastID, message: 'Document added' });
    });
});

// Update document
app.put('/api/documents/:id', (req, res) => {
    const { title, url } = req.body;
    const kind = req.body.kind === 'file' ? 'file' : 'link';
    const problem = kind === 'file' ? checkLocalPath(url) : null;
    if (problem) return res.status(400).json({ error: problem });
    
    db.run('UPDATE documents SET title = ?, url = ?, kind = ? WHERE id = ?',
        [title, kind === 'file' ? normalisePath(url) : url, kind, req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Document updated' });
    });
});

// Delete document
app.delete('/api/documents/:id', (req, res) => {
    db.run('DELETE FROM documents WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Document deleted' });
    });
});


// ============ LOCAL FILES (v2.2) ============
// A "file" document stores the location of a file on this computer. Browsers may not open
// local files from a web page, so easyCRM's server opens them with the computer's own default app.
// Only files attached to a contact can be opened (by document id), never an arbitrary path.

// Pasted paths often come wrapped in quotes ("Copy as path" on Windows) or as file:// URLs
function normalisePath(p) {
    let v = String(p || '').trim().replace(/^["']|["']$/g, '');
    if (/^file:\/\//i.test(v)) {
        try { v = decodeURIComponent(new URL(v).pathname); if (process.platform === 'win32') v = v.replace(/^\/([A-Za-z]:)/, '$1'); } catch (e) {}
    }
    if (v.startsWith('~')) v = path.join(require('os').homedir(), v.slice(1));
    return v;
}

function fileExists(p) {
    try { return fs.statSync(normalisePath(p)).isFile(); } catch (e) { return false; }
}

function checkLocalPath(p) {
    const v = normalisePath(p);
    if (!v) return 'Please choose a file.';
    if (!path.isAbsolute(v)) return 'Please give the full location of the file (e.g. /Users/you/Documents/letter.pdf or C:\\Users\\you\\Documents\\letter.pdf).';
    if (!fileExists(v)) return 'No file found at that location. Check that it exists and was not moved or renamed.';
    return null;
}

// Requests that open things on the computer must come from easyCRM's own page:
// a custom header cannot be sent by other websites without permission (which easyCRM never gives).
function fromEasyCRM(req, res) {
    if (req.get('X-EasyCRM') !== '1') { res.status(403).json({ error: 'Not allowed' }); return false; }
    return true;
}

function openWithSystem(file, reveal) {
    return new Promise((resolve, reject) => {
        let cmd, args;
        if (process.platform === 'darwin') { cmd = 'open'; args = reveal ? ['-R', file] : [file]; }
        else if (process.platform === 'win32') { cmd = 'explorer.exe'; args = reveal ? ['/select,' + file] : [file]; }
        else { cmd = 'xdg-open'; args = [reveal ? path.dirname(file) : file]; }
        const child = spawn(cmd, args, { detached: true, stdio: 'ignore' });
        child.on('error', reject);              // e.g. command not available: report it, don't crash
        child.on('spawn', () => { child.unref(); resolve(); });
    });
}

function openDocument(req, res, reveal) {
    if (!fromEasyCRM(req, res)) return;
    db.get('SELECT * FROM documents WHERE id = ?', [req.params.id], (err, doc) => {
        if (err) return res.status(500).json({ error: err.message });
        if (!doc || doc.kind !== 'file') return res.status(404).json({ error: 'Document not found' });
        const file = normalisePath(doc.url);
        if (!fileExists(file)) return res.status(404).json({ error: 'File not found — it may have been moved, renamed or deleted.', missing: true });
        openWithSystem(file, reveal)
            .then(() => res.json({ ok: true }))
            .catch(e => res.status(500).json({ error: 'Could not open the file: ' + e.message }));
    });
}
app.post('/api/documents/:id/open', (req, res) => openDocument(req, res, false));
app.post('/api/documents/:id/reveal', (req, res) => openDocument(req, res, true));

// "Browse…": show the computer's own file-picker window and return the chosen location
app.post('/api/pick-file', (req, res) => {
    if (!fromEasyCRM(req, res)) return;
    const done = (err, out) => {
        const file = String(out || '').trim();
        if (err || !file) return res.json({ cancelled: true });
        res.json({ path: file, name: path.basename(file) });
    };
    const opts = { timeout: 10 * 60 * 1000, maxBuffer: 1024 * 1024 };
    if (process.platform === 'darwin') {
        // plain osascript: no extra macOS permission prompt needed
        execFile('osascript', ['-e', 'POSIX path of (choose file with prompt "Choose a document for easyCRM")'], opts, done);
    } else if (process.platform === 'win32') {
        const ps = [
            'Add-Type -AssemblyName System.Windows.Forms;',
            '[Console]::OutputEncoding = [System.Text.Encoding]::UTF8;',
            '$owner = New-Object System.Windows.Forms.Form -Property @{TopMost = $true};',
            '$d = New-Object System.Windows.Forms.OpenFileDialog;',
            '$d.Title = "Choose a document for easyCRM";',
            'if ($d.ShowDialog($owner) -eq [System.Windows.Forms.DialogResult]::OK) { Write-Output $d.FileName }'
        ].join(' ');
        execFile('powershell.exe', ['-NoProfile', '-STA', '-Command', ps], opts, done);
    } else {
        execFile('zenity', ['--file-selection', '--title=Choose a document for easyCRM'], opts, (err, out) => {
            if (err && err.code === 'ENOENT') return res.status(501).json({ error: 'No file picker available on this system — paste the file location instead.' });
            done(err, out);
        });
    }
});

// ============ COMPANY ENDPOINTS ============

// Get all companies (for autocomplete)
// ============ TAG MANAGEMENT (v2.1) ============
// Tags live in contacts.tags as a comma-separated list. These endpoints rewrite that list
// on EVERY contact (archived included), matching tag names case-insensitively.
function rewriteTags(transform, res) {
    db.all("SELECT id, tags FROM contacts WHERE tags IS NOT NULL AND tags != ''", (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        const updates = [];
        rows.forEach(row => {
            const before = row.tags.split(',').map(t => t.trim()).filter(Boolean);
            const after = [];
            transform(before).forEach(t => {
                if (!after.some(x => x.toLowerCase() === t.toLowerCase())) after.push(t);
            });
            if (after.join(',') !== before.join(',')) updates.push([after.join(','), row.id]);
        });
        if (updates.length === 0) return res.json({ changed: 0 });
        db.serialize(() => {
            db.run('BEGIN TRANSACTION');
            const stmt = db.prepare('UPDATE contacts SET tags = ? WHERE id = ?');
            updates.forEach(u => stmt.run(u));
            stmt.finalize();
            db.run('COMMIT', (e) => {
                if (e) return res.status(500).json({ error: e.message });
                res.json({ changed: updates.length });
            });
        });
    });
}

// Rename or merge: every tag in `from` becomes `to`
app.post('/api/tags/rename', (req, res) => {
    const from = (Array.isArray(req.body.from) ? req.body.from : [req.body.from]).filter(Boolean).map(t => String(t).trim().toLowerCase());
    const to = String(req.body.to || '').replace(/,/g, ' ').replace(/\s+/g, ' ').trim();
    if (from.length === 0 || !to) return res.status(400).json({ error: 'Tag name(s) and new name are required' });
    rewriteTags(tags => tags.map(t => from.includes(t.toLowerCase()) ? to : t), res);
});

// Delete tags from all contacts
app.post('/api/tags/delete', (req, res) => {
    const remove = (req.body.tags || []).map(t => String(t).trim().toLowerCase()).filter(Boolean);
    if (remove.length === 0) return res.status(400).json({ error: 'No tags given' });
    rewriteTags(tags => tags.filter(t => !remove.includes(t.toLowerCase())), res);
});

app.get('/api/companies', (req, res) => {
    db.all('SELECT id, name FROM companies ORDER BY name', [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// ============ STATS ENDPOINT ============

app.get('/api/stats', (req, res) => {
    updateFollowUpFlags();
    
    const stats = {};
    
    // Count only active (non-archived) contacts
    db.get('SELECT COUNT(*) as count FROM contacts WHERE archived = 0 OR archived IS NULL', (err, row) => {
        stats.totalContacts = row.count;
        
        db.get('SELECT COUNT(*) as count FROM tasks WHERE status = "pending"', (err, row) => {
            stats.tasksDue = row.count;
            
            // Count only active contacts needing follow-up
            db.get('SELECT COUNT(*) as count FROM contacts WHERE needs_follow_up = 1 AND (archived = 0 OR archived IS NULL)', (err, row) => {
                stats.needsFollowUp = row.count;
                
                // Count archived contacts
                db.get('SELECT COUNT(*) as count FROM contacts WHERE archived = 1', (err, row) => {
                    stats.archivedContacts = row.count;
                    res.json(stats);
                });
            });
        });
    });
});

// ============ IMPORT/EXPORT ENDPOINTS ============

// Export contacts to CSV
app.get('/api/export/contacts', (req, res) => {
    db.all(`SELECT c.name, c.email, c.phone, COALESCE(co.name, c.company) as company, c.notes, c.tags FROM contacts c LEFT JOIN companies co ON c.company_id = co.id ORDER BY c.name`, [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        let csv = 'Name,Email,Phone,Company,Website,Notes,Tags\n';
        rows.forEach(row => {
            csv += `"${row.name || ''}","${row.email || ''}","${row.phone || ''}","${row.company || ''}","${row.website || ''}","${row.notes || ''}","${row.tags || ''}"\n`;
        });
        
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename=contacts.csv');
        res.send(csv);
    });
});

// Import contacts from CSV
app.post('/api/import/contacts', (req, res) => {
    const lines = req.body.split('\n').filter(l => l.trim());
    if (lines.length < 2) {
        return res.status(400).json({ error: 'CSV file is empty or has no data rows.' });
    }

    // Auto-detect delimiter: count semicolons vs commas in header line
    const headerLine = lines[0];
    const delimiter = (headerLine.split(';').length >= headerLine.split(',').length) ? ';' : ',';

    // Parse a single CSV row respecting quoted fields
    function parseRow(line, delim) {
        const result = [];
        let current = '';
        let inQuotes = false;
        for (let i = 0; i < line.length; i++) {
            const ch = line[i];
            if (ch === '"') {
                inQuotes = !inQuotes;
            } else if (ch === delim && !inQuotes) {
                result.push(current.trim());
                current = '';
            } else {
                current += ch;
            }
        }
        result.push(current.trim());
        return result;
    }

    const headers = parseRow(headerLine, delimiter).map(h => h.toLowerCase().trim());

    const nameIdx    = headers.indexOf('name');
    const emailIdx   = headers.indexOf('email');
    const phoneIdx   = headers.indexOf('phone');
    const companyIdx = headers.indexOf('company');
    const websiteIdx = headers.indexOf('website');
    const notesIdx   = headers.indexOf('notes');
    const tagsIdx    = headers.indexOf('tags');

    if (nameIdx === -1) {
        return res.status(400).json({
            error: `Could not find a "Name" column. Headers detected: [${headers.join(', ')}]. Delimiter used: "${delimiter === ';' ? 'semicolon' : 'comma'}".`
        });
    }

    // Collect valid rows, skip blanks and rows without a name
    const rows = [];
    const skipped = [];
    for (let i = 1; i < lines.length; i++) {
        const values = parseRow(lines[i], delimiter);
        // Strip invisible/control characters from each value
        const clean = values.map(v => v.replace(/[\u00AD\u200B-\u200D\uFEFF]/g, '').trim());
        const name = nameIdx >= 0 ? (clean[nameIdx] || '') : '';
        if (!name) {
            skipped.push(i + 1);
            continue;
        }
        const rawCompany = companyIdx >= 0 ? (clean[companyIdx] || '') : '';
        const isUrl = /^https?:\/\//i.test(rawCompany);
        rows.push({
            name,
            email:   emailIdx   >= 0 ? (clean[emailIdx]   || '') : '',
            phone:   phoneIdx   >= 0 ? (clean[phoneIdx]   || '') : '',
            company: isUrl ? '' : rawCompany,
            website: websiteIdx >= 0 ? (clean[websiteIdx] || '') : (isUrl ? rawCompany : ''),
            notes:   notesIdx   >= 0 ? (clean[notesIdx]   || '') : '',
            tags:    tagsIdx    >= 0 ? (clean[tagsIdx]    || '') : ''
        });
    }

    if (rows.length === 0) {
        return res.status(400).json({
            error: 'No importable rows found. Every row is either empty or missing a Name value.',
            skippedRows: skipped
        });
    }

    // Insert rows sequentially to keep accurate counters (no race condition)
    let imported = 0, failed = 0;
    const errors = [];

    function insertRow(index) {
        if (index >= rows.length) {
            // All done — respond
            return res.json({
                imported,
                failed,
                skippedRows: skipped.length,
                delimiter: delimiter === ';' ? 'semicolon' : 'comma',
                ...(errors.length > 0 && { errors })
            });
        }

        const row = rows[index];
        const companyName = row.company || null;

        const doInsert = (companyId) => {
            db.run(
                `INSERT INTO contacts (name, email, phone, company, company_id, website, notes, tags, last_contact)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))`,
                [row.name, row.email, row.phone, companyName, companyId, row.website || null, row.notes, row.tags],
                (err) => {
                    if (err) {
                        failed++;
                        errors.push({ name: row.name, reason: err.message });
                    } else {
                        imported++;
                    }
                    insertRow(index + 1);
                }
            );
        };

        if (companyName) {
            db.get('SELECT id FROM companies WHERE LOWER(name) = LOWER(?)', [companyName], (err, existing) => {
                if (existing) {
                    doInsert(existing.id);
                } else {
                    db.run('INSERT OR IGNORE INTO companies (name) VALUES (?)', [companyName], function(err) {
                        if (err || !this.lastID) {
                            // May have been inserted by a concurrent call — fetch it
                            db.get('SELECT id FROM companies WHERE LOWER(name) = LOWER(?)', [companyName], (err2, row2) => {
                                doInsert(row2 ? row2.id : null);
                            });
                        } else {
                            doInsert(this.lastID);
                        }
                    });
                }
            });
        } else {
            doInsert(null);
        }
    }

    insertRow(0);
});

// Export full backup
app.get('/api/export/backup', (req, res) => {
    const backup = { exportDate: new Date().toISOString() };
    
    db.all('SELECT * FROM contacts', (err, contacts) => {
        backup.contacts = contacts;
        db.all('SELECT * FROM tasks', (err, tasks) => {
            backup.tasks = tasks;
            db.all('SELECT * FROM interactions', (err, interactions) => {
                backup.interactions = interactions;
                db.all('SELECT * FROM notes', (err, notes) => {
                    backup.notes = notes;
                    db.all('SELECT * FROM documents', (err, documents) => {
                        backup.documents = documents;
                        db.all('SELECT * FROM companies', (err2, companies) => {
                        backup.companies = companies || [];   // v2.2: so a backup can be fully restored
                        backup.app = 'easyCRM';
                        
                        res.setHeader('Content-Type', 'application/json');
                        res.setHeader('Content-Disposition', 'attachment; filename=crm-backup.json');
                        res.send(JSON.stringify(backup, null, 2));
                        });
                    });
                });
            });
        });
    });
});


// ============ RESTORE FROM BACKUP (v2.2) ============
// 1) saves a copy of the current database in backups/  2) replaces ALL data with the backup file.
// Everything happens in one transaction: if anything fails, nothing is changed.
const RESTORE_TABLES = ['documents', 'notes', 'interactions', 'tasks', 'contacts', 'companies'];

function validateBackup(b) {
    if (!b || typeof b !== 'object') return 'This is not an easyCRM backup file.';
    if (!Array.isArray(b.contacts)) return 'The file has no contacts list — is it an easyCRM backup (💾 Backup)?';
    for (const k of ['tasks', 'interactions', 'notes']) if (b[k] !== undefined && !Array.isArray(b[k])) return `"${k}" in the file is not a list.`;
    if (b.contacts.some(c => !c || c.id === undefined || !c.name)) return 'Some contacts in the file have no id or name.';
    return null;
}

function tableColumns(table) {
    return new Promise((resolve, reject) =>
        db.all(`PRAGMA table_info(${table})`, (err, rows) => err ? reject(err) : resolve(rows.map(r => r.name))));
}

// Companies: use the list in the file if there is one, otherwise rebuild it from the contacts
function companiesFromBackup(b) {
    if (Array.isArray(b.companies) && b.companies.length) return b.companies;
    const byId = new Map(), byName = new Set();
    b.contacts.forEach(c => {
        const name = (c.company || '').trim();
        if (c.company_id && name && !byId.has(c.company_id) && !byName.has(name.toLowerCase())) {
            byId.set(c.company_id, { id: c.company_id, name });
            byName.add(name.toLowerCase());
        }
    });
    return [...byId.values()];
}

app.post('/api/restore/preview', (req, res) => {
    const problem = validateBackup(req.body);
    if (problem) return res.status(400).json({ error: problem });
    const b = req.body;
    db.get(`SELECT (SELECT COUNT(*) FROM contacts) c, (SELECT COUNT(*) FROM tasks) t, (SELECT COUNT(*) FROM notes) n,
                   (SELECT COUNT(*) FROM interactions) i, (SELECT COUNT(*) FROM documents) d`, (err, cur) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({
            exportDate: b.exportDate || null,
            file: { contacts: b.contacts.length, tasks: (b.tasks || []).length, notes: (b.notes || []).length,
                    interactions: (b.interactions || []).length, documents: (b.documents || []).length },
            current: { contacts: cur.c, tasks: cur.t, notes: cur.n, interactions: cur.i, documents: cur.d }
        });
    });
});

app.post('/api/restore', async (req, res) => {
    const b = req.body;
    const problem = validateBackup(b);
    if (problem) return res.status(400).json({ error: problem });

    // Step 1: safety copy of the current database
    const dir = path.join(__dirname, 'backups');
    try { fs.mkdirSync(dir, { recursive: true }); } catch (e) {}
    const now = new Date();
    const stamp = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0') +
        '_' + String(now.getHours()).padStart(2, '0') + String(now.getMinutes()).padStart(2, '0') + String(now.getSeconds()).padStart(2, '0');
    const safetyFile = path.join(dir, `crm-before-restore-${stamp}.db`);

    db.run('VACUUM INTO ?', [safetyFile], async (err) => {
        if (err) return res.status(500).json({ error: 'Could not save a copy of the current data, so nothing was changed. (' + err.message + ')' });

        // Step 2: replace everything, in one transaction
        let cols;
        try {
            cols = {};
            for (const t of RESTORE_TABLES) cols[t] = await tableColumns(t);
        } catch (e) { return res.status(500).json({ error: e.message }); }

        const data = {
            companies: companiesFromBackup(b), contacts: b.contacts,
            tasks: b.tasks || [], interactions: b.interactions || [], notes: b.notes || [], documents: b.documents || []
        };
        let firstError = null;
        const note = e => { if (e && !firstError) firstError = e; };

        db.serialize(() => {
            db.run('BEGIN TRANSACTION', note);
            RESTORE_TABLES.forEach(t => db.run(`DELETE FROM ${t}`, note));
            db.run("DELETE FROM sqlite_sequence WHERE name IN ('" + RESTORE_TABLES.join("','") + "')", () => {}); // reset ids
            ['companies', 'contacts', 'tasks', 'interactions', 'notes', 'documents'].forEach(t => {
                data[t].forEach(row => {
                    const keys = Object.keys(row).filter(k => cols[t].includes(k));
                    if (!keys.length) return;
                    db.run(`INSERT OR REPLACE INTO ${t} (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`,
                        keys.map(k => row[k]), note);
                });
            });
            db.get('SELECT 1', () => {
                if (firstError) {
                    db.run('ROLLBACK', () => res.status(500).json({ error: 'Restore failed, nothing was changed: ' + firstError.message, safetyCopy: path.basename(safetyFile) }));
                } else {
                    db.run('COMMIT', (e) => {
                        if (e) return db.run('ROLLBACK', () => res.status(500).json({ error: 'Restore failed, nothing was changed: ' + e.message }));
                        res.json({
                            restored: { contacts: data.contacts.length, companies: data.companies.length, tasks: data.tasks.length,
                                        interactions: data.interactions.length, notes: data.notes.length, documents: data.documents.length },
                            safetyCopy: 'backups/' + path.basename(safetyFile)
                        });
                    });
                }
            });
        });
    });
});

// Start server
const server = app.listen(PORT, HOST, () => {
    console.log(`
    🚀 easyCRM Server is running!
    
    Open your browser and navigate to:
    👉 http://localhost:${PORT}
    
    Version: 2.4.0
    
    Press Ctrl+C to stop the server
    `);
});

server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
        console.error(`\n❌ Port ${PORT} is already in use. Is easyCRM already running?\n   Close the other easyCRM window and try again.\n`);
    } else {
        console.error('Server error:', err);
    }
    process.exit(1);
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\nShutting down gracefully...');
    db.close(() => {
        console.log('Database connection closed.');
        process.exit(0);
    });
});
