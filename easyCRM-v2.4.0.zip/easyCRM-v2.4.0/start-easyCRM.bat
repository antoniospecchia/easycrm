@echo off
REM Start easyCRM and open it in your default browser
cd /d "%~dp0"
if not exist node_modules (
    echo easyCRM is not installed yet. Running install.bat first...
    call install.bat
    exit /b
)
echo Starting easyCRM... keep this window open while you use it.
echo Close this window to stop easyCRM.
start "" cmd /c "timeout /t 2 >nul && start http://localhost:3000"
node server.js
pause
