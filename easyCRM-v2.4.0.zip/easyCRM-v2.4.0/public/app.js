/**
 * easyCRM Frontend - Version 2.4.0
 * Added: Document links feature (Google Docs/Drive links per contact)
 * Date: January 7, 2026
 */

const API_URL = '/api'; // same origin as the page, so any port works

// Global state
let currentContacts = [];
let currentContactId = null;
let currentView = 'table'; // Change #6: Default to table view
let selectedContacts = new Set();
let followUpOnly = false;
let archivedOnly = false; // Change #3/#5: Track archived view
let allTags = new Set();
let allCompanies = [];

// Initialize on page load
// Keep the table's column header just below the sticky toolbar (v2.1)
function updateStickyOffset() {
    const bar = document.getElementById('sticky-top');
    if (bar) document.documentElement.style.setProperty('--sticky-offset', bar.offsetHeight + 'px');
}

document.addEventListener('DOMContentLoaded', () => {
    updateStickyOffset();
    window.addEventListener('resize', updateStickyOffset);
    if (window.ResizeObserver) new ResizeObserver(updateStickyOffset).observe(document.getElementById('sticky-top'));
    loadStats();
    updateActiveStat();
    loadContacts();
    loadCompanies();
    
    // Refresh stats every 30 seconds
    setInterval(loadStats, 30000);
});

// Load companies for autocomplete
async function loadCompanies() {
    try {
        const response = await fetch(`${API_URL}/companies`);
        allCompanies = await response.json();
        updateCompanyDatalist();
    } catch (error) {
        console.error('Error loading companies:', error);
    }
}

// Update datalist options
function updateCompanyDatalist() {
    const datalist = document.getElementById('company-options');
    if (!datalist) return;
    datalist.innerHTML = allCompanies.map(c => `<option value="${escapeHtml(c.name)}">`).join('');
}

// Load dashboard statistics
async function loadStats() {
    try {
        const response = await fetch(`${API_URL}/stats`);
        const stats = await response.json();
        
        document.getElementById('stat-contacts').textContent = stats.totalContacts || 0;
        document.getElementById('stat-tasks').textContent = stats.tasksDue || 0;
        document.getElementById('stat-followup').textContent = stats.needsFollowUp || 0;
        document.getElementById('stat-archived').textContent = stats.archivedContacts || 0;
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// Load contacts
async function loadContacts() {
    try {
        const response = await fetch(`${API_URL}/contacts`);
        const contacts = await response.json();
        currentContacts = contacts;

        // Collect all tags
        allTags.clear();
        contacts.forEach(contact => {
            if (contact.tags) {
                contact.tags.split(',').forEach(tag => allTags.add(tag.trim()));
            }
        });

        // Repopulate the tag dropdown (preserves current selection if still valid)
        populateTagFilter(contacts.filter(c => c.archived !== 1));

        // Bug fix: route through searchContacts so the active search term and
        // tag filter survive reloads triggered by add/edit/delete/archive.
        // searchContacts already honors archivedOnly + followUpOnly.
        searchContacts();
    } catch (error) {
        console.error('Error loading contacts:', error);
        showNotification('Error loading contacts', 'error');
    }
}

// Display contacts based on current view
// v2.1: the contacts currently on screen (after search / tag / follow-up / archive filters)
let visibleContacts = [];

function displayContacts(contacts) {
    const container = document.getElementById('contacts-container');
    visibleContacts = contacts || [];
    
    if (currentView === 'table') {
        container.className = '';
        displayTable(contacts);
    } else {
        container.className = 'grid-view';
        displayGrid(contacts);
    }
}

// ===== Date helpers (v2.1) =====
// SQLite gives "YYYY-MM-DD" or "YYYY-MM-DD HH:MM:SS" (UTC). Safari can't parse the space form.
function parseDbDate(value) {
    if (!value) return null;
    const v = String(value).trim();
    const d = /^\d{4}-\d{2}-\d{2}$/.test(v) ? new Date(v + 'T00:00:00') : new Date(v.replace(' ', 'T') + (v.includes(' ') ? 'Z' : ''));
    return isNaN(d) ? null : d;
}

// Whole days between a date and today (positive = in the past)
function daysAgo(value) {
    const d = parseDbDate(value);
    if (!d) return null;
    const a = new Date(); a.setHours(0, 0, 0, 0);
    const b = new Date(d); b.setHours(0, 0, 0, 0);
    return Math.round((a - b) / 86400000);
}

// "today", "yesterday", "12 days ago", "3 months ago"
function relativePast(value) {
    const n = daysAgo(value);
    if (n === null) return 'never';
    if (n <= 0) return 'today';
    if (n === 1) return 'yesterday';
    if (n < 60) return `${n} days ago`;
    if (n < 730) return `${Math.round(n / 30)} months ago`;
    return `${Math.round(n / 365)} years ago`;
}

// "overdue 3 days", "today", "tomorrow", "in 5 days", or a date
function relativeDue(value) {
    const n = daysAgo(value);
    if (n === null) return '';
    if (n > 0) return `overdue ${n} day${n === 1 ? '' : 's'}`;
    if (n === 0) return 'due today';
    if (n === -1) return 'due tomorrow';
    if (n > -14) return `due in ${-n} days`;
    return 'due ' + parseDbDate(value).toLocaleDateString();
}

// Colour class for "last contact": fresh < 14 days, aging < 30, stale otherwise
function freshnessClass(value) {
    const n = daysAgo(value);
    if (n === null || n >= 30) return 'stale';
    if (n >= 14) return 'aging';
    return 'fresh';
}

const INTERACTION_ICONS = { call: '📞', email: '📧', meeting: '🤝', note: '📝', message: '💬' };

// Display contacts in grid view (v2.1: clearer cards with activity summary)
function displayGrid(contacts) {
    const container = document.getElementById('contacts-container');
    
    if (!contacts || contacts.length === 0) {
        container.innerHTML = '<div class="empty-state">No contacts found</div>';
        return;
    }

    // Don't repeat the tag you're filtering by on every card
    const activeTags = new Set(tagFilters.map(t => t.toLowerCase()));
    
    container.innerHTML = contacts.map(contact => {
        const needsFollowUp = contact.needs_follow_up === 1;
        const isArchived = contact.archived === 1;
        const tags = contact.tags ? contact.tags.split(',').map(t => t.trim()).filter(Boolean) : [];
        const shownTags = tags.filter(t => !activeTags.has(t.toLowerCase()));
        const company = contact.company_name || contact.company;

        // Activity block
        const activity = [];
        if (contact.next_task_title) {
            const dueN = daysAgo(contact.next_task_due);
            const dueCls = dueN !== null && dueN > 0 ? 'overdue' : (dueN === 0 ? 'due-today' : '');
            const more = contact.open_tasks > 1 ? ` <span class="more">+${contact.open_tasks - 1} more</span>` : '';
            activity.push(`<div class="act act-task ${dueCls}" title="Next open task">✅ <span class="act-text">${escapeHtml(contact.next_task_title)}${contact.next_task_due ? ` <span class="act-when">· ${relativeDue(contact.next_task_due)}</span>` : ''}${more}</span></div>`);
        }
        if (contact.last_interaction_type) {
            const icon = INTERACTION_ICONS[String(contact.last_interaction_type).toLowerCase()] || '💬';
            const what = contact.last_interaction_notes ? `: ${escapeHtml(contact.last_interaction_notes)}` : '';
            activity.push(`<div class="act act-interaction" title="Last interaction">${icon} <span class="act-text"><strong>${escapeHtml(contact.last_interaction_type)}</strong> ${relativePast(contact.last_interaction_date)}${what}</span></div>`);
        }
        if (contact.latest_note) {
            activity.push(`<div class="act act-note" title="Latest note">📝 <span class="act-text">${escapeHtml(contact.latest_note)}</span></div>`);
        }
        
        return `
            <div class="contact-card ${needsFollowUp ? 'needs-followup' : ''} ${isArchived ? 'is-archived' : ''}" onclick="showContactDetail(${contact.id})">
                <div class="card-head">
                    <div class="card-title">
                        <h3 title="${escapeHtml(contact.name)}">${escapeHtml(contact.name)}</h3>
                        ${company ? `<div class="card-company" onclick="event.stopPropagation()"><span class="company-link" onclick="filterByCompany(${jsArg(company)})">${escapeHtml(company)}</span></div>` : ''}
                    </div>
                    <div class="card-flags">
                        ${needsFollowUp ? '<span class="badge badge-followup" title="Needs follow-up">🔔 Follow up</span>' : ''}
                        ${isArchived ? '<span class="badge badge-archived">📦 Archived</span>' : ''}
                        <input type="checkbox" class="contact-checkbox" 
                            data-id="${contact.id}"
                            ${selectedContacts.has(contact.id) ? 'checked' : ''}
                            title="Select"
                            onclick="event.stopPropagation(); toggleSelection(${contact.id})">
                    </div>
                </div>

                <div class="card-contact" onclick="event.stopPropagation()">
                    ${contact.email ? `<div class="line" title="${escapeHtml(contact.email)}">📧 <a href="mailto:${escapeHtml(contact.email)}" onclick="afterSingleEmail(${contact.id})">${escapeHtml(contact.email)}</a></div>` : ''}
                    ${contact.phone ? `<div class="line">📱 <a href="tel:${escapeHtml(contact.phone)}">${escapeHtml(contact.phone)}</a></div>` : ''}
                </div>

                <div class="card-last ${freshnessClass(contact.last_contact)}" title="${contact.last_contact ? 'Last contact: ' + escapeHtml(parseDbDate(contact.last_contact)?.toLocaleDateString() || '') : ''}">
                    <span class="dot"></span> Last contact: <strong>${relativePast(contact.last_contact)}</strong>
                </div>

                ${activity.length ? `<div class="card-activity">${activity.join('')}</div>` : ''}

                ${shownTags.length ? `
                    <div class="contact-tags tags-cell" onclick="event.stopPropagation(); openTagEditor(${contact.id}, this)" title="Click to manage tags">
                        ${shownTags.map(tag => `<span class="tag">${escapeHtml(tag)}</span>`).join('')}
                    </div>` : ''}

                <div class="card-actions" onclick="event.stopPropagation()">
                    <button onclick="openEditModal(${contact.id})" class="btn-icon" title="Edit">✏️<span>Edit</span></button>
                    <button onclick="quickAddTask(${contact.id})" class="btn-icon" title="Add task">✅<span>Task</span></button>
                    <button onclick="openTagEditor(${contact.id}, this)" class="btn-icon" title="Manage tags">🏷️<span>Tag</span></button>
                    <button onclick="toggleFollowUp(${contact.id})" class="btn-icon ${needsFollowUp ? 'on' : ''}" title="${needsFollowUp ? 'Mark as contacted (clear follow-up)' : 'Mark for follow-up'}">${needsFollowUp ? '✔️<span>Done</span>' : '🔔<span>Follow-up</span>'}</button>
                    <button onclick="archiveContact(${contact.id})" class="btn-icon" title="Archive">📦<span>Archive</span></button>
                </div>
            </div>
        `;
    }).join('');
}

// Display contacts in table view - ENHANCED WITH TAGS
function displayTable(contacts) {
    const container = document.getElementById('contacts-container');
    
    if (!contacts || contacts.length === 0) {
        container.innerHTML = '<div class="empty-state">No contacts found</div>';
        return;
    }
    
    let html = `
        <table class="contacts-table">
            <thead>
                <tr>
                    <th><input type="checkbox" onclick="selectAll(this)"></th>
                    <th>Name</th>
                    <th>Tags</th>
                    <th>Email</th>
                    <th>Company</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
    `;
    
    contacts.forEach(contact => {
        const needsFollowUp = contact.needs_follow_up === 1;

        const tags = contact.tags ? contact.tags.split(',').map(t => t.trim()) : [];
        
        html += `
            <tr onclick="showContactDetail(${contact.id})" style="cursor:pointer;" class="${needsFollowUp ? 'needs-followup' : ''}">
                <td class="select-cell" data-id="${contact.id}" title="Click to select · press and slide to select many · Shift+click for a range"
                    onclick="event.stopPropagation()" onmousedown="selectCellDown(event, ${contact.id})">
                    <input type="checkbox" class="contact-checkbox" tabindex="-1"
                        data-id="${contact.id}"
                        ${selectedContacts.has(contact.id) ? 'checked' : ''}>
                </td>
                <td class="name-cell" title="${escapeHtml(contact.name)}">${escapeHtml(contact.name)}${needsFollowUp ? ' <span class="badge badge-followup" title="Needs follow-up">🔔</span>' : ''}</td>
                <td class="tags-cell" onclick="event.stopPropagation(); openTagEditor(${contact.id}, this)" title="Click to manage tags">
                    ${tags.length ? tags.map(tag => `<span class="tag-small">${escapeHtml(tag)}</span>`).join('') : '<span class="tag-add-hint">＋ add tag</span>'}
                </td>
                <td title="${escapeHtml(contact.email || '')}">${contact.email ? `<a href="mailto:${escapeHtml(contact.email)}" onclick="event.stopPropagation(); afterSingleEmail(${contact.id})">${escapeHtml(contact.email)}</a>` : ''}</td>
                <td onclick="event.stopPropagation()" title="${escapeHtml(contact.company_name || contact.company || '')}">${(contact.company_name || contact.company) ? `<span class="company-link" onclick="filterByCompany(${jsArg(contact.company_name || contact.company)})">${escapeHtml(contact.company_name || contact.company)}</span>` : ''}</td>
                <td onclick="event.stopPropagation()" style="white-space:nowrap;">
                    <button onclick="openEditModal(${contact.id})" class="btn-small" title="Edit">✏️</button>
                    <button onclick="quickAddTask(${contact.id})" class="btn-small" title="Add Task">✅</button>
                    <button onclick="openTagEditor(${contact.id}, this)" class="btn-small" title="Manage tags">🏷️</button>
                    <button onclick="toggleFollowUp(${contact.id})" class="btn-small" title="${needsFollowUp ? 'Unmark' : 'Mark'} Follow-up">${needsFollowUp ? '🔕' : '🔔'}</button>
                    <button onclick="archiveContact(${contact.id})" class="btn-small btn-archive" title="Archive">📦</button>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// Quick add tag
// ===== Choice dialog (v2.1) — clear buttons instead of an OK/Cancel pop-up =====
let choiceResolve = null;
function openChoice({ title, message = '', choices = [] }) {
    return new Promise(resolve => {
        choiceResolve = resolve;
        document.getElementById('choice-title').textContent = title;
        document.getElementById('choice-message').textContent = message;
        document.getElementById('choice-buttons').innerHTML =
            `<button type="button" onclick="closeChoice(null)">Cancel</button>` +
            choices.map(c => `<button type="button" class="${c.cls || ''}" onclick="closeChoice(${jsArg(c.value)})">${escapeHtml(c.label)}</button>`).join('');
        document.getElementById('choice-modal').classList.add('show');
    });
}
function closeChoice(value) {
    document.getElementById('choice-modal').classList.remove('show');
    if (choiceResolve) { const r = choiceResolve; choiceResolve = null; r(value); }
}

// ===== Tag window (v2.4): click a contact's tags to add / remove them in place =====
const tagEditor = { id: null };

function tagsOf(contactId) {
    const c = currentContacts.find(x => x.id === contactId);
    return c && c.tags ? c.tags.split(',').map(t => t.trim()).filter(Boolean) : [];
}

function openTagEditor(contactId, anchor) {
    const c = currentContacts.find(x => x.id === contactId);
    if (!c) return;
    tagEditor.id = contactId;
    const box = document.getElementById('tag-editor');
    document.getElementById('te-name').textContent = c.name;
    document.getElementById('te-input').value = '';
    box.classList.add('open');
    // place it under the clicked area (or above, if there is no room below)
    const r = anchor.getBoundingClientRect();
    const w = 320, h = box.offsetHeight || 260;
    const left = Math.max(8, Math.min(r.left, window.innerWidth - w - 8));
    const top = (r.bottom + h + 8 < window.innerHeight) ? r.bottom + 4 : Math.max(8, r.top - h - 4);
    box.style.left = left + 'px';
    box.style.top = top + 'px';
    renderTagEditor();
    setTimeout(() => document.getElementById('te-input').focus(), 20);
}

function closeTagEditor() {
    document.getElementById('tag-editor').classList.remove('open');
    tagEditor.id = null;
}

function renderTagEditor() {
    const id = tagEditor.id;
    if (id === null) return;
    const current = tagsOf(id);
    document.getElementById('te-current').innerHTML = current.length
        ? current.map(t => `<span class="te-chip">${escapeHtml(t)}
              <button type="button" title="Show all contacts with this tag" onclick="tagEditorFilter(${jsArg(t)})">🔍</button>
              <button type="button" title="Remove this tag" onclick="tagEditorRemove(${jsArg(t)})">×</button></span>`).join('')
        : '<span class="muted">No tags yet</span>';
    const q = document.getElementById('te-input').value.trim().toLowerCase();
    const have = new Set(current.map(t => t.toLowerCase()));
    const options = getTagCatalogue().filter(o => !have.has(o.tag.toLowerCase()) && (!q || o.tag.toLowerCase().includes(q))).slice(0, 8);
    let html = options.map(o => `<button type="button" class="te-option" onclick="tagEditorAdd(${jsArg(o.tag)})">＋ ${escapeHtml(o.tag)} <span class="tp-count">${o.count}</span></button>`).join('');
    const typed = document.getElementById('te-input').value.replace(/,/g, ' ').replace(/\s+/g, ' ').trim();
    if (typed && !getTagCatalogue().some(o => o.tag.toLowerCase() === typed.toLowerCase()) && !have.has(typed.toLowerCase())) {
        html = `<button type="button" class="te-option tp-new" onclick="tagEditorAdd(${jsArg(typed)})">➕ Create “${escapeHtml(typed)}”</button>` + html;
    }
    document.getElementById('te-suggest').innerHTML = html || (q ? '<div class="muted" style="padding:6px">Already has this tag</div>' : '');
}

async function saveContactTags(contactId, tags) {
    const c = currentContacts.find(x => x.id === contactId);
    if (!c) return false;
    const res = await fetch(`${API_URL}/contacts/${contactId}`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...c, company: c.company_name || c.company, tags: tags.join(',') })
    });
    if (!res.ok) { showNotification('Could not save tags', 'error'); return false; }
    c.tags = tags.join(',');
    await loadContacts();
    if (currentContactId === contactId && document.getElementById('contact-detail-modal').classList.contains('show')) showContactDetail(contactId);
    renderTagEditor();
    return true;
}

async function tagEditorAdd(tag) {
    const id = tagEditor.id; if (id === null) return;
    const existing = getTagCatalogue().find(o => o.tag.toLowerCase() === tag.toLowerCase());
    const name = existing ? existing.tag : tag;      // reuse the existing spelling
    const current = tagsOf(id);
    if (current.some(t => t.toLowerCase() === name.toLowerCase())) return;
    document.getElementById('te-input').value = '';
    await saveContactTags(id, [...current, name]);
    document.getElementById('te-input').focus();
}

async function tagEditorRemove(tag) {
    const id = tagEditor.id; if (id === null) return;
    await saveContactTags(id, tagsOf(id).filter(t => t !== tag));
}

function tagEditorFilter(tag) {
    closeTagEditor();
    closeModal('contact-detail-modal');
    filterByTag(tag);
}

function tagEditorKey(e) {
    if (e.key === 'Escape') { closeTagEditor(); return; }
    if (e.key === 'Enter' || e.key === ',') {
        e.preventDefault();
        const typed = e.target.value.replace(/,/g, ' ').replace(/\s+/g, ' ').trim();
        if (typed) tagEditorAdd(typed);
    }
}

document.addEventListener('click', (e) => {
    const box = document.getElementById('tag-editor');
    if (!box || !box.classList.contains('open') || !e.target.isConnected) return;
    if (box.contains(e.target) || e.target.closest('.tags-cell') || e.target.closest('[title="Manage tags"]')) return;
    closeTagEditor();
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeTagEditor(); });

// ===== Tag picker (v2.1) — replaces the plain browser pop-ups =====
// Usage: const tags = await openTagPicker({ title, intro, confirmLabel, options, allowNew });
// Resolves to an array of chosen tags, or null if cancelled.
let tagPickerState = null;

// All known tags with how many contacts use them. Case variants (e.g. "Author"/"author")
// are grouped under the most-used spelling so you pick one consistently.
function getTagCatalogue(contacts = currentContacts) {
    const groups = new Map();
    const split = new Map();   // key -> {active, archived}
    contacts.forEach(c => (c.tags || '').split(',').map(t => t.trim()).filter(Boolean).forEach(t => {
        const key = t.toLowerCase();
        if (!groups.has(key)) { groups.set(key, new Map()); split.set(key, { active: 0, archived: 0 }); }
        const g = groups.get(key); g.set(t, (g.get(t) || 0) + 1);
        split.get(key)[c.archived === 1 ? 'archived' : 'active']++;
    }));
    return [...groups.entries()].map(([key, g]) => {
        const variants = [...g.entries()].sort((a, b) => b[1] - a[1]);
        return { tag: variants[0][0], count: variants.reduce((n, v) => n + v[1], 0), variants: variants.map(v => v[0]),
                 active: split.get(key).active, archived: split.get(key).archived };
    }).sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag));
}

function openTagPicker({ title = 'Add tags', intro = '', confirmLabel = 'Add', options = null, allowNew = true, exclude = [] } = {}) {
    return new Promise(resolve => {
        const excl = new Set(exclude.map(t => t.toLowerCase()));
        tagPickerState = {
            resolve, allowNew,
            options: (options || getTagCatalogue()).filter(o => !excl.has(o.tag.toLowerCase())),
            exclude: excl,
            chosen: []
        };
        document.getElementById('tag-picker-title').textContent = title;
        document.getElementById('tag-picker-intro').textContent = intro;
        document.getElementById('tag-picker-confirm').textContent = confirmLabel;
        const input = document.getElementById('tag-picker-input');
        input.value = '';
        input.placeholder = allowNew ? 'Type to search, or type a new tag and press Enter' : 'Type to search';
        renderTagPicker();
        document.getElementById('tag-picker-modal').classList.add('show');
        setTimeout(() => input.focus(), 50);
    });
}

function closeTagPicker(result) {
    document.getElementById('tag-picker-modal').classList.remove('show');
    if (tagPickerState) { const r = tagPickerState.resolve; tagPickerState = null; r(result); }
}

function confirmTagPicker() {
    if (!tagPickerState) return;
    // Something typed but not yet added? Add it before confirming.
    const typed = document.getElementById('tag-picker-input').value.trim();
    if (typed) tagPickerAddTyped();
    closeTagPicker(tagPickerState && tagPickerState.chosen.length ? tagPickerState.chosen.slice() : null);
}

function tagPickerToggle(tag) {
    const st = tagPickerState; if (!st) return;
    const i = st.chosen.findIndex(t => t.toLowerCase() === tag.toLowerCase());
    if (i >= 0) st.chosen.splice(i, 1); else st.chosen.push(tag);
    renderTagPicker();
}

function tagPickerAddTyped() {
    const st = tagPickerState; if (!st) return;
    const input = document.getElementById('tag-picker-input');
    const typed = input.value.replace(/,/g, ' ').replace(/\s+/g, ' ').trim();
    if (!typed) return;
    // Prefer an existing spelling (case-insensitive), so "author" becomes "Author" if that exists
    const existing = st.options.find(o => o.tag.toLowerCase() === typed.toLowerCase());
    if (!existing && !st.allowNew) { showNotification('Choose one of the listed tags', 'warning'); return; }
    if (st.exclude.has(typed.toLowerCase())) { showNotification('The contact already has this tag', 'warning'); input.value = ''; renderTagPicker(); return; }
    const tag = existing ? existing.tag : typed;
    if (!st.chosen.some(t => t.toLowerCase() === tag.toLowerCase())) st.chosen.push(tag);
    input.value = '';
    renderTagPicker();
}

function renderTagPicker() {
    const st = tagPickerState; if (!st) return;
    const q = document.getElementById('tag-picker-input').value.trim().toLowerCase();
    const chosenLc = new Set(st.chosen.map(t => t.toLowerCase()));

    document.getElementById('tag-picker-chosen').innerHTML = st.chosen.length
        ? st.chosen.map(t => `<span class="tag tag-chosen" onclick="tagPickerToggle(${jsArg(t)})" title="Remove">${escapeHtml(t)} ×</span>`).join('')
        : '<span class="muted">Nothing selected yet</span>';

    const matches = st.options.filter(o => !q || o.tag.toLowerCase().includes(q));
    let html = matches.map(o => `
        <button type="button" class="tp-option ${chosenLc.has(o.tag.toLowerCase()) ? 'selected' : ''}" onclick="tagPickerToggle(${jsArg(o.tag)})"
            title="${o.variants.length > 1 ? 'Also spelled: ' + escapeHtml(o.variants.slice(1).join(', ')) : ''}">
            <span class="tp-check">${chosenLc.has(o.tag.toLowerCase()) ? '✓' : ''}</span>
            <span class="tp-name">${escapeHtml(o.tag)}</span>
            ${o.variants.length > 1 ? '<span class="tp-variants">≈</span>' : ''}
            <span class="tp-count">${o.count}</span>
        </button>`).join('');
    const exact = st.options.some(o => o.tag.toLowerCase() === q);
    if (q && !exact && st.allowNew) {
        html = `<button type="button" class="tp-option tp-new" onclick="tagPickerAddTyped()">➕ Create new tag “${escapeHtml(document.getElementById('tag-picker-input').value.trim())}”</button>` + html;
    }
    document.getElementById('tag-picker-list').innerHTML = html || '<div class="muted" style="padding:10px">No matching tags</div>';
}

function tagPickerKey(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        const input = e.target;
        if (input.value.trim()) tagPickerAddTyped(); else confirmTagPicker();
    } else if (e.key === 'Escape') {
        closeTagPicker(null);
    } else if (e.key === ',') {
        e.preventDefault(); tagPickerAddTyped(); // commas separate tags, so treat as "add"
    }
}

// Merge chosen tags into a contact's tag list (no duplicates, case-insensitive)
function mergeTags(current, added) {
    const out = current.slice();
    added.forEach(t => { if (!out.some(x => x.toLowerCase() === t.toLowerCase())) out.push(t); });
    return out;
}

// "Choose…" button next to the tag fields in the Add / Edit contact forms
async function pickTagsInto(inputId) {
    const input = document.getElementById(inputId);
    const current = input.value.split(',').map(t => t.trim()).filter(Boolean);
    const chosen = await openTagPicker({ title: 'Choose tags', confirmLabel: 'Add to contact', exclude: current });
    if (chosen) input.value = mergeTags(current, chosen).join(', ');
}

async function quickAddTag(contactId) {
    const contact = currentContacts.find(c => c.id === contactId);
    if (!contact) return;
    const currentTags = contact.tags ? contact.tags.split(',').map(t => t.trim()).filter(Boolean) : [];

    const chosen = await openTagPicker({
        title: `Add tags — ${contact.name}`,
        intro: currentTags.length ? 'Current tags: ' + currentTags.join(', ') : 'No tags yet',
        confirmLabel: 'Add tags',
        exclude: currentTags
    });
    if (!chosen) return;

    const updatedTags = mergeTags(currentTags, chosen).join(',');
    
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                ...contact,
                tags: updatedTags
            })
        });
        
        if (response.ok) {
            showNotification(chosen.length > 1 ? 'Tags added' : 'Tag added', 'success');
            loadContacts();
            if (currentContactId === contactId) {
                showContactDetail(contactId);
            }
        }
    } catch (error) {
        showNotification('Error adding tag', 'error');
    }
}

// Delete tag from contact
async function deleteTag(contactId, tagToDelete) {
    const contact = currentContacts.find(c => c.id === contactId);
    if (!contact) return;
    
    const currentTags = contact.tags ? contact.tags.split(',').map(t => t.trim()) : [];
    const updatedTags = currentTags.filter(t => t !== tagToDelete).join(',');
    
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                ...contact,
                tags: updatedTags
            })
        });
        
        if (response.ok) {
            showNotification('Tag removed', 'success');
            loadContacts();
            if (currentContactId === contactId) {
                showContactDetail(contactId);
            }
        }
    } catch (error) {
        showNotification('Error removing tag', 'error');
    }
}

// Filter by tag
function filterByTag(tag) {
    // Clicking a tag chip filters by that one tag (matching regardless of capitalisation)
    const entry = tagCatalogue.find(o => o.tag.toLowerCase() === String(tag).toLowerCase());
    tagFilters = [entry ? entry.tag : tag];
    updateTagFilterButton();
    searchContacts();
}

// Filter by company
function filterByCompany(companyName) {
    document.getElementById('search-input').value = companyName;
    searchContacts();
}

// Switch view between grid and table
function switchView(view) {
    currentView = view;

    // Update button states
    document.getElementById('btn-grid').classList.toggle('active', view === 'grid');
    document.getElementById('btn-table').classList.toggle('active', view === 'table');

    // Re-apply ALL active filters (search, tag, follow-up, archived).
    // Bug fix: previously this only re-applied archived/follow-up, so the
    // selected tag (and search term) were lost when toggling grid/table.
    searchContacts();
}

// Show all contacts (from stat box)
function showAllContacts() {
    followUpOnly = false;
    archivedOnly = false;
    document.getElementById('main-view').style.display = 'flex';
    document.getElementById('tasks-view').style.display = 'none';
    // Clear active search/tag filters so "All" actually shows all.
    document.getElementById('search-input').value = '';
    tagFilters = []; updateTagFilterButton();
    updateActiveStat();
    loadContacts();
}

// Show only follow-up contacts (from stat box)
function showFollowUpContacts() {
    followUpOnly = true;
    archivedOnly = false;
    document.getElementById('main-view').style.display = 'flex';
    document.getElementById('tasks-view').style.display = 'none';
    // v2.1 fix: clear search/tag so the list matches the count on the stat box, and go through
    // searchContacts() so later refreshes (e.g. after removing a follow-up) show the same list.
    document.getElementById('search-input').value = '';
    tagFilters = []; updateTagFilterButton();
    const shown = searchContacts();
    showNotification(`Showing ${shown} contacts needing follow-up`, 'info');
}

// Show archived contacts (from stat box)
function showArchivedContacts() {
    followUpOnly = false;
    archivedOnly = true;
    document.getElementById('main-view').style.display = 'flex';
    document.getElementById('tasks-view').style.display = 'none';
    document.getElementById('search-input').value = '';
    tagFilters = []; updateTagFilterButton();
    const shown = searchContacts();
    showNotification(`Showing ${shown} archived contacts`, 'info');
}

// Archive contact
async function archiveContact(contactId) {
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}/archive`, {
            method: 'POST'
        });
        
        if (response.ok) {
            showNotification('Contact archived', 'success');
            closeModal('contact-detail-modal');
            loadContacts();
            loadStats();
        }
    } catch (error) {
        showNotification('Error archiving contact', 'error');
    }
}

// Unarchive contact
async function unarchiveContact(contactId) {
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}/unarchive`, {
            method: 'POST'
        });
        
        if (response.ok) {
            showNotification('Contact restored', 'success');
            closeModal('contact-detail-modal');
            loadContacts();
            loadStats();
        }
    } catch (error) {
        showNotification('Error restoring contact', 'error');
    }
}

// Show tasks view (from stat box)
function showTasksView() {
    document.getElementById('main-view').style.display = 'none';
    document.getElementById('tasks-view').style.display = 'flex';
    updateActiveStat();
    loadTasks();
}

// Load and display tasks
async function loadTasks() {
    try {
        const response = await fetch(`${API_URL}/tasks`);
        const tasks = await response.json();
        
        const container = document.getElementById('tasks-container');
        
        if (tasks.length === 0) {
            container.innerHTML = '<div class="empty-state">No tasks found</div>';
            return;
        }
        
        // v2.1: compare with today's LOCAL date (toISOString() is UTC, wrong just after midnight)
        const now = new Date();
        const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
        const dueStr = t => String(t.due_date).split('T')[0].split(' ')[0];
        const pending = tasks.filter(t => t.status !== 'completed');
        const byDue = (a, b) => dueStr(a).localeCompare(dueStr(b));
        
        // Groups - Overdue is yesterday or earlier (not today)
        const overdue  = pending.filter(t => t.due_date && dueStr(t) <  todayStr).sort(byDue);
        const today    = pending.filter(t => t.due_date && dueStr(t) === todayStr);
        const upcoming = pending.filter(t => t.due_date && dueStr(t) >  todayStr).sort(byDue);
        const noDate   = pending.filter(t => !t.due_date);   // v2.1: these used to be hidden
        const completed = tasks.filter(t => t.status === 'completed');
        
        const section = (cls, title, list) => list.length
            ? `<h3 class="task-group-title ${cls}">${title} <span class="count">${list.length}</span></h3>` + list.map(t => renderTask(t, cls)).join('')
            : '';
        
        let html = '';
        html += section('overdue', '⚠️ Overdue', overdue);
        html += section('today', '📅 Today', today);
        html += section('upcoming', '📌 Upcoming', upcoming);
        html += section('nodate', '🗒️ No due date', noDate);
        
        if (completed.length > 0) {
            html += `
                <details class="completed-box" ${completedBoxOpen ? 'open' : ''} ontoggle="completedBoxOpen = this.open">
                    <summary>✅ Completed <span class="count">${completed.length}</span></summary>
                    <div class="completed-list">${completed.map(t => renderTask(t, 'completed')).join('')}</div>
                </details>`;
        }
        
        if (!html) html = '<div class="empty-state">No tasks found</div>';
        container.innerHTML = html;
    } catch (error) {
        console.error('Error loading tasks:', error);
    }
}

// Render single task (v2.1: styled by group; completed tasks are compact and faded)
let completedBoxOpen = true;

function renderTask(task, group = '') {
    const dueDate = task.due_date ? parseDbDate(String(task.due_date).split('T')[0].split(' ')[0]) : null;
    const dateText = dueDate ? dueDate.toLocaleDateString() : '';

    if (group === 'completed') {
        return `
        <div class="task-item task-completed" onclick="showContactFromTask(${task.contact_id})">
            <span class="task-check">✓</span>
            <span class="task-title">${escapeHtml(task.title)}</span>
            ${task.contact_name ? `<span class="task-contact">${escapeHtml(task.contact_name)}</span>` : ''}
            <span class="task-date">${dateText}</span>
            <span class="task-actions" onclick="event.stopPropagation()">
                <button onclick="reopenTask(${task.id})" class="btn-icon" title="Reopen">↩️</button>
                <button onclick="openEditTaskModal(${task.id})" class="btn-icon" title="Edit">✏️</button>
                <button onclick="deleteTask(${task.id})" class="btn-icon" title="Delete">🗑️</button>
            </span>
        </div>`;
    }

    const rel = task.due_date ? relativeDue(task.due_date) : '';
    const when = !task.due_date ? 'No due date' : (rel.includes(dateText) ? rel : `${rel} · ${dateText}`);
    return `
        <div class="task-item task-${group || 'upcoming'}" onclick="showContactFromTask(${task.contact_id})">
            <div class="task-main">
                <strong class="task-title">${escapeHtml(task.title)}</strong>
                ${task.contact_name ? `<span class="task-contact">— ${escapeHtml(task.contact_name)}</span>` : ''}
                <div class="task-when">${when}</div>
            </div>
            <div class="task-actions" onclick="event.stopPropagation()">
                <button onclick="completeTask(${task.id})" class="btn-icon btn-done" title="Mark as done">✔️<span>Done</span></button>
                <button onclick="openEditTaskModal(${task.id})" class="btn-icon" title="Edit">✏️<span>Edit</span></button>
                <button onclick="deleteTask(${task.id})" class="btn-icon" title="Delete">🗑️</button>
            </div>
        </div>
    `;
}

// Show contact from task
async function showContactFromTask(contactId) {
    if (!contactId) return;
    showAllContacts();
    setTimeout(() => showContactDetail(contactId), 100);
}

// Show contact detail modal - ENHANCED WITH TAGS
async function showContactDetail(contactId) {
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}`);
        const data = await response.json();
        
        currentContactId = contactId;
        
        const tags = data.contact.tags ? data.contact.tags.split(',').map(t => t.trim()) : [];
        const isArchived = data.contact.archived === 1;
        
        document.getElementById('detail-name').textContent = data.contact.name;
        
        // Display tags in detail view with delete capability
        document.getElementById('detail-tags').innerHTML = tags.length > 0 
            ? tags.map(tag => `<span class="tag-deletable"><span class="tag-text">${escapeHtml(tag)}</span><span class="tag-delete" onclick="deleteTag(${contactId}, ${jsArg(tag)})">×</span></span>`).join('')
            : '<span style="color: #999;">No tags</span>';
        
        document.getElementById('detail-email').innerHTML = data.contact.email 
            ? `<a href="mailto:${escapeHtml(data.contact.email)}" onclick="afterSingleEmail(${data.contact.id})">${escapeHtml(data.contact.email)}</a>` 
            : 'N/A';
        document.getElementById('detail-phone').innerHTML = data.contact.phone 
            ? `<a href="tel:${data.contact.phone}">${data.contact.phone}</a>` 
            : 'N/A';
        const companyDisplay = data.contact.company_name || data.contact.company || '';
        document.getElementById('detail-company').innerHTML = companyDisplay 
            ? `<span class="company-link" onclick="closeModal('contact-detail-modal'); filterByCompany(${jsArg(companyDisplay)})">${escapeHtml(companyDisplay)}</span>`
            : 'N/A';
        document.getElementById('detail-website').innerHTML = data.contact.website
            ? `<a href="${safeUrl(data.contact.website)}" target="_blank" rel="noopener noreferrer">${escapeHtml(data.contact.website)}</a>`
            : 'N/A';
        
        // Update archive button based on contact status
        const archiveBtn = document.getElementById('archive-btn');
        if (isArchived) {
            archiveBtn.textContent = '📤 Unarchive';
            archiveBtn.onclick = () => unarchiveContact(currentContactId);
        } else {
            archiveBtn.textContent = '📦 Archive';
            archiveBtn.onclick = () => archiveContact(currentContactId);
        }
        
        // Display tasks
        const tasksHtml = data.tasks.length > 0 ? data.tasks.map(t => `
            <div class="detail-item">
                <strong>${escapeHtml(t.title)}</strong> - ${t.status}
                <div class="detail-item-actions">
                    <button onclick="openEditTaskModal(${t.id})" class="btn-small">✏️</button>
                </div>
            </div>
        `).join('') : '<p>No tasks</p>';
        document.getElementById('detail-tasks').innerHTML = tasksHtml;
        
        // Display interactions
        const interactionsHtml = data.interactions.length > 0 ? data.interactions.map(i => `
            <div class="detail-item">
                <strong>${i.type}</strong> - ${new Date(i.date).toLocaleDateString()}
                ${i.notes ? `<br>${escapeHtml(i.notes)}` : ''}
                <div class="detail-item-actions">
                    <button onclick="editInteraction(${i.id}, ${jsArg(i.type)}, ${jsArg(i.notes || '')})" class="btn-small">✏️</button>
                    <button onclick="deleteInteraction(${i.id})" class="btn-small btn-danger">🗑️</button>
                </div>
            </div>
        `).join('') : '<p>No interactions</p>';
        document.getElementById('detail-interactions').innerHTML = interactionsHtml;
        
        // Display notes (using new element ID)
        const notesHtml = data.notes.length > 0 ? data.notes.map(n => `
            <div class="detail-item">
                ${escapeHtml(n.content)}
                <div class="detail-item-actions">
                    <button onclick="editNote(${n.id}, ${jsArg(n.content)})" class="btn-small">✏️</button>
                    <button onclick="deleteNote(${n.id})" class="btn-small btn-danger">🗑️</button>
                </div>
            </div>
        `).join('') : '<p>No notes</p>';
        document.getElementById('detail-notes-list').innerHTML = notesHtml;
        
        // Display documents (from API)
        const docs = data.documents || [];
        const documentsHtml = docs.length > 0 ? docs.map(d => `
            <div class="detail-item">
                ${d.kind === 'file'
                    ? `<button type="button" class="doc-file-link" onclick="openLocalDocument(${d.id})" title="Open with its usual app">📁 ${escapeHtml(d.title)}</button>
                       <button type="button" class="btn-icon" onclick="revealLocalDocument(${d.id})" title="Show in Finder / Explorer">📂</button>
                       ${d.exists === false ? '<span class="doc-missing">⚠️ file not found — moved or renamed? Use ✏️ to point to it again</span>' : ''}`
                    : `<a href="${safeUrl(d.url)}" target="_blank" rel="noopener noreferrer">🔗 ${escapeHtml(d.title)}</a>`}
                <small style="color: #999; margin-left: 8px;">${parseDbDate(d.created_at) ? parseDbDate(d.created_at).toLocaleDateString() : ''}</small>
                ${d.kind === 'file' ? `<span class="doc-path">${escapeHtml(d.url)}</span>` : ''}
                <div class="detail-item-actions">
                    <button onclick="openEditDocumentModal(${d.id}, ${jsArg(d.title)}, ${jsArg(d.url)}, ${jsArg(d.kind || 'link')})" class="btn-small">✏️</button>
                    <button onclick="deleteDocument(${d.id})" class="btn-small btn-danger">🗑️</button>
                </div>
            </div>
        `).join('') : '<p>No documents</p>';
        document.getElementById('detail-documents').innerHTML = documentsHtml;
        
        openModal('contact-detail-modal');
    } catch (error) {
        console.error('Error loading contact:', error);
        showNotification('Error loading contact details', 'error');
    }
}

// FIXED: Open edit contact modal (closes detail modal first)
async function openEditModal(contactId) {
    // Close contact detail modal if it's open
    closeModal('contact-detail-modal');
    
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}`);
        const data = await response.json();
        const contact = data.contact;
        
        document.getElementById('edit-id').value = contact.id;
        document.getElementById('edit-name').value = contact.name;
        document.getElementById('edit-email').value = contact.email || '';
        document.getElementById('edit-phone').value = contact.phone || '';
        document.getElementById('edit-company').value = contact.company_name || contact.company || '';
        document.getElementById('edit-website').value = contact.website || '';
        document.getElementById('edit-tags').value = contact.tags || '';
        document.getElementById('edit-notes').value = contact.notes || '';
        
        // Show tag suggestions
        const tagSuggestions = Array.from(allTags).join(', ');
        document.getElementById('tag-suggestions').textContent = tagSuggestions ? `Existing tags: ${tagSuggestions}` : '';
        
        openModal('edit-contact-modal');
    } catch (error) {
        console.error('Error loading contact:', error);
        showNotification('Error loading contact', 'error');
    }
}

// FIXED: Save edited contact (and reopen detail if needed)
async function saveContact() {
    const contactId = document.getElementById('edit-id').value;
    const wasDetailOpen = currentContactId == contactId;
    
    // Get the current contact to compare notes
    const currentContact = currentContacts.find(c => c.id == contactId);
    const oldNotes = currentContact ? currentContact.notes : '';
    const newNotes = document.getElementById('edit-notes').value;
    
    const data = {
        name: document.getElementById('edit-name').value,
        email: document.getElementById('edit-email').value,
        phone: document.getElementById('edit-phone').value,
        company: document.getElementById('edit-company').value,
        website: document.getElementById('edit-website').value,
        tags: document.getElementById('edit-tags').value,
        notes: newNotes
    };
    
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            // If notes changed, also add to notes table
            if (newNotes && newNotes !== oldNotes) {
                await fetch(`${API_URL}/notes`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        contact_id: contactId,
                        content: newNotes
                    })
                });
            }
            
            showNotification('Contact updated successfully', 'success');
            closeModal('edit-contact-modal');
            loadContacts();
            loadStats();
            loadCompanies();
            
            // Reopen contact detail if it was open
            if (wasDetailOpen) {
                setTimeout(() => showContactDetail(contactId), 300);
            }
        }
    } catch (error) {
        showNotification('Error updating contact', 'error');
    }
}

// Add new contact
async function addContact(event) {
    event.preventDefault();
    
    const data = {
        name: document.getElementById('add-name').value,
        email: document.getElementById('add-email').value,
        phone: document.getElementById('add-phone').value,
        company: document.getElementById('add-company').value,
        website: document.getElementById('add-website').value,
        tags: document.getElementById('add-tags').value,
        notes: document.getElementById('add-notes').value
    };
    
    try {
        const response = await fetch(`${API_URL}/contacts`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            const result = await response.json();
            
            // If notes were provided, also add to notes table
            if (data.notes) {
                await fetch(`${API_URL}/notes`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        contact_id: result.id,
                        content: data.notes
                    })
                });
            }
            
            showNotification('Contact added successfully', 'success');
            document.getElementById('add-contact-form').reset();
            closeModal('add-contact-modal');
            loadContacts();
            loadStats();
            loadCompanies();
        }
    } catch (error) {
        showNotification('Error adding contact', 'error');
    }
}

// Delete contact
async function deleteContact(contactId) {
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('Contact deleted', 'success');
            loadContacts();
            loadStats();
        }
    } catch (error) {
        showNotification('Error deleting contact', 'error');
    }
}

// Toggle follow-up status
async function toggleFollowUp(contactId) {
    const contact = currentContacts.find(c => c.id === contactId);
    const endpoint = contact?.needs_follow_up === 1 
        ? `/contacts/unmark-followup/${contactId}`
        : `/contacts/mark-followup/${contactId}`;
    
    try {
        const response = await fetch(`${API_URL}${endpoint}`, {
            method: 'POST'
        });
        
        if (response.ok) {
            showNotification(contact?.needs_follow_up === 1 ? 'Follow-up removed' : 'Marked for follow-up', 'success');
            loadContacts();
            loadStats();
        }
    } catch (error) {
        showNotification('Error updating follow-up status', 'error');
    }
}

// Quick add task - now opens the modal instead of using prompts
function quickAddTask(contactId) {
    document.getElementById('task-contact-id').value = contactId;
    document.getElementById('task-title').value = '';
    document.getElementById('task-description').value = '';
    document.getElementById('task-due-date').value = '';
    document.getElementById('task-priority').value = 'medium';
    openModal('add-task-modal');
}

// Open add task modal
function openAddTaskModal(contactId = null) {
    if (contactId) {
        document.getElementById('task-contact-id').value = contactId;
    }
    openModal('add-task-modal');
}

// Save new task
async function saveTask(event) {
    event.preventDefault();
    
    const data = {
        contact_id: document.getElementById('task-contact-id').value || currentContactId,
        title: document.getElementById('task-title').value,
        description: document.getElementById('task-description').value,
        due_date: document.getElementById('task-due-date').value || null,
        priority: document.getElementById('task-priority').value
    };
    
    try {
        const response = await fetch(`${API_URL}/tasks`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            showNotification('Task added successfully', 'success');
            document.getElementById('add-task-form').reset();
            closeModal('add-task-modal');
            loadStats();
            if (currentContactId) {
                showContactDetail(currentContactId);
            }
        }
    } catch (error) {
        showNotification('Error adding task', 'error');
    }
}

// Open edit task modal
async function openEditTaskModal(taskId) {
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}`);
        const task = await response.json();
        
        document.getElementById('edit-task-id').value = task.id;
        document.getElementById('edit-task-title').value = task.title;
        document.getElementById('edit-task-description').value = task.description || '';
        document.getElementById('edit-task-due-date').value = task.due_date ? task.due_date.split('T')[0] : '';
        document.getElementById('edit-task-priority').value = task.priority;
        document.getElementById('edit-task-status').value = task.status;
        
        openModal('edit-task-modal');
    } catch (error) {
        showNotification('Error loading task', 'error');
    }
}

// Save edited task
async function saveEditedTask(event) {
    event.preventDefault();
    
    const taskId = document.getElementById('edit-task-id').value;
    const data = {
        title: document.getElementById('edit-task-title').value,
        description: document.getElementById('edit-task-description').value,
        due_date: document.getElementById('edit-task-due-date').value || null,
        priority: document.getElementById('edit-task-priority').value,
        status: document.getElementById('edit-task-status').value
    };
    
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            showNotification('Task updated', 'success');
            closeModal('edit-task-modal');
            loadTasks();
            loadStats();
            if (currentContactId) {
                showContactDetail(currentContactId);
            }
        }
    } catch (error) {
        showNotification('Error updating task', 'error');
    }
}

// Complete task
async function completeTask(taskId) {
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}/status`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: 'completed' })
        });
        
        if (response.ok) {
            showNotification('Task completed', 'success');
            loadTasks();
            loadStats();
        }
    } catch (error) {
        showNotification('Error completing task', 'error');
    }
}

// Reopen task
async function reopenTask(taskId) {
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}/status`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: 'pending' })
        });
        
        if (response.ok) {
            showNotification('Task reopened', 'success');
            loadTasks();
            loadStats();
        }
    } catch (error) {
        showNotification('Error reopening task', 'error');
    }
}

// Delete task
async function deleteTask(taskId) {
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('Task deleted', 'success');
            loadTasks();
            loadStats();
        }
    } catch (error) {
        showNotification('Error deleting task', 'error');
    }
}

// Edit interaction
async function editInteraction(id, type, notes) {
    const newType = prompt('Type:', type);
    const newNotes = prompt('Notes:', notes.replace(/\\'/g, "'"));
    
    if (newType === null) return;
    
    try {
        const response = await fetch(`${API_URL}/interactions/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type: newType, notes: newNotes })
        });
        
        if (response.ok) {
            showNotification('Interaction updated', 'success');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error updating interaction', 'error');
    }
}

// Delete interaction
async function deleteInteraction(id) {
    try {
        const response = await fetch(`${API_URL}/interactions/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('Interaction deleted', 'success');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error deleting interaction', 'error');
    }
}

// Edit note
async function editNote(id, content) {
    const newContent = prompt('Edit note:', content.replace(/\\'/g, "'"));
    
    if (newContent === null) return;
    
    try {
        const response = await fetch(`${API_URL}/notes/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content: newContent })
        });
        
        if (response.ok) {
            showNotification('Note updated', 'success');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error updating note', 'error');
    }
}

// Delete note
async function deleteNote(id) {
    try {
        const response = await fetch(`${API_URL}/notes/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('Note deleted', 'success');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error deleting note', 'error');
    }
}

// Log interaction
async function logInteraction() {
    const type = document.getElementById('log-type').value;
    const notes = document.getElementById('log-notes').value;
    
    try {
        const response = await fetch(`${API_URL}/interactions`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contact_id: currentContactId,
                type: type,
                notes: notes
            })
        });
        
        if (response.ok) {
            showNotification('Interaction logged', 'success');
            document.getElementById('log-type').value = 'call';
            document.getElementById('log-notes').value = '';
            closeModal('log-interaction-modal');
            showContactDetail(currentContactId);
            loadContacts();
        }
    } catch (error) {
        showNotification('Error logging interaction', 'error');
    }
}

// Add note
async function addNote() {
    const content = document.getElementById('add-note-content').value;
    
    if (!content) return;
    
    try {
        const response = await fetch(`${API_URL}/notes`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contact_id: currentContactId,
                content: content
            })
        });
        
        if (response.ok) {
            showNotification('Note added', 'success');
            document.getElementById('add-note-content').value = '';
            closeModal('add-note-modal');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error adding note', 'error');
    }
}

// Add document link
async function addDocument() {
    const kind = docKind.add;
    const url = (kind === 'file' ? document.getElementById('add-doc-path') : document.getElementById('doc-url')).value.trim();
    let title = document.getElementById('doc-title').value.trim();
    if (!title && kind === 'file' && url) title = url.replace(/^["']|["']$/g, '').split(/[\\/]/).pop();   // default title = file name
    
    if (!title || !url) {
        showNotification(kind === 'file' ? 'Please choose a file' : 'Please fill in both title and URL', 'warning');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/documents`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contact_id: currentContactId,
                title: title,
                url: url,
                kind: kind
            })
        });
        
        if (!response.ok) {
            const err = await response.json().catch(() => ({}));
            showNotification(err.error || 'Error adding document', 'error');
            return;
        }
        if (response.ok) {
            showNotification('Document added', 'success');
            document.getElementById('doc-title').value = '';
            document.getElementById('doc-url').value = '';
            document.getElementById('add-doc-path').value = '';
            setDocKind('add', 'link');
            closeModal('add-document-modal');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error adding document', 'error');
    }
}

// ===== Local file documents (v2.2) =====
const docKind = { add: 'link', edit: 'link' };

function setDocKind(which, kind) {
    docKind[which] = kind;
    document.getElementById(`${which}-doc-url-group`).style.display = kind === 'link' ? '' : 'none';
    document.getElementById(`${which}-doc-file-group`).style.display = kind === 'file' ? '' : 'none';
    document.querySelectorAll(`#${which}-doc-kind button`).forEach(b => b.classList.toggle('on', b.dataset.kind === kind));
}

// Calls that make easyCRM act on this computer carry a header other websites cannot send
async function localAction(path, body) {
    const res = await fetch(`${API_URL}${path}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-EasyCRM': '1' },
        body: JSON.stringify(body || {})
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw Object.assign(new Error(data.error || 'Error'), data);
    return data;
}

async function browseLocalFile(which) {
    try {
        showNotification('Choose the file in the window that opens (it may be behind your browser)…', 'info');
        const r = await localAction('/pick-file');
        if (r.cancelled) return;
        document.getElementById(`${which}-doc-path`).value = r.path;
        const titleEl = document.getElementById(which === 'add' ? 'doc-title' : 'edit-doc-title');
        if (!titleEl.value.trim()) titleEl.value = r.name;
    } catch (e) {
        showNotification(e.message, 'warning');
    }
}

async function openLocalDocument(id) {
    try { await localAction(`/documents/${id}/open`); }
    catch (e) { showNotification(e.message, 'error'); if (e.missing) showContactDetail(currentContactId); }
}

async function revealLocalDocument(id) {
    try { await localAction(`/documents/${id}/reveal`); }
    catch (e) { showNotification(e.message, 'error'); }
}

// Open edit document modal
function openEditDocumentModal(docId, title, url, kind = 'link') {
    document.getElementById('edit-doc-id').value = docId;
    document.getElementById('edit-doc-title').value = title;
    document.getElementById('edit-doc-url').value = kind === 'file' ? '' : url;
    document.getElementById('edit-doc-path').value = kind === 'file' ? url : '';
    setDocKind('edit', kind);
    
    openModal('edit-document-modal');
}

// Save edited document
async function saveEditedDocument() {
    const docId = document.getElementById('edit-doc-id').value;
    const title = document.getElementById('edit-doc-title').value.trim();
    const kind = docKind.edit;
    const url = (kind === 'file' ? document.getElementById('edit-doc-path') : document.getElementById('edit-doc-url')).value.trim();
    
    if (!title || !url) {
        showNotification(kind === 'file' ? 'Please give a title and choose a file' : 'Please fill in both title and URL', 'warning');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/documents/${docId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title: title, url: url, kind: kind })
        });
        
        if (!response.ok) {
            const err = await response.json().catch(() => ({}));
            showNotification(err.error || 'Error updating document', 'error');
            return;
        }
        if (response.ok) {
            showNotification('Document updated', 'success');
            closeModal('edit-document-modal');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error updating document', 'error');
    }
}

// Delete document
async function deleteDocument(docId) {
    if (!confirm('Delete this document link?')) return;
    
    try {
        const response = await fetch(`${API_URL}/documents/${docId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('Document deleted', 'success');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error deleting document', 'error');
    }
}

// Toggle selection for bulk operations
function toggleSelection(contactId) {
    if (selectedContacts.has(contactId)) {
        selectedContacts.delete(contactId);
    } else {
        selectedContacts.add(contactId);
    }
    updateBulkBar();
}

// ===== v2.4: easier selection in the table =====
// Click anywhere in the left strip to tick/untick; press and slide over rows to tick (or untick) many;
// Shift+click to tick everything between the last clicked row and this one.
let selectDrag = null;        // { state, anchorIdx, lastIdx, x, y, timer }
let selectAnchorIdx = null;   // last clicked row, for Shift+click

function selectCells() { return Array.from(document.querySelectorAll('.contacts-table td.select-cell')); }

function setRowSelected(cell, state) {
    const id = Number(cell.dataset.id);
    if (state) selectedContacts.add(id); else selectedContacts.delete(id);
    const cb = cell.querySelector('.contact-checkbox');
    if (cb) cb.checked = state;
}

function applySelectRange(from, to, state) {
    const cells = selectCells();
    const [a, b] = from <= to ? [from, to] : [to, from];
    for (let i = a; i <= b; i++) if (cells[i]) setRowSelected(cells[i], state);
    // While sliding, don't make the bulk bar appear/disappear: it would push the rows
    // under the pointer. It is updated when the button is released.
    const bar = document.getElementById('bulk-actions');
    if (!selectDrag || (bar.style.display === 'flex' && selectedContacts.size > 0)) updateBulkBar();
}

function selectCellDown(event, contactId) {
    if (event.button !== 0) return;
    event.preventDefault();                       // no text highlighting while sliding
    const cells = selectCells();
    const idx = cells.findIndex(c => Number(c.dataset.id) === contactId);
    if (idx < 0) return;
    if (event.shiftKey && selectAnchorIdx !== null && selectAnchorIdx < cells.length) {
        applySelectRange(selectAnchorIdx, idx, true);
        selectAnchorIdx = idx;
        return;
    }
    const state = !selectedContacts.has(contactId);
    selectDrag = { state, lastIdx: idx, x: event.clientX, y: event.clientY, timer: setInterval(selectDragTick, 50) };
    applySelectRange(idx, idx, state);
    selectAnchorIdx = idx;
    document.body.classList.add('select-dragging');
}

function selectDragAt(x, y) {
    const el = document.elementFromPoint(x, y);
    const row = el && el.closest('.contacts-table tbody tr');
    if (!row) return;
    const cell = row.querySelector('td.select-cell');
    const idx = selectCells().indexOf(cell);
    if (idx < 0 || idx === selectDrag.lastIdx) return;
    applySelectRange(selectDrag.lastIdx, idx, selectDrag.state);
    selectDrag.lastIdx = idx;
    selectAnchorIdx = idx;
}

function selectScroller() {
    const c = document.getElementById('contacts-container');
    return (c && c.scrollHeight > c.clientHeight + 1) ? c : null;
}

// While sliding near the top or bottom edge of the list, scroll it so you can keep going.
function selectDragTick() {
    if (!selectDrag) return;
    const sc = selectScroller();
    const top = sc ? Math.max(sc.getBoundingClientRect().top, 0) : 0;
    const bottom = sc ? Math.min(sc.getBoundingClientRect().bottom, window.innerHeight) : window.innerHeight;
    const edge = 50; let dy = 0;
    if (selectDrag.y > bottom - edge) dy = Math.min(30, selectDrag.y - (bottom - edge));
    else if (selectDrag.y < top + edge + 40) dy = -Math.min(30, (top + edge + 40) - selectDrag.y);
    if (!dy) return;
    if (sc) sc.scrollTop += dy; else window.scrollBy(0, dy);
    // keep the pointer inside the list area when checking which row it is over
    selectDragAt(selectDrag.x, Math.max(top + edge + 41, Math.min(selectDrag.y, bottom - edge - 1)));
}

document.addEventListener('mousemove', e => {
    if (!selectDrag) return;
    selectDrag.x = e.clientX; selectDrag.y = e.clientY;
    selectDragAt(e.clientX, e.clientY);
});
document.addEventListener('mouseup', () => {
    if (!selectDrag) return;
    clearInterval(selectDrag.timer);
    selectDrag = null;
    document.body.classList.remove('select-dragging');
    updateBulkBar();
});

// Select all contacts
function selectAll(checkbox) {
    if (checkbox.checked) {
        // v2.1 fix: select only the contacts you can see, never hidden or archived ones
        selectedContacts.clear();
        visibleContacts.forEach(c => selectedContacts.add(c.id));
    } else {
        selectedContacts.clear();
    }
    
    document.querySelectorAll('.contact-checkbox').forEach(cb => {
        cb.checked = checkbox.checked;
    });
    
    updateBulkBar();
}

// Update bulk actions bar
function updateBulkBar() {
    const bar = document.getElementById('bulk-actions');
    if (selectedContacts.size > 0) {
        bar.style.display = 'flex';
        document.getElementById('selected-count').textContent = selectedContacts.size;
    } else {
        bar.style.display = 'none';
    }
}

// v2.4: after clicking a contact's email address, offer to record the email
// (an "email" interaction + a completed task, and Last contact = today)
function afterSingleEmail(contactId) {
    const c = currentContacts.find(x => x.id === contactId);
    if (!c) return;
    setTimeout(async () => {                       // let the mail app open first
        const subject = await openTextInput({
            title: `📧 Record the email to ${c.name}?`,
            label: 'If you sent it, give it a short subject and click Record: easyCRM logs it, adds a completed task and sets Last contact to today. Cancel if you did not send it.',
            value: 'Email', confirmLabel: 'Record'
        });
        if (!subject) return;
        try {
            const res = await fetch(`${API_URL}/interactions/bulk`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ids: [contactId], type: 'email', notes: subject, doneTask: `📧 Email: ${subject}` })
            });
            if (!res.ok) throw new Error((await res.json()).error || 'Error');
            await Promise.all([loadContacts(), loadStats()]);
            if (currentContactId === contactId && document.getElementById('contact-detail-modal').classList.contains('show')) showContactDetail(contactId);
            showNotification(`Email to ${c.name} recorded`, 'success');
        } catch (e) { showNotification('Could not record the email: ' + e.message, 'error'); }
    }, 600);
}

// ===== Bulk email (v2.4): open the mail app with the selected contacts in BCC =====
const BULK_EMAIL_BATCH = 50;
const bulkEmail = { recipients: [], batches: [], opened: new Set() };

function looksLikeEmail(e) { return /^[^\s@,;<>"]+@[^\s@,;<>"]+\.[^\s@,;<>"]+$/.test(e); }

function openBulkEmail() {
    const selected = currentContacts.filter(c => selectedContacts.has(c.id));
    const seen = new Set();
    const recipients = [], noEmail = [];
    selected.forEach(c => {
        const e = (c.email || '').trim();
        if (!looksLikeEmail(e)) { noEmail.push(c); return; }
        if (seen.has(e.toLowerCase())) return;          // same address twice: send once
        seen.add(e.toLowerCase());
        recipients.push({ id: c.id, email: e });
    });
    if (!recipients.length) { showNotification('None of the selected contacts has an email address', 'warning'); return; }
    bulkEmail.recipients = recipients;
    bulkEmail.batches = [];
    for (let i = 0; i < recipients.length; i += BULK_EMAIL_BATCH) bulkEmail.batches.push(recipients.slice(i, i + BULK_EMAIL_BATCH));
    bulkEmail.opened = new Set();

    document.getElementById('be-summary').textContent =
        `${recipients.length} contact${recipients.length === 1 ? '' : 's'} will be in BCC` +
        (noEmail.length ? ` · ${noEmail.length} skipped (no valid email: ${noEmail.slice(0, 3).map(c => c.name).join(', ')}${noEmail.length > 3 ? '…' : ''})` : '') + '.';
    let saved = '';
    try { saved = localStorage.getItem('easycrm.myEmail') || ''; } catch (e) {}
    document.getElementById('be-to').value = saved;
    document.getElementById('be-record').style.display = 'none';
    renderBulkEmailBatches();
    openModal('bulk-email-modal');
}

function renderBulkEmailBatches() {
    const n = bulkEmail.batches.length;
    document.getElementById('be-batches').innerHTML = bulkEmail.batches.map((b, i) => `
        <button type="button" class="${bulkEmail.opened.has(i) ? 'done' : 'btn-primary'}" onclick="openBulkEmailBatch(${i})">
            ${bulkEmail.opened.has(i) ? '✓ Opened' : '📧 Open email'}${n > 1 ? ` ${i + 1} of ${n}` : ''} — ${b.length} recipient${b.length === 1 ? '' : 's'}
        </button>`).join('') +
        (n > 1 ? `<small class="muted">Large lists are split into emails of up to ${BULK_EMAIL_BATCH}, so every mail app can handle them.</small>` : '');
}

function openBulkEmailBatch(i) {
    const to = document.getElementById('be-to').value.trim();
    if (to && !looksLikeEmail(to)) { showNotification('Your own address in “To” does not look like an email address', 'warning'); return; }
    try { if (to) localStorage.setItem('easycrm.myEmail', to); } catch (e) {}
    const subject = document.getElementById('be-subject').value.trim();
    const bcc = bulkEmail.batches[i].map(r => encodeURIComponent(r.email)).join(',');
    let url = `mailto:${encodeURIComponent(to)}?bcc=${bcc}`;
    if (subject) url += `&subject=${encodeURIComponent(subject)}`;
    window.location.href = url;                     // hands the message to Mail / Outlook / the default mail app
    bulkEmail.opened.add(i);
    renderBulkEmailBatches();
    document.getElementById('be-record').style.display = '';
}

async function recordBulkEmail() {
    const ids = bulkEmail.batches.filter((b, i) => bulkEmail.opened.has(i)).flat().map(r => r.id);
    if (!ids.length) return;
    const subject = document.getElementById('be-subject').value.trim();
    try {
        const res = await fetch(`${API_URL}/interactions/bulk`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids, type: 'email', notes: subject ? `Bulk email: ${subject}` : 'Bulk email',
                                   doneTask: `📧 Email: ${subject || 'bulk email'}` })
        });
        if (!res.ok) throw new Error((await res.json()).error || 'Error');
        closeModal('bulk-email-modal');
        selectedContacts.clear();
        updateBulkBar();
        await Promise.all([loadContacts(), loadStats()]);
        showNotification(`Recorded the email on ${ids.length} contact${ids.length === 1 ? '' : 's'}`, 'success');
    } catch (e) {
        showNotification('Could not record the email: ' + e.message, 'error');
    }
}

// Bulk delete
async function bulkDelete() {
    try {
        const response = await fetch(`${API_URL}/contacts/bulk-delete`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids: Array.from(selectedContacts) })
        });
        
        if (response.ok) {
            showNotification(`${selectedContacts.size} contacts deleted`, 'success');
            selectedContacts.clear();
            updateBulkBar();
            loadContacts();
            loadStats();
        }
    } catch (error) {
        showNotification('Error deleting contacts', 'error');
    }
}

// Bulk add tags
async function bulkAddTags() {
    const chosen = await openTagPicker({
        title: `Add tags to ${selectedContacts.size} selected contact${selectedContacts.size === 1 ? '' : 's'}`,
        confirmLabel: 'Add tags'
    });
    if (!chosen) return;
    const tags = chosen.join(',');
    
    try {
        const response = await fetch(`${API_URL}/contacts/bulk-update-tags`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                ids: Array.from(selectedContacts),
                tags: tags,
                action: 'add'
            })
        });
        
        if (response.ok) {
            showNotification('Tags added to selected contacts', 'success');
            selectedContacts.clear();
            updateBulkBar();
            loadContacts();
        }
    } catch (error) {
        showNotification('Error adding tags', 'error');
    }
}

// Bulk remove tags
async function bulkRemoveTags() {
    const selected = currentContacts.filter(c => selectedContacts.has(c.id));
    const chosen = await openTagPicker({
        title: `Remove tags from ${selected.length} selected contact${selected.length === 1 ? '' : 's'}`,
        intro: 'Only tags used by the selected contacts are listed.',
        confirmLabel: 'Remove tags',
        options: getTagCatalogue(selected),
        allowNew: false
    });
    if (!chosen) return;
    // Remove every spelling variant of the chosen tags (e.g. "Author" and "author")
    const catalogue = getTagCatalogue(selected);
    const tags = chosen.flatMap(t => (catalogue.find(o => o.tag === t) || { variants: [t] }).variants).join(',');

    try {
        const response = await fetch(`${API_URL}/contacts/bulk-update-tags`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                ids: Array.from(selectedContacts),
                tags: tags,
                action: 'remove'
            })
        });

        if (response.ok) {
            showNotification('Tags removed from selected contacts', 'success');
            selectedContacts.clear();
            updateBulkBar();
            loadContacts();
        }
    } catch (error) {
        showNotification('Error removing tags', 'error');
    }
}

// Confirm and delete contact (only from detail modal)
function confirmDeleteContact(contactId) {
    const contact = currentContacts.find(c => c.id === contactId);
    const name = contact ? contact.name : 'this contact';
    if (confirm(`Are you sure you want to permanently delete "${name}"? This cannot be undone.`)) {
        deleteContact(contactId);
        closeModal('contact-detail-modal');
    }
}

// Bulk archive
async function bulkArchive() {
    if (!confirm(`Archive ${selectedContacts.size} selected contacts?`)) return;
    try {
        const response = await fetch(`${API_URL}/contacts/bulk-archive`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids: Array.from(selectedContacts) })
        });
        if (response.ok) {
            showNotification(`${selectedContacts.size} contacts archived`, 'success');
            selectedContacts.clear();
            updateBulkBar();
            loadContacts();
            loadStats();
        }
    } catch (error) {
        showNotification('Error archiving contacts', 'error');
    }
}

// Bulk toggle follow-up
async function bulkFollowUp() {
    const n = selectedContacts.size;
    const action = await openChoice({
        title: `Follow-up for ${n} selected contact${n === 1 ? '' : 's'}`,
        message: 'Clearing the follow-up marks the contacts as contacted today, so they won\'t be flagged again for 30 days.',
        choices: [
            { label: '🔔 Mark for follow-up', value: 'mark', cls: 'btn-warning' },
            { label: '✔️ Clear follow-up', value: 'unmark', cls: 'btn-primary' }
        ]
    });
    if (!action) return;
    try {
        const response = await fetch(`${API_URL}/contacts/bulk-followup`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids: Array.from(selectedContacts), action })
        });
        if (response.ok) {
            showNotification(`${selectedContacts.size} contacts updated`, 'success');
            selectedContacts.clear();
            updateBulkBar();
            loadContacts();
            loadStats();
        }
    } catch (error) {
        showNotification('Error updating follow-up', 'error');
    }
}

// Bulk create task
async function bulkTask() {
    const title = prompt('Task title for selected contacts:');
    if (!title) return;
    const due_date = prompt('Due date (YYYY-MM-DD) or leave empty:');
    try {
        const response = await fetch(`${API_URL}/contacts/bulk-task`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                ids: Array.from(selectedContacts),
                title,
                due_date: due_date || null,
                priority: 'medium'
            })
        });
        if (response.ok) {
            showNotification(`Task created for ${selectedContacts.size} contacts`, 'success');
            selectedContacts.clear();
            updateBulkBar();
            loadStats();
        }
    } catch (error) {
        showNotification('Error creating tasks', 'error');
    }
}

// Clear selection and reload
function clearSelectionAndReload() {
    selectedContacts.clear();
    updateBulkBar();
    loadContacts();
}

// Show the × in the search box only when there is something to clear (v2.4)
function updateSearchClear() {
    const input = document.getElementById('search-input');
    const btn = document.getElementById('search-clear');
    if (input && btn) btn.classList.toggle('show', input.value.length > 0);
}

function clearSearch() {
    const input = document.getElementById('search-input');
    input.value = '';
    updateSearchClear();
    searchContacts();
    input.focus();
}

// Search and filter
// v2.4: highlight the stat box of the group being browsed
function updateActiveStat() {
    const tasksOpen = document.getElementById('tasks-view').style.display === 'flex';
    const view = tasksOpen ? 'tasks' : archivedOnly ? 'archived' : followUpOnly ? 'followup' : 'all';
    document.querySelectorAll('.stat-card[data-view]').forEach(card =>
        card.classList.toggle('active', card.dataset.view === view));
}

function searchContacts() {
    updateActiveStat();
    const searchTerm = document.getElementById('search-input').value.toLowerCase();
    updateSearchClear();
    const wanted = tagFilters.map(t => t.toLowerCase());
    
    let filtered = currentContacts.filter(contact => {
        const matchesSearch = !searchTerm || 
            contact.name.toLowerCase().includes(searchTerm) ||
            (contact.email && contact.email.toLowerCase().includes(searchTerm)) ||
            (contact.company && contact.company.toLowerCase().includes(searchTerm)) ||
            (contact.company_name && contact.company_name.toLowerCase().includes(searchTerm));
        
        // Bug fix: split into individual tags and do an exact match.
        // Previous `contact.tags.includes(tagFilter)` was a substring check,
        // so filtering by "lead" would also match contacts tagged "leader".
        const contactTagList = contact.tags
            ? contact.tags.split(',').map(t => t.trim())
            : [];
        // v2.1: several tags, "any" (at least one) or "all" (every one)
        const have = new Set(contactTagList.map(t => t.toLowerCase()));
        const matchesTag = wanted.length === 0 ||
            (tagMatchMode === 'all' ? wanted.every(t => have.has(t)) : wanted.some(t => have.has(t)));
        
        const matchesFollowUp = !followUpOnly || contact.needs_follow_up === 1;
        
        // Respect archived filter
        const matchesArchived = archivedOnly ? contact.archived === 1 : contact.archived !== 1;
        
        return matchesSearch && matchesTag && matchesFollowUp && matchesArchived;
    });
    
    displayContacts(filtered);
    if (filtered.length === 0 && (wanted.length || searchTerm)) explainEmptyResult(searchTerm, wanted);
    return filtered.length;
}

// v2.1: when filters give nothing, say why and offer the other view if it has matches
function explainEmptyResult(searchTerm, wanted) {
    const inOtherView = currentContacts.filter(contact => {
        if ((contact.archived === 1) === archivedOnly) return false;
        const have = new Set((contact.tags || '').split(',').map(t => t.trim().toLowerCase()));
        const okTag = wanted.length === 0 || (tagMatchMode === 'all' ? wanted.every(t => have.has(t)) : wanted.some(t => have.has(t)));
        const okSearch = !searchTerm || contact.name.toLowerCase().includes(searchTerm) ||
            (contact.email || '').toLowerCase().includes(searchTerm) ||
            (contact.company_name || contact.company || '').toLowerCase().includes(searchTerm);
        return okTag && okSearch;
    }).length;
    const what = wanted.length ? `with ${tagFilters.length === 1 ? 'the tag “' + escapeHtml(tagFilters[0]) + '”' : 'these tags'}` : 'matching your search';
    const where = archivedOnly ? 'archived' : 'active';
    const other = archivedOnly ? 'active' : 'archived';
    document.getElementById('contacts-container').innerHTML = `
        <div class="empty-state">
            No ${where} contacts ${what}${followUpOnly ? ' needing follow-up' : ''}.
            ${inOtherView ? `<br><br>${inOtherView} ${other} contact${inOtherView === 1 ? ' has' : 's have'} ${wanted.length ? (tagFilters.length === 1 ? 'it' : 'them') : 'a match'}.
                <button type="button" class="btn-primary" style="margin-left:8px" onclick="switchArchiveViewKeepingFilters()">Show ${other} contacts</button>` : ''}
        </div>`;
}

function switchArchiveViewKeepingFilters() {
    archivedOnly = !archivedOnly;
    followUpOnly = false;
    searchContacts();
}

// ===== Tag filter (v2.1): pick several tags, match Any / All =====
let tagFilters = [];          // selected tag names
let tagMatchMode = 'any';     // 'any' | 'all'
let tagCatalogue = [];        // [{tag, count, variants}]

function populateTagFilter(contacts) {
    // Built from ALL contacts (archived too); "Author"/"author" count as one tag
    tagCatalogue = getTagCatalogue(currentContacts.length ? currentContacts : contacts)
        .sort((a, b) => a.tag.localeCompare(b.tag, undefined, { sensitivity: 'base' }));
    // Drop selections that no longer exist (e.g. after a rename), keep canonical spelling
    tagFilters = tagFilters
        .map(t => (tagCatalogue.find(o => o.tag.toLowerCase() === t.toLowerCase()) || {}).tag)
        .filter(Boolean);
    updateTagFilterButton();
    if (document.getElementById('tag-filter-panel').classList.contains('open')) renderTagFilterPanel();
    if (document.getElementById('tag-manager-modal').classList.contains('show')) renderTagManager();
}

function updateTagFilterButton() {
    const btn = document.getElementById('tag-filter-btn');
    if (!btn) return;
    let label = '🏷️ All tags';
    if (tagFilters.length === 1) label = `🏷️ ${tagFilters[0]}`;
    else if (tagFilters.length > 1) label = `🏷️ ${tagFilters.length} tags · ${tagMatchMode === 'all' ? 'all' : 'any'}`;
    btn.textContent = label + ' ▾';
    btn.classList.toggle('active', tagFilters.length > 0);
    btn.title = tagFilters.length ? tagFilters.join(tagMatchMode === 'all' ? ' AND ' : ' OR ') : 'Filter by tags';
}

function toggleTagFilterPanel(force) {
    const panel = document.getElementById('tag-filter-panel');
    const open = force !== undefined ? force : !panel.classList.contains('open');
    panel.classList.toggle('open', open);
    if (open) {
        document.getElementById('tfp-search').value = '';
        renderTagFilterPanel();
        setTimeout(() => document.getElementById('tfp-search').focus(), 30);
    }
}

function renderTagFilterPanel() {
    const q = document.getElementById('tfp-search').value.trim().toLowerCase();
    const chosen = new Set(tagFilters.map(t => t.toLowerCase()));
    document.querySelectorAll('#tag-filter-panel .tfp-mode button').forEach(b =>
        b.classList.toggle('on', b.dataset.mode === tagMatchMode));
    // v2.1: counts follow the current view (active contacts, or the archive)
    const here = o => archivedOnly ? o.archived : o.active;
    const list = tagCatalogue.filter(o => !q || o.tag.toLowerCase().includes(q));
    const byName = (a, b) => a.tag.localeCompare(b.tag, undefined, { sensitivity: 'base' });
    const sel = list.filter(o => chosen.has(o.tag.toLowerCase())).sort(byName);
    const used = list.filter(o => !chosen.has(o.tag.toLowerCase()) && here(o) > 0).sort(byName);
    const item = o => `
        <label class="tfp-item ${chosen.has(o.tag.toLowerCase()) ? 'on' : ''} ${here(o) === 0 ? 'none-here' : ''}">
            <input type="checkbox" ${chosen.has(o.tag.toLowerCase()) ? 'checked' : ''} onchange="toggleTagFilter(${jsArg(o.tag)})">
            <span class="tfp-name">${escapeHtml(o.tag)}</span>
            <span class="tp-count" title="${archivedOnly ? 'Archived' : 'Active'} contacts with this tag">${here(o)}</span>
        </label>`;
    // v2.1: only tags present in this view (active OR archived); ticked ones stay listed so you can untick them
    const html = sel.map(item).join('') + used.map(item).join('');
    document.getElementById('tfp-list').innerHTML = html || '<div class="muted" style="padding:10px">No matching tags</div>';
    document.getElementById('tfp-view').textContent = archivedOnly ? 'Tags used on archived contacts' : 'Tags used on active contacts';
    document.getElementById('tfp-summary').textContent = tagFilters.length
        ? `${tagFilters.length} selected` : 'No tag selected — showing all';
}

function toggleTagFilter(tag) {
    const i = tagFilters.findIndex(t => t.toLowerCase() === tag.toLowerCase());
    if (i >= 0) tagFilters.splice(i, 1); else tagFilters.push(tag);
    updateTagFilterButton();
    renderTagFilterPanel();
    searchContacts();
}

function setTagMatchMode(mode) {
    tagMatchMode = mode;
    updateTagFilterButton();
    renderTagFilterPanel();
    searchContacts();
}

function clearTagFilters() {
    tagFilters = [];
    updateTagFilterButton();
    renderTagFilterPanel();
    searchContacts();
}

// Close the panel when clicking elsewhere
document.addEventListener('click', (e) => {
    const wrap = document.getElementById('tag-filter-wrap');
    if (!e.target.isConnected) return;   // the list was just re-drawn under the click
    if (wrap && !wrap.contains(e.target)) toggleTagFilterPanel(false);
});

// ===== Tag manager (v2.1): rename, merge, delete tags on all contacts =====
let tagManagerSelected = new Set();   // lower-case tag names ticked in the manager

function openTagManager() {
    toggleTagFilterPanel(false);
    tagManagerSelected.clear();
    document.getElementById('tm-search').value = '';
    renderTagManager();
    openModal('tag-manager-modal');
}

// Tags that look alike once spaces, dashes and capitals are ignored ("ARM research" / "ARMResearch")
function similarKey(tag) { return tag.toLowerCase().replace(/[^a-z0-9à-ÿ]/g, ''); }

function renderTagManager() {
    const q = document.getElementById('tm-search').value.trim().toLowerCase();
    const groups = {};
    tagCatalogue.forEach(o => { const k = similarKey(o.tag); (groups[k] = groups[k] || []).push(o.tag); });
    const rows = tagCatalogue.filter(o => !q || o.tag.toLowerCase().includes(q)).map(o => {
        const lc = o.tag.toLowerCase();
        const similar = (groups[similarKey(o.tag)] || []).filter(t => t !== o.tag);
        const notes = [];
        if (o.variants.length > 1) notes.push(`<span class="tm-note" title="Stored with different capitals">also spelled: ${escapeHtml(o.variants.slice(1).join(', '))} <button type="button" class="link-btn" onclick="unifyTagSpelling(${jsArg(o.tag)})">unify</button></span>`);
        if (similar.length) notes.push(`<span class="tm-note">looks like: ${escapeHtml(similar.join(', '))}</span>`);
        return `
        <div class="tm-row ${tagManagerSelected.has(lc) ? 'on' : ''}">
            <input type="checkbox" ${tagManagerSelected.has(lc) ? 'checked' : ''} onchange="toggleTagManagerSelect(${jsArg(o.tag)})">
            <span class="tm-name"><span class="tag">${escapeHtml(o.tag)}</span>${notes.join('')}</span>
            <span class="tp-count" title="Active contacts with this tag">${o.active}</span>
            <span class="tfp-other" title="Archived contacts with this tag">${o.archived ? '+' + o.archived + ' archived' : ''}</span>
            <button type="button" class="btn-icon" onclick="renameTag(${jsArg(o.tag)})" title="Rename">✏️<span>Rename</span></button>
            <button type="button" class="btn-icon" onclick="deleteTags([${jsArg(o.tag)}])" title="Delete">🗑️<span>Delete</span></button>
        </div>`;
    }).join('');
    document.getElementById('tm-list').innerHTML = rows || '<div class="muted" style="padding:10px">No tags</div>';
    const n = tagManagerSelected.size;
    document.getElementById('tm-selected-bar').style.display = n ? 'flex' : 'none';
    document.getElementById('tm-selected-count').textContent = `${n} selected`;
    document.getElementById('tm-merge-btn').disabled = n < 2;
    document.getElementById('tm-total').textContent = `${tagCatalogue.length} tags`;
}

function toggleTagManagerSelect(tag) {
    const lc = tag.toLowerCase();
    if (tagManagerSelected.has(lc)) tagManagerSelected.delete(lc); else tagManagerSelected.add(lc);
    renderTagManager();
}

function catalogueEntry(tag) { return tagCatalogue.find(o => o.tag.toLowerCase() === tag.toLowerCase()); }

async function callTagApi(path, body, okMessage) {
    try {
        const res = await fetch(`${API_URL}/tags/${path}`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Error');
        showNotification(`${okMessage} — ${data.changed} contact${data.changed === 1 ? '' : 's'} updated`, 'success');
        tagManagerSelected.clear();
        await loadContacts();
        renderTagManager();
    } catch (e) {
        showNotification('Could not update tags: ' + e.message, 'error');
    }
}

async function renameTag(tag) {
    const entry = catalogueEntry(tag);
    const to = await openTextInput({ title: `Rename tag “${tag}”`, label: `Used by ${entry ? entry.count : 0} contacts. New name:`, value: tag, confirmLabel: 'Rename' });
    if (!to || to === tag) return;
    const clash = catalogueEntry(to);
    if (clash && clash.tag.toLowerCase() !== tag.toLowerCase()) {
        const ok = await openChoice({ title: `“${clash.tag}” already exists`, message: `Renaming will merge “${tag}” into “${clash.tag}”.`, choices: [{ label: 'Merge', value: 'yes', cls: 'btn-primary' }] });
        if (!ok) return;
    }
    callTagApi('rename', { from: entry ? entry.variants : [tag], to }, `Renamed to “${to}”`);
}

async function unifyTagSpelling(tag) {
    const entry = catalogueEntry(tag);
    if (!entry) return;
    callTagApi('rename', { from: entry.variants, to: entry.tag }, `All spellings now “${entry.tag}”`);
}

async function mergeSelectedTags() {
    const entries = tagCatalogue.filter(o => tagManagerSelected.has(o.tag.toLowerCase()));
    if (entries.length < 2) return;
    const biggest = entries.slice().sort((a, b) => b.count - a.count)[0].tag;
    const to = await openTextInput({
        title: `Merge ${entries.length} tags`,
        label: `${entries.map(e => e.tag).join(', ')} will become one tag. Name:`,
        value: biggest, confirmLabel: 'Merge'
    });
    if (!to) return;
    callTagApi('rename', { from: entries.flatMap(e => e.variants), to }, `Merged into “${to}”`);
}

async function deleteTags(tags) {
    const entries = tags.map(catalogueEntry).filter(Boolean);
    if (!entries.length) return;
    const total = entries.reduce((n, e) => n + e.count, 0);
    const ok = await openChoice({
        title: entries.length === 1 ? `Delete tag “${entries[0].tag}”?` : `Delete ${entries.length} tags?`,
        message: `The tag${entries.length === 1 ? '' : 's'} will be removed from ${total} contact${total === 1 ? '' : 's'} (archived included). The contacts themselves are kept.`,
        choices: [{ label: '🗑️ Delete', value: 'yes', cls: 'btn-danger' }]
    });
    if (!ok) return;
    callTagApi('delete', { tags: entries.flatMap(e => e.variants) }, 'Tag deleted');
}

function deleteSelectedTags() {
    deleteTags(tagCatalogue.filter(o => tagManagerSelected.has(o.tag.toLowerCase())).map(o => o.tag));
}

// ===== Small text-input dialog (v2.1) =====
let textInputResolve = null;
function openTextInput({ title, label = '', value = '', confirmLabel = 'OK' }) {
    return new Promise(resolve => {
        textInputResolve = resolve;
        document.getElementById('ti-title').textContent = title;
        document.getElementById('ti-label').textContent = label;
        document.getElementById('ti-confirm').textContent = confirmLabel;
        const input = document.getElementById('ti-input');
        input.value = value;
        document.getElementById('text-input-modal').classList.add('show');
        setTimeout(() => { input.focus(); input.select(); }, 30);
    });
}
function closeTextInput(ok) {
    document.getElementById('text-input-modal').classList.remove('show');
    const v = document.getElementById('ti-input').value.replace(/,/g, ' ').replace(/\s+/g, ' ').trim();
    if (textInputResolve) { const r = textInputResolve; textInputResolve = null; r(ok && v ? v : null); }
}

// Export contacts
function exportContacts() {
    window.location.href = `${API_URL}/export/contacts`;
}

// Export backup
// ===== Restore from a backup file (v2.2) =====
// 1) the server saves a copy of the current data in backups/, 2) replaces everything with the file.
async function restoreFromFile(input) {
    const file = input.files && input.files[0];
    input.value = '';                       // allow picking the same file again later
    if (!file) return;
    let backup;
    try {
        backup = JSON.parse(await file.text());
    } catch (e) {
        showNotification('This file is not a valid easyCRM backup (it is not readable JSON).', 'error');
        return;
    }
    try {
        const pre = await fetch(`${API_URL}/restore/preview`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(backup)
        });
        const info = await pre.json();
        if (!pre.ok) { showNotification(info.error || 'Not a valid backup file', 'error'); return; }

        const when = info.exportDate ? new Date(info.exportDate).toLocaleString() : 'unknown date';
        const f = info.file, c = info.current;
        const ok = await openChoice({
            title: '♻️ Restore this backup?',
            message: `Backup “${file.name}” from ${when}: ${f.contacts} contacts, ${f.tasks} tasks, ${f.notes} notes, ${f.interactions} interactions, ${f.documents} documents.\n\n` +
                     `You have now: ${c.contacts} contacts, ${c.tasks} tasks, ${c.notes} notes, ${c.interactions} interactions, ${c.documents} documents.\n\n` +
                     `1) Your current data is first saved as a copy in the “backups” folder.\n2) Then ALL current data is replaced by the backup.`,
            choices: [{ label: '♻️ Restore', value: 'yes', cls: 'btn-danger' }]
        });
        if (!ok) return;

        showNotification('Restoring…', 'info');
        const res = await fetch(`${API_URL}/restore`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(backup)
        });
        const out = await res.json();
        if (!res.ok) { showNotification(out.error || 'Restore failed — nothing was changed', 'error'); return; }
        selectedContacts.clear();
        updateBulkBar();
        await Promise.all([loadContacts(), loadStats(), loadCompanies()]);
        showNotification(`Restored ${out.restored.contacts} contacts. Your previous data is saved as ${out.safetyCopy}`, 'success');
    } catch (e) {
        showNotification('Restore failed — nothing was changed (' + e.message + ')', 'error');
    }
}

function exportBackup() {
    window.location.href = `${API_URL}/export/backup`;
}

// Import CSV
async function importCSV() {
    const fileInput = document.getElementById('import-file');
    const file = fileInput.files[0];
    
    if (!file) {
        showNotification('Please select a file', 'warning');
        return;
    }
    
    const text = await file.text();
    
    try {
        const response = await fetch(`${API_URL}/import/contacts`, {
            method: 'POST',
            headers: { 'Content-Type': 'text/csv' },
            body: text
        });
        
        const result = await response.json();
        if (!response.ok) {
            showNotification(result.error || 'Import failed', 'error');
            return;
        }
        let msg = `Imported ${result.imported} contacts`;
        if (result.failed > 0) msg += `, ${result.failed} failed`;
        if (result.skippedRows > 0) msg += `, ${result.skippedRows} skipped (no name)`;
        showNotification(msg, result.failed > 0 ? 'warning' : 'success');
        fileInput.value = '';
        closeModal('import-modal');
        loadContacts();
        loadStats();
    } catch (error) {
        showNotification('Import failed', 'error');
    }
}

// FIXED: Modal functions with proper centering
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.add('show');
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('show');
}

// Close modal on outside click
window.onclick = function(event) {
    if (event.target.id === 'tag-picker-modal') {
        closeTagPicker(null);
    } else if (event.target.id === 'choice-modal') {
        closeChoice(null);
    } else if (event.target.id === 'text-input-modal') {
        closeTextInput(false);
    } else if (event.target.classList.contains('modal')) {
        event.target.classList.remove('show');
    }
}

// Show notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Only allow web/mail links in href attributes; anything else (e.g. "javascript:")
// is treated as a plain web address.
function safeUrl(url) {
    const u = String(url || '').trim();
    if (/^(https?:|mailto:)/i.test(u)) return escapeHtml(u);
    return escapeHtml('https://' + u.replace(/^[a-z][a-z0-9+.-]*:/i, ''));
}

// Safely embed a value as a JavaScript string argument inside an inline HTML handler
// (e.g. onclick="fn(${jsArg(value)})"). JSON.stringify makes a valid JS string literal
// (quotes, backslashes, newlines escaped); escapeHtml then protects the HTML attribute.
function jsArg(value) {
    return escapeHtml(JSON.stringify(String(value == null ? '' : value)));
}

// Escape HTML
function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.toString().replace(/[&<>"']/g, m => map[m]);
}
