#!/bin/bash
# Double-click on a Mac to start easyCRM
cd "$(dirname "$0")" && ./start.sh
