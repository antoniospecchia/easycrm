#!/bin/bash
# Start easyCRM and open it in your default browser
cd "$(dirname "$0")" || exit 1
if [ ! -d node_modules ]; then
    echo "easyCRM is not installed yet. Running install.sh first..."
    exec ./install.sh
fi
URL="http://localhost:${PORT:-3000}"
echo "🚀 Starting easyCRM... keep this window open while you use it (Ctrl+C to stop)."
(
  sleep 2
  if command -v open >/dev/null 2>&1; then open "$URL"
  elif command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL" >/dev/null 2>&1
  else echo "Open $URL in your browser."
  fi
) &
node server.js
