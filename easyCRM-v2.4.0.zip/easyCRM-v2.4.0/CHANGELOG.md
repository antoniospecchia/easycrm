# Changelog

## 2.4.0 — October 2026

### New
- **Table view: wider Name column**, narrower Company; names stay on one line with the 🔔. Long names, emails or company names are shortened with “…” and shown in full when you hover over them.
- **📧 Bulk email**: select contacts and click **📧 Email** in the bulk bar. easyCRM opens your mail app (Mail, Outlook…) with your own address in To and the selected contacts in **BCC**; you write and send as usual. Contacts without an email are skipped (and listed), duplicates are sent once, and more than 50 recipients are split into several emails. Afterwards easyCRM asks “Did you send it?” — if yes, it logs an “email” interaction and a **completed task** (“📧 Email: subject”) on each contact and sets Last contact to today.
- **Single emails are recorded too**: click a contact's email address — your mail app opens, and easyCRM offers to record it the same way (interaction + completed task + Last contact today).
- **Tag window**: click a contact's tags (in the table, on a card, the 🏷️ button or “Add” in the contact window) to open a small window: remove a tag with ×, add one from your existing tags or create a new one by typing, and 🔍 to show all contacts with that tag. Changes are saved at once.
- **Easier selection in the Table view**: click anywhere in the left strip of a row to tick it (no need to hit the small box). Press and slide up or down to tick many at once (starting on a ticked row unticks instead); slide to the edge of the list and it scrolls by itself. **Shift+click** ticks everything between the last row you clicked and this one.
- **You can see which group you are browsing**: the box at the top you clicked (All Contacts, Tasks Due, Need Follow-up or Archived) is outlined in blue with a “VIEWING” badge.
- **× in the search box**: appears as soon as you type; one click (or **Esc**) clears the search and shows all contacts again.

## 2.3.0 — October 2026

### New
- **♻️ Restore** (next to 💾 Backup): choose a backup file and easyCRM shows what is in it compared with your current data. On confirmation it **1)** saves a copy of your current database in the `backups` folder (`crm-before-restore-<date>.db`), then **2)** replaces all data with the backup. If anything goes wrong, nothing is changed.
- **Documents can be files on your computer**, not only web links. In "Add Document" choose **📁 File on this computer**, click **📂 Browse…** (or paste the file's location) and easyCRM remembers where it is. Clicking it opens the file with its usual app (Preview, Word, Excel…); 📂 shows it in Finder / Explorer. The file stays where it is; if it is moved or renamed, easyCRM shows "file not found" and you can point it to the new place with ✏️. On Linux the Browse window needs `zenity`; otherwise paste the location.
- Backups now also include the list of companies.

### Notes
- Version 2.2 was internal only; 2.3 contains everything since 2.1.
- Backups made with 2.1 can be restored with 2.3.

## 2.1.0 — October 2026

### New
- **Clearer contact cards (Grid view)**: equal-height cards with buttons along the bottom, company under the name, a "Follow up" badge instead of orange names, and "Last contact: 12 days ago" with a green / amber / red dot.
- **Activity on each card**: next open task (red when overdue), last interaction and latest note.
- **Tag picker**: choose tags from a searchable list (with how many contacts use each) instead of typing them into a pop-up; works for single contacts, bulk add / remove, and the Add / Edit forms. Typing a tag that exists with different capitals ("author") reuses the existing one ("Author").
- **Tasks view**: each task on one line; overdue (red), today (blue) and upcoming are clearly different, with "overdue 6 days" / "due in 7 days"; completed tasks sit in a grey, collapsible box as faded, struck-through rows.
- **Multi-tag filter**: tick several tags in the filter panel and choose **any** (at least one) or **all** (every one); searchable, with how many contacts use each tag.
- **Tag filter follows the view**: in the active view it lists only tags used on active contacts, in the archive only tags used on archived contacts, each with its count. If a search finds nothing, easyCRM says how many archived contacts match, without showing them unless you ask.
- **Tag manager** (⚙️ Manage tags…): rename, merge and delete tags across all contacts (archived included); spots the same tag stored with different capitals ("Author"/"author", one-click **unify**) and look-alike tags ("ARM research"/"ARMResearch").
- **Fixed top area**: the title, stat boxes, search bar and buttons stay in place; only the contact list (or task list) scrolls, inside its own box, and in Table view the column titles stay visible at the top of that box.

### Changed
- Requires **Node.js 20 or newer** (LTS recommended). The database component was updated (sqlite3 6), which removes the security warnings npm showed during installation. On Linux this needs a 2024+ system (e.g. Ubuntu 24.04); older Linux should stay on 2.0.

### Fixed
- **"Select all" selected hidden contacts too** (including archived ones and those hidden by a filter), so a bulk action could change contacts you couldn't see. It now selects only the contacts on screen.
- Bulk follow-up used an OK/Cancel pop-up where "Cancel" meant "unmark", so clearing follow-up in bulk was confusing. It now offers clear "Mark for follow-up" / "Clear follow-up" buttons.
- Open tasks without a due date were not shown anywhere in the Tasks view; they now have their own "No due date" group.
- Clicking "Need Follow-up" while a tag filter was set showed the full list, but the next refresh (or switching to Grid) silently re-applied the hidden tag filter. The stat boxes now clear the filters and the list stays consistent.
- The tag filter is no longer case-sensitive and lists each tag once, including tags used only on archived contacts.
- Tags can no longer contain commas (a comma now separates tags in the picker).


## 2.0.0 — October 2026

### New
- **Companies**: contacts linked to companies; click a company to filter.
- **Archive** contacts instead of deleting them; archived view.
- **Notes thread** per contact (multiple dated notes).
- **Document links** per contact (Google Docs / Drive or any URL).
- **Website** field on contacts.
- **Bulk actions**: archive, follow-up flag, add task, add/remove tags.
- CSV import auto-detects comma or semicolon separators and reads a `Website` column.

### Fixed
- Tags or company names containing an apostrophe (e.g. `O'Brien`) broke buttons; text can no longer be interpreted as code.
- Editing a note or interaction that contained a line break failed.
- Only web and email links are opened from website and document fields.
- Tag filter matched partial words (`lead` matched `leader`).
- Switching views or reloading dropped the active tag/search filter.

### Changed
- easyCRM now listens only on your own computer (127.0.0.1) and no longer accepts requests from other websites.
- New one-click installers and start files for Windows (`install.bat`, `start-easyCRM.bat`) and macOS/Linux (`install.sh`, `start.sh`, `start-easyCRM.command`).
- `npm run reset` works on Windows and asks for confirmation.
- The setup wizard was removed: the database is created automatically on first start.
- Requires Node.js 18 or newer (LTS recommended).

### Upgrading
Copy your existing `crm.db` into the new folder before the first start; it is migrated automatically.
