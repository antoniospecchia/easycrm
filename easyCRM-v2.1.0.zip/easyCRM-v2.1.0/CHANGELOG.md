# Changelog

## 2.1.0 — October 2026

### New
- **Clearer contact cards (Grid view)**: equal-height cards with buttons along the bottom, company under the name, a "Follow up" badge instead of orange names, and "Last contact: 12 days ago" with a green / amber / red dot.
- **Activity on each card**: next open task (red when overdue), last interaction and latest note.
- **Tag picker**: choose tags from a searchable list (with how many contacts use each) instead of typing them into a pop-up; works for single contacts, bulk add / remove, and the Add / Edit forms. Typing a tag that exists with different capitals ("author") reuses the existing one ("Author").
- **Tasks view**: each task on one line; overdue (red), today (blue) and upcoming are clearly different, with "overdue 6 days" / "due in 7 days"; completed tasks sit in a grey, collapsible box as faded, struck-through rows.
- **Multi-tag filter**: tick several tags in the filter panel and choose **any** (at least one) or **all** (every one); searchable, with how many contacts use each tag.
- **Tag filter follows the view**: in the active view it lists only tags used on active contacts, in the archive only tags used on archived contacts, each with its count. If a search finds nothing, easyCRM says how many archived contacts match, without showing them unless you ask.
- **Tag manager** (⚙️ Manage tags…): rename, merge and delete tags across all contacts (archived included); spots the same tag stored with different capitals ("Author"/"author", one-click **unify**) and look-alike tags ("ARM research"/"ARMResearch").
- **Fixed top area**: the title, stat boxes, search bar and buttons stay in place; only the contact list (or task list) scrolls, inside its own box, and in Table view the column titles stay visible at the top of that box.

### Changed
- Requires **Node.js 20 or newer** (LTS recommended). The database component was updated (sqlite3 6), which removes the security warnings npm showed during installation. On Linux this needs a 2024+ system (e.g. Ubuntu 24.04); older Linux should stay on 2.0.

### Fixed
- **"Select all" selected hidden contacts too** (including archived ones and those hidden by a filter), so a bulk action could change contacts you couldn't see. It now selects only the contacts on screen.
- Bulk follow-up used an OK/Cancel pop-up where "Cancel" meant "unmark", so clearing follow-up in bulk was confusing. It now offers clear "Mark for follow-up" / "Clear follow-up" buttons.
- Open tasks without a due date were not shown anywhere in the Tasks view; they now have their own "No due date" group.
- Clicking "Need Follow-up" while a tag filter was set showed the full list, but the next refresh (or switching to Grid) silently re-applied the hidden tag filter. The stat boxes now clear the filters and the list stays consistent.
- The tag filter is no longer case-sensitive and lists each tag once, including tags used only on archived contacts.
- Tags can no longer contain commas (a comma now separates tags in the picker).


## 2.0.0 — October 2026

### New
- **Companies**: contacts linked to companies; click a company to filter.
- **Archive** contacts instead of deleting them; archived view.
- **Notes thread** per contact (multiple dated notes).
- **Document links** per contact (Google Docs / Drive or any URL).
- **Website** field on contacts.
- **Bulk actions**: archive, follow-up flag, add task, add/remove tags.
- CSV import auto-detects comma or semicolon separators and reads a `Website` column.

### Fixed
- Tags or company names containing an apostrophe (e.g. `O'Brien`) broke buttons; text can no longer be interpreted as code.
- Editing a note or interaction that contained a line break failed.
- Only web and email links are opened from website and document fields.
- Tag filter matched partial words (`lead` matched `leader`).
- Switching views or reloading dropped the active tag/search filter.

### Changed
- easyCRM now listens only on your own computer (127.0.0.1) and no longer accepts requests from other websites.
- New one-click installers and start files for Windows (`install.bat`, `start-easyCRM.bat`) and macOS/Linux (`install.sh`, `start.sh`, `start-easyCRM.command`).
- `npm run reset` works on Windows and asks for confirmation.
- The setup wizard was removed: the database is created automatically on first start.
- Requires Node.js 18 or newer (LTS recommended).

### Upgrading
Copy your existing `crm.db` into the new folder before the first start; it is migrated automatically.
