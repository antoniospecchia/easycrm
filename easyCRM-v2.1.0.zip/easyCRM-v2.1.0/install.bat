@echo off
REM easyCRM installer for Windows
cd /d "%~dp0"
echo.
echo =======================================
echo      easyCRM 2.1.0 - Installation
echo   Simple - Private - Local
echo =======================================
echo.
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo ERROR: Node.js is not installed.
    echo Install the LTS version from https://nodejs.org and run this file again.
    pause
    exit /b 1
)
for /f "tokens=*" %%i in ('node -v') do set NODE_VERSION=%%i
echo OK: Node.js %NODE_VERSION% found.
for /f "tokens=1 delims=v." %%m in ("%NODE_VERSION%") do set NODE_MAJOR=%%m
if %NODE_MAJOR% LSS 20 (
    echo ERROR: easyCRM needs Node.js 20 or newer. You have %NODE_VERSION%.
    echo Install the LTS version from https://nodejs.org and run this file again.
    pause
    exit /b 1
)
echo.
echo Installing components (this can take a minute)...
call npm install --omit=dev
if %errorlevel% neq 0 (
    echo.
    echo ERROR: Installation failed.
    echo Most often this means your Node.js version is too new or too old.
    echo Install the LTS version from https://nodejs.org and try again.
    pause
    exit /b 1
)
echo.
echo =======================================
echo   Installation complete!
echo   From now on, double-click start-easyCRM.bat
echo =======================================
echo.
set /p START="Start easyCRM now? (y/n): "
if /i "%START%"=="y" call start-easyCRM.bat
