#!/bin/bash
# easyCRM installer for macOS and Linux
cd "$(dirname "$0")" || exit 1
echo ""
echo "======================================="
echo "     easyCRM 2.1.0 - Installation"
echo "   Simple • Private • Local"
echo "======================================="
echo ""
if ! command -v node >/dev/null 2>&1; then
    echo "❌ Node.js is not installed."
    echo "Install the LTS version from https://nodejs.org and run this again."
    exit 1
fi
echo "✅ Node.js $(node -v) found."
NODE_MAJOR=$(node -p "process.versions.node.split('.')[0]")
if [ "$NODE_MAJOR" -lt 20 ]; then
    echo "❌ easyCRM needs Node.js 20 or newer. You have $(node -v)."
    echo "Install the LTS version from https://nodejs.org and run this again."
    exit 1
fi
echo "📦 Installing components (this can take a minute)..."
if ! npm install --omit=dev; then
    echo ""
    echo "❌ Installation failed."
    echo "Most often this means your Node.js version is too new or too old."
    echo "Install the LTS version from https://nodejs.org and try again."
    exit 1
fi
chmod +x start-easyCRM.command start.sh 2>/dev/null
echo ""
echo "======================================="
echo "  ✅ Installation complete!"
echo "  From now on run ./start.sh"
echo "  (on a Mac you can double-click start-easyCRM.command)"
echo "======================================="
echo ""
read -r -p "Start easyCRM now? (y/n): " response
if [[ "$response" =~ ^[Yy]$ ]]; then
    ./start.sh
fi
