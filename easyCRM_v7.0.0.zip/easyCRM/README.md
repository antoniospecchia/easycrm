# easyCRM v7.0.0 Update

**Date:** January 5, 2026

## What's New

### 1. Overdue Logic Fix
- **Before:** Tasks due today appeared in both "Overdue" AND "Today" sections
- **After:** "Overdue" now only shows tasks due **yesterday or earlier**
- Today's tasks appear only in "Today"

### 2. Branding Update
- Renamed from "Local CRM" to "easyCRM"
- New brand color: #9b8ead (soft purple)

### 3. Archive Feature
- Archive contacts to hide them from the main view
- Archived contacts are excluded from "All Contacts" count
- View archived contacts by clicking the new "Archived" stat box
- Unarchive button to restore contacts

### 4. Contact Modal Redesign
- Cleaner layout: Name → Tags (right side) → Contact info → Quick Actions
- Removed the non-editable Notes field
- Notes section now shows editable timestamped notes

### 5. Dashboard "Archived" Counter
- New 4th stat box showing count of archived contacts
- Click to view all archived contacts

### 6. Default View: Table
- Table view is now the default when loading the app
- Grid view still available via toggle

---

## Installation

### Option A: Fresh Install
1. Extract all files to your project folder
2. Run `npm install` (if needed)
3. Run `node server.js`
4. Open `http://localhost:3000`

### Option B: Update Existing Installation
1. **BACKUP your `crm.db` file first!**
2. Replace `index.html`, `app.js`, and `server.js` with the new versions
3. Keep your existing `crm.db` — the server will automatically add the new `archived` column
4. Restart your server

---

## Files Included

| File | Description |
|------|-------------|
| `index.html` | Frontend HTML/CSS |
| `app.js` | Frontend JavaScript |
| `server.js` | Backend Node.js server |
| `README.md` | This file |

**Note:** `crm.db` is NOT included — your existing database will be preserved and upgraded automatically.

---

## Version History

- **v7.0.0** (2026-01-05): Archive feature, overdue fix, branding, UI improvements
- **v6.0.0** (2025-12-11): Enhanced tag management
- **v4.0.0** (2025-12-09): Clean rebuild, stable milestone
