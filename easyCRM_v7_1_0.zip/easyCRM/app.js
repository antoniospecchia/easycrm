/**
 * easyCRM Frontend - Version 7.1.0
 * Added: Document links feature (Google Docs/Drive links per contact)
 * Date: January 7, 2026
 */

const API_URL = 'http://localhost:3000/api';

// Global state
let currentContacts = [];
let currentContactId = null;
let currentView = 'table'; // Change #6: Default to table view
let selectedContacts = new Set();
let followUpOnly = false;
let archivedOnly = false; // Change #3/#5: Track archived view
let allTags = new Set();

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    loadStats();
    loadContacts();
    
    // Refresh stats every 30 seconds
    setInterval(loadStats, 30000);
});

// Load dashboard statistics
async function loadStats() {
    try {
        const response = await fetch(`${API_URL}/stats`);
        const stats = await response.json();
        
        document.getElementById('stat-contacts').textContent = stats.totalContacts || 0;
        document.getElementById('stat-tasks').textContent = stats.tasksDue || 0;
        document.getElementById('stat-followup').textContent = stats.needsFollowUp || 0;
        document.getElementById('stat-archived').textContent = stats.archivedContacts || 0;
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// Load contacts
async function loadContacts() {
    try {
        const response = await fetch(`${API_URL}/contacts`);
        const contacts = await response.json();
        currentContacts = contacts;
        
        // Collect all tags
        allTags.clear();
        contacts.forEach(contact => {
            if (contact.tags) {
                contact.tags.split(',').forEach(tag => allTags.add(tag.trim()));
            }
        });
        
        // Filter based on current view mode
        let filtered = contacts;
        
        if (archivedOnly) {
            // Show only archived contacts
            filtered = contacts.filter(c => c.archived === 1);
        } else {
            // Show only active (non-archived) contacts
            filtered = contacts.filter(c => c.archived !== 1);
            
            if (followUpOnly) {
                filtered = filtered.filter(c => c.needs_follow_up === 1);
            }
        }
        
        displayContacts(filtered);
        populateTagFilter(contacts.filter(c => c.archived !== 1)); // Only show tags from active contacts
    } catch (error) {
        console.error('Error loading contacts:', error);
        showNotification('Error loading contacts', 'error');
    }
}

// Display contacts based on current view
function displayContacts(contacts) {
    const container = document.getElementById('contacts-container');
    
    if (currentView === 'table') {
        container.className = '';
        displayTable(contacts);
    } else {
        container.className = 'grid-view';
        displayGrid(contacts);
    }
}

// Display contacts in grid view - ENHANCED WITH TAGS
function displayGrid(contacts) {
    const container = document.getElementById('contacts-container');
    
    if (!contacts || contacts.length === 0) {
        container.innerHTML = '<div class="empty-state">No contacts found</div>';
        return;
    }
    
    container.innerHTML = contacts.map(contact => {
        const needsFollowUp = contact.needs_follow_up === 1;
        const tags = contact.tags ? contact.tags.split(',').map(t => t.trim()) : [];
        
        return `
            <div class="contact-card ${needsFollowUp ? 'needs-followup' : ''}" onclick="showContactDetail(${contact.id})">
                <input type="checkbox" class="contact-checkbox" 
                    data-id="${contact.id}"
                    ${selectedContacts.has(contact.id) ? 'checked' : ''}
                    onclick="event.stopPropagation(); toggleSelection(${contact.id})">
                <h3>${escapeHtml(contact.name)}</h3>
                ${tags.length > 0 ? `
                    <div class="contact-tags" onclick="event.stopPropagation()">
                        ${tags.map(tag => `<span class="tag" onclick="filterByTag('${tag}')">${escapeHtml(tag)}</span>`).join('')}
                    </div>
                ` : ''}
                ${contact.email ? `<p>📧 <a href="mailto:${contact.email}" onclick="event.stopPropagation()">${escapeHtml(contact.email)}</a></p>` : ''}
                ${contact.phone ? `<p>📱 <a href="tel:${contact.phone}" onclick="event.stopPropagation()">${escapeHtml(contact.phone)}</a></p>` : ''}
                ${contact.company ? `<p>🏢 ${escapeHtml(contact.company)}</p>` : ''}
                <p>📅 Last: ${contact.last_contact ? new Date(contact.last_contact).toLocaleDateString() : 'Never'}</p>
                <div class="card-actions" onclick="event.stopPropagation()">
                    <button onclick="openEditModal(${contact.id})" class="btn-small" title="Edit">✏️</button>
                    <button onclick="quickAddTask(${contact.id})" class="btn-small" title="Add Task">✅</button>
                    <button onclick="quickAddTag(${contact.id})" class="btn-small" title="Add Tag">🏷️</button>
                    <button onclick="toggleFollowUp(${contact.id})" class="btn-small" title="${needsFollowUp ? 'Unmark' : 'Mark'} Follow-up">${needsFollowUp ? '🔕' : '🔔'}</button>
                    <button onclick="deleteContact(${contact.id})" class="btn-small btn-danger" title="Delete">🗑️</button>
                </div>
            </div>
        `;
    }).join('');
}

// Display contacts in table view - ENHANCED WITH TAGS
function displayTable(contacts) {
    const container = document.getElementById('contacts-container');
    
    if (!contacts || contacts.length === 0) {
        container.innerHTML = '<div class="empty-state">No contacts found</div>';
        return;
    }
    
    let html = `
        <table class="contacts-table">
            <thead>
                <tr>
                    <th><input type="checkbox" onclick="selectAll(this)"></th>
                    <th>Name</th>
                    <th>Tags</th>
                    <th>Email</th>
                    <th>Company</th>
                    <th>Last Interaction</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
    `;
    
    contacts.forEach(contact => {
        const needsFollowUp = contact.needs_follow_up === 1;
        const nameStyle = needsFollowUp ? 'color: #ffa436; font-weight: bold;' : '';
        const tags = contact.tags ? contact.tags.split(',').map(t => t.trim()) : [];
        
        html += `
            <tr onclick="showContactDetail(${contact.id})" style="cursor:pointer;" class="${needsFollowUp ? 'needs-followup' : ''}">
                <td onclick="event.stopPropagation()">
                    <input type="checkbox" class="contact-checkbox" 
                        data-id="${contact.id}"
                        ${selectedContacts.has(contact.id) ? 'checked' : ''}
                        onclick="toggleSelection(${contact.id})">
                </td>
                <td style="${nameStyle}">${escapeHtml(contact.name)}</td>
                <td onclick="event.stopPropagation()">
                    ${tags.map(tag => `<span class="tag-small" onclick="filterByTag('${tag}')">${escapeHtml(tag)}</span>`).join('')}
                </td>
                <td>${contact.email ? `<a href="mailto:${escapeHtml(contact.email)}" onclick="event.stopPropagation()">${escapeHtml(contact.email)}</a>` : ''}</td>
                <td>${escapeHtml(contact.company) || ''}</td>
                <td>${contact.last_contact ? new Date(contact.last_contact).toLocaleDateString() : 'Never'}</td>
                <td onclick="event.stopPropagation()">
                    <button onclick="openEditModal(${contact.id})" class="btn-small" title="Edit">✏️</button>
                    <button onclick="quickAddTask(${contact.id})" class="btn-small" title="Add Task">✅</button>
                    <button onclick="quickAddTag(${contact.id})" class="btn-small" title="Add Tag">🏷️</button>
                    <button onclick="toggleFollowUp(${contact.id})" class="btn-small" title="${needsFollowUp ? 'Unmark' : 'Mark'} Follow-up">${needsFollowUp ? '🔕' : '🔔'}</button>
                    <button onclick="deleteContact(${contact.id})" class="btn-small btn-danger" title="Delete">🗑️</button>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// Quick add tag
async function quickAddTag(contactId) {
    const contact = currentContacts.find(c => c.id === contactId);
    const currentTags = contact.tags ? contact.tags.split(',').map(t => t.trim()) : [];
    
    // Show existing tags and let user add new one
    let message = 'Current tags: ' + (currentTags.length > 0 ? currentTags.join(', ') : 'None') + '\n\n';
    message += 'Add new tag (or choose from: ' + Array.from(allTags).join(', ') + '):';
    
    const newTag = prompt(message);
    if (!newTag) return;
    
    // Add new tag to existing tags
    if (!currentTags.includes(newTag.trim())) {
        currentTags.push(newTag.trim());
    }
    
    // Update contact
    const updatedTags = currentTags.join(',');
    
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                ...contact,
                tags: updatedTags
            })
        });
        
        if (response.ok) {
            showNotification('Tag added successfully', 'success');
            loadContacts();
            if (currentContactId === contactId) {
                showContactDetail(contactId);
            }
        }
    } catch (error) {
        showNotification('Error adding tag', 'error');
    }
}

// Delete tag from contact
async function deleteTag(contactId, tagToDelete) {
    const contact = currentContacts.find(c => c.id === contactId);
    if (!contact) return;
    
    const currentTags = contact.tags ? contact.tags.split(',').map(t => t.trim()) : [];
    const updatedTags = currentTags.filter(t => t !== tagToDelete).join(',');
    
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                ...contact,
                tags: updatedTags
            })
        });
        
        if (response.ok) {
            showNotification('Tag removed', 'success');
            loadContacts();
            if (currentContactId === contactId) {
                showContactDetail(contactId);
            }
        }
    } catch (error) {
        showNotification('Error removing tag', 'error');
    }
}

// Filter by tag
function filterByTag(tag) {
    document.getElementById('tag-filter').value = tag;
    searchContacts();
}

// Switch view between grid and table
function switchView(view) {
    currentView = view;
    
    // Update button states
    document.getElementById('btn-grid').classList.toggle('active', view === 'grid');
    document.getElementById('btn-table').classList.toggle('active', view === 'table');
    
    // Re-display contacts respecting all filters
    let filtered = currentContacts;
    
    if (archivedOnly) {
        filtered = currentContacts.filter(c => c.archived === 1);
    } else {
        filtered = currentContacts.filter(c => c.archived !== 1);
        if (followUpOnly) {
            filtered = filtered.filter(c => c.needs_follow_up === 1);
        }
    }
    
    displayContacts(filtered);
}

// Show all contacts (from stat box)
function showAllContacts() {
    followUpOnly = false;
    archivedOnly = false;
    document.getElementById('main-view').style.display = 'block';
    document.getElementById('tasks-view').style.display = 'none';
    loadContacts();
}

// Show only follow-up contacts (from stat box)
function showFollowUpContacts() {
    followUpOnly = true;
    archivedOnly = false;
    document.getElementById('main-view').style.display = 'block';
    document.getElementById('tasks-view').style.display = 'none';
    
    const filtered = currentContacts.filter(c => c.needs_follow_up === 1 && c.archived !== 1);
    displayContacts(filtered);
    showNotification(`Showing ${filtered.length} contacts needing follow-up`, 'info');
}

// Show archived contacts (from stat box)
function showArchivedContacts() {
    followUpOnly = false;
    archivedOnly = true;
    document.getElementById('main-view').style.display = 'block';
    document.getElementById('tasks-view').style.display = 'none';
    
    const filtered = currentContacts.filter(c => c.archived === 1);
    displayContacts(filtered);
    showNotification(`Showing ${filtered.length} archived contacts`, 'info');
}

// Archive contact
async function archiveContact(contactId) {
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}/archive`, {
            method: 'POST'
        });
        
        if (response.ok) {
            showNotification('Contact archived', 'success');
            closeModal('contact-detail-modal');
            loadContacts();
            loadStats();
        }
    } catch (error) {
        showNotification('Error archiving contact', 'error');
    }
}

// Unarchive contact
async function unarchiveContact(contactId) {
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}/unarchive`, {
            method: 'POST'
        });
        
        if (response.ok) {
            showNotification('Contact restored', 'success');
            closeModal('contact-detail-modal');
            loadContacts();
            loadStats();
        }
    } catch (error) {
        showNotification('Error restoring contact', 'error');
    }
}

// Show tasks view (from stat box)
function showTasksView() {
    document.getElementById('main-view').style.display = 'none';
    document.getElementById('tasks-view').style.display = 'block';
    loadTasks();
}

// Load and display tasks
async function loadTasks() {
    try {
        const response = await fetch(`${API_URL}/tasks`);
        const tasks = await response.json();
        
        const container = document.getElementById('tasks-container');
        
        if (tasks.length === 0) {
            container.innerHTML = '<div class="empty-state">No tasks found</div>';
            return;
        }
        
        // Get today's date as YYYY-MM-DD string for reliable comparison
        const now = new Date();
        const todayStr = now.toISOString().split('T')[0]; // "2026-01-05"
        
        // Group tasks - Overdue is yesterday or earlier (not today)
        const overdue = tasks.filter(t => {
            if (!t.due_date || t.status !== 'pending') return false;
            const dueDateStr = t.due_date.split('T')[0]; // Handle both "2026-01-04" and "2026-01-04T00:00:00"
            return dueDateStr < todayStr;
        });
        
        const today = tasks.filter(t => {
            if (!t.due_date || t.status !== 'pending') return false;
            const dueDateStr = t.due_date.split('T')[0];
            return dueDateStr === todayStr;
        });
        
        const upcoming = tasks.filter(t => {
            if (!t.due_date || t.status !== 'pending') return false;
            const dueDateStr = t.due_date.split('T')[0];
            return dueDateStr > todayStr;
        });
        
        const completed = tasks.filter(t => t.status === 'completed');
        
        let html = '';
        
        if (overdue.length > 0) {
            html += '<h3 style="color: #d70022;">⚠️ Overdue</h3>';
            html += overdue.map(t => renderTask(t)).join('');
        }
        
        if (today.length > 0) {
            html += '<h3 style="color: #0060df;">📅 Today</h3>';
            html += today.map(t => renderTask(t)).join('');
        }
        
        if (upcoming.length > 0) {
            html += '<h3>📌 Upcoming</h3>';
            html += upcoming.map(t => renderTask(t)).join('');
        }
        
        if (completed.length > 0) {
            html += '<h3 style="color: #058b00;">✅ Completed</h3>';
            html += completed.map(t => renderTask(t)).join('');
        }
        
        container.innerHTML = html;
    } catch (error) {
        console.error('Error loading tasks:', error);
    }
}

// Render single task
function renderTask(task) {
    return `
        <div class="task-item" onclick="showContactFromTask(${task.contact_id})">
            <strong>${escapeHtml(task.title)}</strong>
            ${task.contact_name ? ` - ${escapeHtml(task.contact_name)}` : ''}
            <br>
            <small>${task.due_date ? `Due: ${new Date(task.due_date).toLocaleDateString()}` : 'No due date'}</small>
            <div class="task-actions" onclick="event.stopPropagation()">
                <button onclick="openEditTaskModal(${task.id})" class="btn-small">✏️</button>
                ${task.status === 'pending' 
                    ? `<button onclick="completeTask(${task.id})" class="btn-small">✔️</button>`
                    : `<button onclick="reopenTask(${task.id})" class="btn-small">↩️</button>`
                }
                <button onclick="deleteTask(${task.id})" class="btn-small btn-danger">🗑️</button>
            </div>
        </div>
    `;
}

// Show contact from task
async function showContactFromTask(contactId) {
    if (!contactId) return;
    showAllContacts();
    setTimeout(() => showContactDetail(contactId), 100);
}

// Show contact detail modal - ENHANCED WITH TAGS
async function showContactDetail(contactId) {
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}`);
        const data = await response.json();
        
        currentContactId = contactId;
        
        const tags = data.contact.tags ? data.contact.tags.split(',').map(t => t.trim()) : [];
        const isArchived = data.contact.archived === 1;
        
        document.getElementById('detail-name').textContent = data.contact.name;
        
        // Display tags in detail view with delete capability
        document.getElementById('detail-tags').innerHTML = tags.length > 0 
            ? tags.map(tag => `<span class="tag-deletable"><span class="tag-text">${escapeHtml(tag)}</span><span class="tag-delete" onclick="deleteTag(${contactId}, '${escapeHtml(tag)}')">×</span></span>`).join('')
            : '<span style="color: #999;">No tags</span>';
        
        document.getElementById('detail-email').innerHTML = data.contact.email 
            ? `<a href="mailto:${data.contact.email}">${data.contact.email}</a>` 
            : 'N/A';
        document.getElementById('detail-phone').innerHTML = data.contact.phone 
            ? `<a href="tel:${data.contact.phone}">${data.contact.phone}</a>` 
            : 'N/A';
        document.getElementById('detail-company').textContent = data.contact.company || 'N/A';
        
        // Update archive button based on contact status
        const archiveBtn = document.getElementById('archive-btn');
        if (isArchived) {
            archiveBtn.textContent = '📤 Unarchive';
            archiveBtn.onclick = () => unarchiveContact(currentContactId);
        } else {
            archiveBtn.textContent = '📦 Archive';
            archiveBtn.onclick = () => archiveContact(currentContactId);
        }
        
        // Display tasks
        const tasksHtml = data.tasks.length > 0 ? data.tasks.map(t => `
            <div class="detail-item">
                <strong>${escapeHtml(t.title)}</strong> - ${t.status}
                <div class="detail-item-actions">
                    <button onclick="openEditTaskModal(${t.id})" class="btn-small">✏️</button>
                </div>
            </div>
        `).join('') : '<p>No tasks</p>';
        document.getElementById('detail-tasks').innerHTML = tasksHtml;
        
        // Display interactions
        const interactionsHtml = data.interactions.length > 0 ? data.interactions.map(i => `
            <div class="detail-item">
                <strong>${i.type}</strong> - ${new Date(i.date).toLocaleDateString()}
                ${i.notes ? `<br>${escapeHtml(i.notes)}` : ''}
                <div class="detail-item-actions">
                    <button onclick="editInteraction(${i.id}, '${i.type}', '${escapeHtml(i.notes || '')}')" class="btn-small">✏️</button>
                    <button onclick="deleteInteraction(${i.id})" class="btn-small btn-danger">🗑️</button>
                </div>
            </div>
        `).join('') : '<p>No interactions</p>';
        document.getElementById('detail-interactions').innerHTML = interactionsHtml;
        
        // Display notes (using new element ID)
        const notesHtml = data.notes.length > 0 ? data.notes.map(n => `
            <div class="detail-item">
                ${escapeHtml(n.content)}
                <div class="detail-item-actions">
                    <button onclick="editNote(${n.id}, '${escapeHtml(n.content)}')" class="btn-small">✏️</button>
                    <button onclick="deleteNote(${n.id})" class="btn-small btn-danger">🗑️</button>
                </div>
            </div>
        `).join('') : '<p>No notes</p>';
        document.getElementById('detail-notes-list').innerHTML = notesHtml;
        
        // Display documents (from API)
        const docs = data.documents || [];
        const documentsHtml = docs.length > 0 ? docs.map(d => `
            <div class="detail-item">
                <a href="${escapeHtml(d.url)}" target="_blank" rel="noopener noreferrer">📄 ${escapeHtml(d.title)}</a>
                <small style="color: #999; margin-left: 8px;">${new Date(d.created_at).toLocaleDateString()}</small>
                <div class="detail-item-actions">
                    <button onclick="openEditDocumentModal(${d.id}, '${escapeHtml(d.title)}', '${escapeHtml(d.url)}')" class="btn-small">✏️</button>
                    <button onclick="deleteDocument(${d.id})" class="btn-small btn-danger">🗑️</button>
                </div>
            </div>
        `).join('') : '<p>No documents</p>';
        document.getElementById('detail-documents').innerHTML = documentsHtml;
        
        openModal('contact-detail-modal');
    } catch (error) {
        console.error('Error loading contact:', error);
        showNotification('Error loading contact details', 'error');
    }
}

// FIXED: Open edit contact modal (closes detail modal first)
async function openEditModal(contactId) {
    // Close contact detail modal if it's open
    closeModal('contact-detail-modal');
    
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}`);
        const data = await response.json();
        const contact = data.contact;
        
        document.getElementById('edit-id').value = contact.id;
        document.getElementById('edit-name').value = contact.name;
        document.getElementById('edit-email').value = contact.email || '';
        document.getElementById('edit-phone').value = contact.phone || '';
        document.getElementById('edit-company').value = contact.company || '';
        document.getElementById('edit-tags').value = contact.tags || '';
        document.getElementById('edit-notes').value = contact.notes || '';
        
        // Show tag suggestions
        const tagSuggestions = Array.from(allTags).join(', ');
        document.getElementById('tag-suggestions').textContent = tagSuggestions ? `Existing tags: ${tagSuggestions}` : '';
        
        openModal('edit-contact-modal');
    } catch (error) {
        console.error('Error loading contact:', error);
        showNotification('Error loading contact', 'error');
    }
}

// FIXED: Save edited contact (and reopen detail if needed)
async function saveContact() {
    const contactId = document.getElementById('edit-id').value;
    const wasDetailOpen = currentContactId == contactId;
    
    // Get the current contact to compare notes
    const currentContact = currentContacts.find(c => c.id == contactId);
    const oldNotes = currentContact ? currentContact.notes : '';
    const newNotes = document.getElementById('edit-notes').value;
    
    const data = {
        name: document.getElementById('edit-name').value,
        email: document.getElementById('edit-email').value,
        phone: document.getElementById('edit-phone').value,
        company: document.getElementById('edit-company').value,
        tags: document.getElementById('edit-tags').value,
        notes: newNotes
    };
    
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            // If notes changed, also add to notes table
            if (newNotes && newNotes !== oldNotes) {
                await fetch(`${API_URL}/notes`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        contact_id: contactId,
                        content: newNotes
                    })
                });
            }
            
            showNotification('Contact updated successfully', 'success');
            closeModal('edit-contact-modal');
            loadContacts();
            loadStats();
            
            // Reopen contact detail if it was open
            if (wasDetailOpen) {
                setTimeout(() => showContactDetail(contactId), 300);
            }
        }
    } catch (error) {
        showNotification('Error updating contact', 'error');
    }
}

// Add new contact
async function addContact(event) {
    event.preventDefault();
    
    const data = {
        name: document.getElementById('add-name').value,
        email: document.getElementById('add-email').value,
        phone: document.getElementById('add-phone').value,
        company: document.getElementById('add-company').value,
        tags: document.getElementById('add-tags').value,
        notes: document.getElementById('add-notes').value
    };
    
    try {
        const response = await fetch(`${API_URL}/contacts`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            const result = await response.json();
            
            // If notes were provided, also add to notes table
            if (data.notes) {
                await fetch(`${API_URL}/notes`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        contact_id: result.id,
                        content: data.notes
                    })
                });
            }
            
            showNotification('Contact added successfully', 'success');
            document.getElementById('add-contact-form').reset();
            closeModal('add-contact-modal');
            loadContacts();
            loadStats();
        }
    } catch (error) {
        showNotification('Error adding contact', 'error');
    }
}

// Delete contact
async function deleteContact(contactId) {
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('Contact deleted', 'success');
            loadContacts();
            loadStats();
        }
    } catch (error) {
        showNotification('Error deleting contact', 'error');
    }
}

// Toggle follow-up status
async function toggleFollowUp(contactId) {
    const contact = currentContacts.find(c => c.id === contactId);
    const endpoint = contact?.needs_follow_up === 1 
        ? `/contacts/unmark-followup/${contactId}`
        : `/contacts/mark-followup/${contactId}`;
    
    try {
        const response = await fetch(`${API_URL}${endpoint}`, {
            method: 'POST'
        });
        
        if (response.ok) {
            showNotification(contact?.needs_follow_up === 1 ? 'Follow-up removed' : 'Marked for follow-up', 'success');
            loadContacts();
            loadStats();
        }
    } catch (error) {
        showNotification('Error updating follow-up status', 'error');
    }
}

// Quick add task - now opens the modal instead of using prompts
function quickAddTask(contactId) {
    document.getElementById('task-contact-id').value = contactId;
    document.getElementById('task-title').value = '';
    document.getElementById('task-description').value = '';
    document.getElementById('task-due-date').value = '';
    document.getElementById('task-priority').value = 'medium';
    openModal('add-task-modal');
}

// Open add task modal
function openAddTaskModal(contactId = null) {
    if (contactId) {
        document.getElementById('task-contact-id').value = contactId;
    }
    openModal('add-task-modal');
}

// Save new task
async function saveTask(event) {
    event.preventDefault();
    
    const data = {
        contact_id: document.getElementById('task-contact-id').value || currentContactId,
        title: document.getElementById('task-title').value,
        description: document.getElementById('task-description').value,
        due_date: document.getElementById('task-due-date').value || null,
        priority: document.getElementById('task-priority').value
    };
    
    try {
        const response = await fetch(`${API_URL}/tasks`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            showNotification('Task added successfully', 'success');
            document.getElementById('add-task-form').reset();
            closeModal('add-task-modal');
            loadStats();
            if (currentContactId) {
                showContactDetail(currentContactId);
            }
        }
    } catch (error) {
        showNotification('Error adding task', 'error');
    }
}

// Open edit task modal
async function openEditTaskModal(taskId) {
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}`);
        const task = await response.json();
        
        document.getElementById('edit-task-id').value = task.id;
        document.getElementById('edit-task-title').value = task.title;
        document.getElementById('edit-task-description').value = task.description || '';
        document.getElementById('edit-task-due-date').value = task.due_date ? task.due_date.split('T')[0] : '';
        document.getElementById('edit-task-priority').value = task.priority;
        document.getElementById('edit-task-status').value = task.status;
        
        openModal('edit-task-modal');
    } catch (error) {
        showNotification('Error loading task', 'error');
    }
}

// Save edited task
async function saveEditedTask(event) {
    event.preventDefault();
    
    const taskId = document.getElementById('edit-task-id').value;
    const data = {
        title: document.getElementById('edit-task-title').value,
        description: document.getElementById('edit-task-description').value,
        due_date: document.getElementById('edit-task-due-date').value || null,
        priority: document.getElementById('edit-task-priority').value,
        status: document.getElementById('edit-task-status').value
    };
    
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            showNotification('Task updated', 'success');
            closeModal('edit-task-modal');
            loadTasks();
            loadStats();
            if (currentContactId) {
                showContactDetail(currentContactId);
            }
        }
    } catch (error) {
        showNotification('Error updating task', 'error');
    }
}

// Complete task
async function completeTask(taskId) {
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}/status`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: 'completed' })
        });
        
        if (response.ok) {
            showNotification('Task completed', 'success');
            loadTasks();
            loadStats();
        }
    } catch (error) {
        showNotification('Error completing task', 'error');
    }
}

// Reopen task
async function reopenTask(taskId) {
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}/status`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: 'pending' })
        });
        
        if (response.ok) {
            showNotification('Task reopened', 'success');
            loadTasks();
            loadStats();
        }
    } catch (error) {
        showNotification('Error reopening task', 'error');
    }
}

// Delete task
async function deleteTask(taskId) {
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('Task deleted', 'success');
            loadTasks();
            loadStats();
        }
    } catch (error) {
        showNotification('Error deleting task', 'error');
    }
}

// Edit interaction
async function editInteraction(id, type, notes) {
    const newType = prompt('Type:', type);
    const newNotes = prompt('Notes:', notes.replace(/\\'/g, "'"));
    
    if (newType === null) return;
    
    try {
        const response = await fetch(`${API_URL}/interactions/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type: newType, notes: newNotes })
        });
        
        if (response.ok) {
            showNotification('Interaction updated', 'success');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error updating interaction', 'error');
    }
}

// Delete interaction
async function deleteInteraction(id) {
    try {
        const response = await fetch(`${API_URL}/interactions/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('Interaction deleted', 'success');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error deleting interaction', 'error');
    }
}

// Edit note
async function editNote(id, content) {
    const newContent = prompt('Edit note:', content.replace(/\\'/g, "'"));
    
    if (newContent === null) return;
    
    try {
        const response = await fetch(`${API_URL}/notes/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content: newContent })
        });
        
        if (response.ok) {
            showNotification('Note updated', 'success');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error updating note', 'error');
    }
}

// Delete note
async function deleteNote(id) {
    try {
        const response = await fetch(`${API_URL}/notes/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('Note deleted', 'success');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error deleting note', 'error');
    }
}

// Log interaction
async function logInteraction() {
    const type = document.getElementById('log-type').value;
    const notes = document.getElementById('log-notes').value;
    
    try {
        const response = await fetch(`${API_URL}/interactions`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contact_id: currentContactId,
                type: type,
                notes: notes
            })
        });
        
        if (response.ok) {
            showNotification('Interaction logged', 'success');
            document.getElementById('log-type').value = 'call';
            document.getElementById('log-notes').value = '';
            closeModal('log-interaction-modal');
            showContactDetail(currentContactId);
            loadContacts();
        }
    } catch (error) {
        showNotification('Error logging interaction', 'error');
    }
}

// Add note
async function addNote() {
    const content = document.getElementById('add-note-content').value;
    
    if (!content) return;
    
    try {
        const response = await fetch(`${API_URL}/notes`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contact_id: currentContactId,
                content: content
            })
        });
        
        if (response.ok) {
            showNotification('Note added', 'success');
            document.getElementById('add-note-content').value = '';
            closeModal('add-note-modal');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error adding note', 'error');
    }
}

// Add document link
async function addDocument() {
    const title = document.getElementById('doc-title').value.trim();
    const url = document.getElementById('doc-url').value.trim();
    
    if (!title || !url) {
        showNotification('Please fill in both title and URL', 'warning');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/documents`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contact_id: currentContactId,
                title: title,
                url: url
            })
        });
        
        if (response.ok) {
            showNotification('Document added', 'success');
            document.getElementById('doc-title').value = '';
            document.getElementById('doc-url').value = '';
            closeModal('add-document-modal');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error adding document', 'error');
    }
}

// Open edit document modal
function openEditDocumentModal(docId, title, url) {
    document.getElementById('edit-doc-id').value = docId;
    document.getElementById('edit-doc-title').value = title;
    document.getElementById('edit-doc-url').value = url;
    
    openModal('edit-document-modal');
}

// Save edited document
async function saveEditedDocument() {
    const docId = document.getElementById('edit-doc-id').value;
    const title = document.getElementById('edit-doc-title').value.trim();
    const url = document.getElementById('edit-doc-url').value.trim();
    
    if (!title || !url) {
        showNotification('Please fill in both title and URL', 'warning');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/documents/${docId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title: title, url: url })
        });
        
        if (response.ok) {
            showNotification('Document updated', 'success');
            closeModal('edit-document-modal');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error updating document', 'error');
    }
}

// Delete document
async function deleteDocument(docId) {
    if (!confirm('Delete this document link?')) return;
    
    try {
        const response = await fetch(`${API_URL}/documents/${docId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('Document deleted', 'success');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error deleting document', 'error');
    }
}

// Toggle selection for bulk operations
function toggleSelection(contactId) {
    if (selectedContacts.has(contactId)) {
        selectedContacts.delete(contactId);
    } else {
        selectedContacts.add(contactId);
    }
    updateBulkBar();
}

// Select all contacts
function selectAll(checkbox) {
    if (checkbox.checked) {
        currentContacts.forEach(c => selectedContacts.add(c.id));
    } else {
        selectedContacts.clear();
    }
    
    document.querySelectorAll('.contact-checkbox').forEach(cb => {
        cb.checked = checkbox.checked;
    });
    
    updateBulkBar();
}

// Update bulk actions bar
function updateBulkBar() {
    const bar = document.getElementById('bulk-actions');
    if (selectedContacts.size > 0) {
        bar.style.display = 'flex';
        document.getElementById('selected-count').textContent = selectedContacts.size;
    } else {
        bar.style.display = 'none';
    }
}

// Bulk delete
async function bulkDelete() {
    try {
        const response = await fetch(`${API_URL}/contacts/bulk-delete`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids: Array.from(selectedContacts) })
        });
        
        if (response.ok) {
            showNotification(`${selectedContacts.size} contacts deleted`, 'success');
            selectedContacts.clear();
            updateBulkBar();
            loadContacts();
            loadStats();
        }
    } catch (error) {
        showNotification('Error deleting contacts', 'error');
    }
}

// Bulk add tags
async function bulkAddTags() {
    const tags = prompt('Add tags to selected contacts (comma separated):');
    if (!tags) return;
    
    try {
        const response = await fetch(`${API_URL}/contacts/bulk-update-tags`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                ids: Array.from(selectedContacts),
                tags: tags,
                action: 'add'
            })
        });
        
        if (response.ok) {
            showNotification('Tags added to selected contacts', 'success');
            selectedContacts.clear();
            updateBulkBar();
            loadContacts();
        }
    } catch (error) {
        showNotification('Error adding tags', 'error');
    }
}

// Clear selection and reload
function clearSelectionAndReload() {
    selectedContacts.clear();
    updateBulkBar();
    loadContacts();
}

// Search and filter
function searchContacts() {
    const searchTerm = document.getElementById('search-input').value.toLowerCase();
    const tagFilter = document.getElementById('tag-filter').value;
    
    let filtered = currentContacts.filter(contact => {
        const matchesSearch = !searchTerm || 
            contact.name.toLowerCase().includes(searchTerm) ||
            (contact.email && contact.email.toLowerCase().includes(searchTerm)) ||
            (contact.company && contact.company.toLowerCase().includes(searchTerm));
        
        const matchesTag = !tagFilter || 
            (contact.tags && contact.tags.includes(tagFilter));
        
        const matchesFollowUp = !followUpOnly || contact.needs_follow_up === 1;
        
        // Respect archived filter
        const matchesArchived = archivedOnly ? contact.archived === 1 : contact.archived !== 1;
        
        return matchesSearch && matchesTag && matchesFollowUp && matchesArchived;
    });
    
    displayContacts(filtered);
}

// Populate tag filter
function populateTagFilter(contacts) {
    const tags = new Set();
    contacts.forEach(c => {
        if (c.tags) {
            c.tags.split(',').forEach(t => tags.add(t.trim()));
        }
    });
    
    const select = document.getElementById('tag-filter');
    const current = select.value;
    select.innerHTML = '<option value="">All Tags</option>';
    
    Array.from(tags).sort().forEach(tag => {
        const option = document.createElement('option');
        option.value = tag;
        option.textContent = tag;
        if (tag === current) option.selected = true;
        select.appendChild(option);
    });
}

// Export contacts
function exportContacts() {
    window.location.href = `${API_URL}/export/contacts`;
}

// Export backup
function exportBackup() {
    window.location.href = `${API_URL}/export/backup`;
}

// Import CSV
async function importCSV() {
    const fileInput = document.getElementById('import-file');
    const file = fileInput.files[0];
    
    if (!file) {
        showNotification('Please select a file', 'warning');
        return;
    }
    
    const text = await file.text();
    
    try {
        const response = await fetch(`${API_URL}/import/contacts`, {
            method: 'POST',
            headers: { 'Content-Type': 'text/csv' },
            body: text
        });
        
        const result = await response.json();
        showNotification(`Imported ${result.imported} contacts`, 'success');
        fileInput.value = '';
        closeModal('import-modal');
        loadContacts();
        loadStats();
    } catch (error) {
        showNotification('Import failed', 'error');
    }
}

// FIXED: Modal functions with proper centering
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.add('show');
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('show');
}

// Close modal on outside click
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.classList.remove('show');
    }
}

// Show notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Escape HTML
function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.toString().replace(/[&<>"']/g, m => map[m]);
}
