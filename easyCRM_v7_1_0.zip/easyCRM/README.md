# easyCRM v7.1.0

**Date:** January 7, 2026

---

## Upgrading from v7.0.0 (Existing Database)

**Your data is safe!** The new version simply adds a `documents` table — your existing contacts, tasks, notes, and interactions remain untouched.

### Upgrade Steps

1. **Stop the server** (Ctrl+C in terminal)

2. **Backup your database** (just in case):
   ```bash
   cp crm.db crm.db.backup
   ```

3. **Replace these 3 files** with the new versions:
   - `index.html`
   - `app.js`
   - `server.js`

4. **Keep your existing `crm.db`** — do NOT delete it

5. **Restart the server**:
   ```bash
   node server.js
   ```

6. **Done!** The server automatically creates the new `documents` table on startup. Your existing data is preserved.

### What happens technically?

The `server.js` contains this code that safely adds the new table:

```javascript
db.run(`
    CREATE TABLE IF NOT EXISTS documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        contact_id INTEGER,
        title TEXT NOT NULL,
        url TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
    )
`);
```

The `IF NOT EXISTS` means it only creates the table if it doesn't already exist — it never touches your existing tables.

---

## What's New in v7.1.0

### Document Links Feature
- **Add document links** to any contact (Google Docs, Drive, or any URL)
- Each document has a **title** (e.g., "Letter to CIPD") and **URL**
- **Edit and delete** document links
- Documents appear in a new **"Documents" section** at the bottom of the contact detail modal
- Stored in the database — persists with your data and included in backups

**Use case:** Link contracts, proposals, CVs, correspondence, or any relevant documents to contacts.

---

## Fresh Installation

### Prerequisites
- Node.js (v14 or higher)
- npm

### Steps

1. Extract all files to your project folder
2. Open terminal in the folder
3. Install dependencies:
   ```bash
   npm install express sqlite3 cors
   ```
4. Start the server:
   ```bash
   node server.js
   ```
5. Open your browser to: **http://localhost:3000**

---

## Features

| Feature | Description |
|---------|-------------|
| **Contacts** | Add, edit, delete, search contacts |
| **Tags** | Categorise contacts with tags, filter by tag |
| **Tasks** | Create tasks linked to contacts, track due dates |
| **Interactions** | Log calls, emails, meetings |
| **Notes** | Add timestamped notes to contacts |
| **Documents** | Link Google Docs/Drive files to contacts |
| **Archive** | Hide inactive contacts without deleting |
| **Follow-up** | Mark contacts needing follow-up |
| **Import/Export** | CSV import, JSON backup export |

---

## Files Included

| File | Description |
|------|-------------|
| `index.html` | Frontend HTML/CSS |
| `app.js` | Frontend JavaScript |
| `server.js` | Backend Node.js server |
| `crm.db` | SQLite database (created on first run, or keep your existing one) |
| `README.md` | This file |

---

## API Endpoints

### Contacts
- `GET /api/contacts` — List all contacts
- `GET /api/contacts/:id` — Get contact with tasks, interactions, notes, documents
- `POST /api/contacts` — Create contact
- `PUT /api/contacts/:id` — Update contact
- `DELETE /api/contacts/:id` — Delete contact

### Documents (NEW in v7.1.0)
- `POST /api/documents` — Add document link
- `PUT /api/documents/:id` — Update document
- `DELETE /api/documents/:id` — Delete document

### Tasks
- `GET /api/tasks` — List all tasks
- `POST /api/tasks` — Create task
- `PUT /api/tasks/:id` — Update task
- `DELETE /api/tasks/:id` — Delete task

### Interactions
- `POST /api/interactions` — Log interaction
- `PUT /api/interactions/:id` — Update interaction
- `DELETE /api/interactions/:id` — Delete interaction

### Notes
- `POST /api/notes` — Add note
- `PUT /api/notes/:id` — Update note
- `DELETE /api/notes/:id` — Delete note

### Other
- `GET /api/stats` — Dashboard statistics
- `GET /api/export/contacts` — Export contacts CSV
- `GET /api/export/backup` — Export full JSON backup (now includes documents)
- `POST /api/import/contacts` — Import contacts from CSV

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| **v7.1.0** | 2026-01-07 | Document links feature |
| v7.0.0 | 2026-01-05 | Archive feature, overdue fix, branding |
| v6.0.0 | 2025-12-11 | Enhanced tag management |
| v4.0.0 | 2025-12-09 | Clean rebuild, stable milestone |

---

## License

Open source — free to use and modify.
