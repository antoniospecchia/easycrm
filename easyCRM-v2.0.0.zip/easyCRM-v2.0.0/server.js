/**
 * easyCRM Server
 * Version: 2.0.0 (public release)
 * Date: October 2026
 * License: MIT
 */

const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
// Listen on this computer only, so nobody else on your network can open your CRM
const HOST = '127.0.0.1';

// Middleware
app.use(express.json());
app.use(express.text({ type: 'text/csv', limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Initialize SQLite database
const db = new sqlite3.Database(path.join(__dirname, 'crm.db'), (err) => {
    if (err) {
        console.error('Error opening database:', err);
    } else {
        console.log('Connected to SQLite database');
        initializeDatabase();
    }
});

// Initialize database tables
function initializeDatabase() {
    db.serialize(() => {
        // Contacts table with needs_follow_up and archived fields
        db.run(`
            CREATE TABLE IF NOT EXISTS contacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT,
                phone TEXT,
                company TEXT,
                notes TEXT,
                tags TEXT,
                last_contact DATE,
                needs_follow_up INTEGER DEFAULT 0,
                archived INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        
        // Add archived column if it doesn't exist (for existing databases)
        db.run(`ALTER TABLE contacts ADD COLUMN archived INTEGER DEFAULT 0`, (err) => {});

        // Add website column if it doesn't exist (for existing databases)
        db.run(`ALTER TABLE contacts ADD COLUMN website TEXT`, (err) => {});

        // Companies table
        db.run(`
            CREATE TABLE IF NOT EXISTS companies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Add company_id to contacts
        db.run(`ALTER TABLE contacts ADD COLUMN company_id INTEGER REFERENCES companies(id)`, (err) => {});

        // Tasks table
        db.run(`
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                contact_id INTEGER,
                title TEXT NOT NULL,
                description TEXT,
                due_date DATE,
                priority TEXT DEFAULT 'medium',
                status TEXT DEFAULT 'pending',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
            )
        `);

        // Interactions table
        db.run(`
            CREATE TABLE IF NOT EXISTS interactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                contact_id INTEGER,
                type TEXT NOT NULL,
                notes TEXT,
                date DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
            )
        `);

        // Notes table
        db.run(`
            CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                contact_id INTEGER,
                content TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
            )
        `);

        // Documents table (NEW in v7.1.0)
        db.run(`
            CREATE TABLE IF NOT EXISTS documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                contact_id INTEGER,
                title TEXT NOT NULL,
                url TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
            )
        `);

        console.log('Database tables initialized');
        
        // Run company migration after tables are ready
        migrateCompanyData();
    });
}

// One-time migration: move company text field to companies table + company_id FK
function migrateCompanyData() {
    // Check if any contacts need migration (have company text but no company_id)
    db.all(`SELECT DISTINCT TRIM(company) as company_name FROM contacts WHERE company IS NOT NULL AND TRIM(company) != '' AND company_id IS NULL`, (err, rows) => {
        if (err || !rows || rows.length === 0) return;
        
        console.log(`Migrating ${rows.length} unique company names...`);
        
        // Deduplicate case-insensitively: pick first occurrence as canonical
        const seen = new Map(); // lowercase -> canonical name
        rows.forEach(r => {
            const lower = r.company_name.toLowerCase();
            if (!seen.has(lower)) {
                seen.set(lower, r.company_name);
            }
        });
        
        let done = 0;
        const total = seen.size;
        
        seen.forEach((canonicalName, lowerName) => {
            // Insert company (ignore if already exists from previous partial migration)
            db.run(`INSERT OR IGNORE INTO companies (name) VALUES (?)`, [canonicalName], function(err) {
                // Now get the company id (whether just inserted or already existed)
                db.get(`SELECT id FROM companies WHERE name = ?`, [canonicalName], (err, company) => {
                    if (!company) { done++; return; }
                    // Update all contacts whose trimmed lowercase company matches
                    db.run(`UPDATE contacts SET company_id = ? WHERE LOWER(TRIM(company)) = ? AND company_id IS NULL`,
                        [company.id, lowerName], function() {
                            done++;
                            if (done === total) {
                                console.log(`Company migration complete: ${total} companies created`);
                            }
                        }
                    );
                });
            });
        });
    });
}

// Update follow-up flags based on last contact date
function updateFollowUpFlags() {
    const sql = `
        UPDATE contacts 
        SET needs_follow_up = CASE 
            WHEN last_contact IS NULL OR date(last_contact) < date('now', '-30 days') THEN 1 
            ELSE 0 
        END
    `;
    db.run(sql);
}

// ============ CONTACT ENDPOINTS ============

// Get all contacts
app.get('/api/contacts', (req, res) => {
    updateFollowUpFlags(); // Update flags before returning
    
    const search = req.query.search || '';
    const tag = req.query.tag || '';
    
    let sql = `
        SELECT c.*, co.name as company_name FROM contacts c
        LEFT JOIN companies co ON c.company_id = co.id
        WHERE (c.name LIKE ? OR c.email LIKE ? OR co.name LIKE ? OR c.notes LIKE ?)
    `;
    const params = [`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`];
    
    if (tag) {
        sql += ` AND c.tags LIKE ?`;
        params.push(`%${tag}%`);
    }
    
    sql += ` ORDER BY c.created_at DESC`;
    
    db.all(sql, params, (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// Get single contact with all related data
app.get('/api/contacts/:id', (req, res) => {
    const contactId = req.params.id;
    const response = {};
    
    db.get('SELECT c.*, co.name as company_name FROM contacts c LEFT JOIN companies co ON c.company_id = co.id WHERE c.id = ?', [contactId], (err, contact) => {
        if (err || !contact) {
            res.status(404).json({ error: 'Contact not found' });
            return;
        }
        response.contact = contact;
        
        db.all('SELECT * FROM tasks WHERE contact_id = ? ORDER BY due_date', [contactId], (err, tasks) => {
            response.tasks = tasks || [];
            
            db.all('SELECT * FROM interactions WHERE contact_id = ? ORDER BY date DESC', [contactId], (err, interactions) => {
                response.interactions = interactions || [];
                
                db.all('SELECT * FROM notes WHERE contact_id = ? ORDER BY created_at DESC', [contactId], (err, notes) => {
                    response.notes = notes || [];
                    
                    db.all('SELECT * FROM documents WHERE contact_id = ? ORDER BY created_at DESC', [contactId], (err, documents) => {
                        response.documents = documents || [];
                        res.json(response);
                    });
                });
            });
        });
    });
});

// Create contact
app.post('/api/contacts', (req, res) => {
    const { name, email, phone, company, website, notes, tags } = req.body;
    const companyName = company ? company.trim() : null;
    
    const insertContact = (companyId) => {
        const sql = `
            INSERT INTO contacts (name, email, phone, company, company_id, website, notes, tags, last_contact)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        `;
        db.run(sql, [name, email, phone, companyName, companyId, website || null, notes, tags], function(err) {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            res.json({ id: this.lastID, message: 'Contact created successfully' });
        });
    };

    if (companyName) {
        // Find or create company
        db.get('SELECT id FROM companies WHERE LOWER(name) = LOWER(?)', [companyName], (err, row) => {
            if (row) {
                insertContact(row.id);
            } else {
                db.run('INSERT INTO companies (name) VALUES (?)', [companyName], function(err) {
                    insertContact(err ? null : this.lastID);
                });
            }
        });
    } else {
        insertContact(null);
    }
});

// Update contact
app.put('/api/contacts/:id', (req, res) => {
    const { name, email, phone, company, website, notes, tags } = req.body;
    const contactId = req.params.id;
    const companyName = company ? company.trim() : null;
    
    const updateContact = (companyId) => {
        const sql = `
            UPDATE contacts 
            SET name = ?, email = ?, phone = ?, company = ?, company_id = ?, website = ?, notes = ?, tags = ?, 
                updated_at = datetime('now')
            WHERE id = ?
        `;
        db.run(sql, [name, email, phone, companyName, companyId, website || null, notes, tags, contactId], function(err) {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            res.json({ message: 'Contact updated successfully' });
        });
    };

    if (companyName) {
        db.get('SELECT id FROM companies WHERE LOWER(name) = LOWER(?)', [companyName], (err, row) => {
            if (row) {
                updateContact(row.id);
            } else {
                db.run('INSERT INTO companies (name) VALUES (?)', [companyName], function(err) {
                    updateContact(err ? null : this.lastID);
                });
            }
        });
    } else {
        updateContact(null);
    }
});

// Delete contact
app.delete('/api/contacts/:id', (req, res) => {
    db.run('DELETE FROM contacts WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Contact deleted successfully' });
    });
});

// Mark contact for follow-up
app.post('/api/contacts/mark-followup/:id', (req, res) => {
    const sql = `UPDATE contacts SET needs_follow_up = 1, last_contact = date('now', '-31 days') WHERE id = ?`;
    
    db.run(sql, [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Contact marked for follow-up' });
    });
});

// Unmark contact follow-up
app.post('/api/contacts/unmark-followup/:id', (req, res) => {
    const sql = `UPDATE contacts SET needs_follow_up = 0, last_contact = datetime('now') WHERE id = ?`;
    
    db.run(sql, [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Follow-up removed' });
    });
});

// Archive contact
app.post('/api/contacts/:id/archive', (req, res) => {
    db.run('UPDATE contacts SET archived = 1 WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Contact archived' });
    });
});

// Unarchive contact
app.post('/api/contacts/:id/unarchive', (req, res) => {
    db.run('UPDATE contacts SET archived = 0 WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Contact unarchived' });
    });
});

// Bulk delete
app.post('/api/contacts/bulk-delete', (req, res) => {
    const { ids } = req.body;
    
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
        res.status(400).json({ error: 'No contact IDs provided' });
        return;
    }
    
    const placeholders = ids.map(() => '?').join(',');
    const sql = `DELETE FROM contacts WHERE id IN (${placeholders})`;
    
    db.run(sql, ids, function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: `${this.changes} contacts deleted successfully` });
    });
});

// Bulk update tags
app.post('/api/contacts/bulk-update-tags', (req, res) => {
    const { ids, tags, action } = req.body;
    
    if (!ids || !Array.isArray(ids)) {
        res.status(400).json({ error: 'No contact IDs provided' });
        return;
    }
    
    const placeholders = ids.map(() => '?').join(',');
    
    if (action === 'replace') {
        const sql = `UPDATE contacts SET tags = ? WHERE id IN (${placeholders})`;
        db.run(sql, [tags, ...ids], function(err) {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            res.json({ message: 'Tags updated' });
        });
    } else if (action === 'remove') {
        const tagsToRemove = tags.split(',').map(t => t.trim().toLowerCase()).filter(Boolean);
        db.all(`SELECT id, tags FROM contacts WHERE id IN (${placeholders})`, ids, (err, rows) => {
            if (err) { res.status(500).json({ error: err.message }); return; }
            let updated = 0;
            rows.forEach(row => {
                const existing = row.tags ? row.tags.split(',').map(t => t.trim()) : [];
                const filtered = existing.filter(t => !tagsToRemove.includes(t.toLowerCase())).join(',');
                db.run('UPDATE contacts SET tags = ? WHERE id = ?', [filtered, row.id], () => {
                    updated++;
                    if (updated === rows.length) {
                        res.json({ message: `Tags removed from ${updated} contacts` });
                    }
                });
            });
        });
    } else {
        // Add tags to existing ones
        db.all(`SELECT id, tags FROM contacts WHERE id IN (${placeholders})`, ids, (err, rows) => {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            const newTags = tags.split(',').map(t => t.trim()).filter(Boolean);
            let updated = 0;
            rows.forEach(row => {
                const existing = row.tags ? row.tags.split(',').map(t => t.trim()) : [];
                const merged = [...new Set([...existing, ...newTags])].join(',');
                db.run('UPDATE contacts SET tags = ? WHERE id = ?', [merged, row.id], () => {
                    updated++;
                    if (updated === rows.length) {
                        res.json({ message: `Tags added to ${updated} contacts` });
                    }
                });
            });
        });
    }
});

// Bulk archive
app.post('/api/contacts/bulk-archive', (req, res) => {
    const { ids } = req.body;
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
        res.status(400).json({ error: 'No contact IDs provided' });
        return;
    }
    const placeholders = ids.map(() => '?').join(',');
    db.run(`UPDATE contacts SET archived = 1 WHERE id IN (${placeholders})`, ids, function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: `${this.changes} contacts archived` });
    });
});

// Bulk toggle follow-up
app.post('/api/contacts/bulk-followup', (req, res) => {
    const { ids, action } = req.body;
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
        res.status(400).json({ error: 'No contact IDs provided' });
        return;
    }
    const placeholders = ids.map(() => '?').join(',');
    const value = action === 'unmark' ? 0 : 1;
    const lastContact = action === 'unmark' ? "datetime('now')" : "date('now', '-31 days')";
    db.run(`UPDATE contacts SET needs_follow_up = ${value}, last_contact = ${lastContact} WHERE id IN (${placeholders})`, ids, function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: `${this.changes} contacts updated` });
    });
});

// Bulk create task
app.post('/api/contacts/bulk-task', (req, res) => {
    const { ids, title, description, due_date, priority } = req.body;
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
        res.status(400).json({ error: 'No contact IDs provided' });
        return;
    }
    let created = 0;
    let errors = 0;
    ids.forEach(id => {
        db.run(`INSERT INTO tasks (contact_id, title, description, due_date, priority, status) VALUES (?, ?, ?, ?, ?, 'pending')`,
            [id, title, description || null, due_date || null, priority || 'medium'],
            (err) => {
                if (err) errors++;
                else created++;
                if (created + errors === ids.length) {
                    res.json({ message: `Task created for ${created} contacts` });
                }
            }
        );
    });
});

// ============ TASK ENDPOINTS ============

// Get all tasks
app.get('/api/tasks', (req, res) => {
    const sql = `
        SELECT t.*, c.name as contact_name 
        FROM tasks t
        LEFT JOIN contacts c ON t.contact_id = c.id
        ORDER BY t.due_date ASC, t.priority DESC
    `;
    
    db.all(sql, [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// Get single task
app.get('/api/tasks/:id', (req, res) => {
    db.get('SELECT * FROM tasks WHERE id = ?', [req.params.id], (err, row) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        if (!row) {
            res.status(404).json({ error: 'Task not found' });
            return;
        }
        res.json(row);
    });
});

// Create task
app.post('/api/tasks', (req, res) => {
    const { contact_id, title, description, due_date, priority } = req.body;
    
    const sql = `
        INSERT INTO tasks (contact_id, title, description, due_date, priority, status)
        VALUES (?, ?, ?, ?, ?, 'pending')
    `;
    
    db.run(sql, [contact_id, title, description, due_date, priority || 'medium'], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ id: this.lastID, message: 'Task created successfully' });
    });
});

// Update task
app.put('/api/tasks/:id', (req, res) => {
    const { title, description, due_date, priority, status } = req.body;
    
    const sql = `
        UPDATE tasks 
        SET title = ?, description = ?, due_date = ?, priority = ?, status = ?
        WHERE id = ?
    `;
    
    db.run(sql, [title, description, due_date, priority, status, req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Task updated successfully' });
    });
});

// Update task status
app.patch('/api/tasks/:id/status', (req, res) => {
    const { status } = req.body;
    
    db.run('UPDATE tasks SET status = ? WHERE id = ?', [status, req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Task status updated' });
    });
});

// Delete task
app.delete('/api/tasks/:id', (req, res) => {
    db.run('DELETE FROM tasks WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Task deleted successfully' });
    });
});

// ============ INTERACTION ENDPOINTS ============

// Add interaction
app.post('/api/interactions', (req, res) => {
    const { contact_id, type, notes } = req.body;
    
    const sql = `INSERT INTO interactions (contact_id, type, notes) VALUES (?, ?, ?)`;
    
    db.run(sql, [contact_id, type, notes], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        // Update last contact date
        db.run('UPDATE contacts SET last_contact = datetime("now") WHERE id = ?', [contact_id]);
        
        res.json({ id: this.lastID, message: 'Interaction logged successfully' });
    });
});

// Update interaction
app.put('/api/interactions/:id', (req, res) => {
    const { type, notes } = req.body;
    
    db.run('UPDATE interactions SET type = ?, notes = ? WHERE id = ?', 
        [type, notes, req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Interaction updated' });
    });
});

// Delete interaction
app.delete('/api/interactions/:id', (req, res) => {
    db.run('DELETE FROM interactions WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Interaction deleted' });
    });
});

// ============ NOTE ENDPOINTS ============

// Add note
app.post('/api/notes', (req, res) => {
    const { contact_id, content } = req.body;
    
    db.run('INSERT INTO notes (contact_id, content) VALUES (?, ?)', 
        [contact_id, content], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ id: this.lastID, message: 'Note added' });
    });
});

// Update note
app.put('/api/notes/:id', (req, res) => {
    const { content } = req.body;
    
    db.run('UPDATE notes SET content = ? WHERE id = ?', [content, req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Note updated' });
    });
});

// Delete note
app.delete('/api/notes/:id', (req, res) => {
    db.run('DELETE FROM notes WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Note deleted' });
    });
});

// ============ DOCUMENT ENDPOINTS ============

// Add document
app.post('/api/documents', (req, res) => {
    const { contact_id, title, url } = req.body;
    
    db.run('INSERT INTO documents (contact_id, title, url) VALUES (?, ?, ?)', 
        [contact_id, title, url], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ id: this.lastID, message: 'Document added' });
    });
});

// Update document
app.put('/api/documents/:id', (req, res) => {
    const { title, url } = req.body;
    
    db.run('UPDATE documents SET title = ?, url = ? WHERE id = ?', [title, url, req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Document updated' });
    });
});

// Delete document
app.delete('/api/documents/:id', (req, res) => {
    db.run('DELETE FROM documents WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Document deleted' });
    });
});

// ============ COMPANY ENDPOINTS ============

// Get all companies (for autocomplete)
app.get('/api/companies', (req, res) => {
    db.all('SELECT id, name FROM companies ORDER BY name', [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// ============ STATS ENDPOINT ============

app.get('/api/stats', (req, res) => {
    updateFollowUpFlags();
    
    const stats = {};
    
    // Count only active (non-archived) contacts
    db.get('SELECT COUNT(*) as count FROM contacts WHERE archived = 0 OR archived IS NULL', (err, row) => {
        stats.totalContacts = row.count;
        
        db.get('SELECT COUNT(*) as count FROM tasks WHERE status = "pending"', (err, row) => {
            stats.tasksDue = row.count;
            
            // Count only active contacts needing follow-up
            db.get('SELECT COUNT(*) as count FROM contacts WHERE needs_follow_up = 1 AND (archived = 0 OR archived IS NULL)', (err, row) => {
                stats.needsFollowUp = row.count;
                
                // Count archived contacts
                db.get('SELECT COUNT(*) as count FROM contacts WHERE archived = 1', (err, row) => {
                    stats.archivedContacts = row.count;
                    res.json(stats);
                });
            });
        });
    });
});

// ============ IMPORT/EXPORT ENDPOINTS ============

// Export contacts to CSV
app.get('/api/export/contacts', (req, res) => {
    db.all(`SELECT c.name, c.email, c.phone, COALESCE(co.name, c.company) as company, c.notes, c.tags FROM contacts c LEFT JOIN companies co ON c.company_id = co.id ORDER BY c.name`, [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        let csv = 'Name,Email,Phone,Company,Website,Notes,Tags\n';
        rows.forEach(row => {
            csv += `"${row.name || ''}","${row.email || ''}","${row.phone || ''}","${row.company || ''}","${row.website || ''}","${row.notes || ''}","${row.tags || ''}"\n`;
        });
        
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename=contacts.csv');
        res.send(csv);
    });
});

// Import contacts from CSV
app.post('/api/import/contacts', (req, res) => {
    const lines = req.body.split('\n').filter(l => l.trim());
    if (lines.length < 2) {
        return res.status(400).json({ error: 'CSV file is empty or has no data rows.' });
    }

    // Auto-detect delimiter: count semicolons vs commas in header line
    const headerLine = lines[0];
    const delimiter = (headerLine.split(';').length >= headerLine.split(',').length) ? ';' : ',';

    // Parse a single CSV row respecting quoted fields
    function parseRow(line, delim) {
        const result = [];
        let current = '';
        let inQuotes = false;
        for (let i = 0; i < line.length; i++) {
            const ch = line[i];
            if (ch === '"') {
                inQuotes = !inQuotes;
            } else if (ch === delim && !inQuotes) {
                result.push(current.trim());
                current = '';
            } else {
                current += ch;
            }
        }
        result.push(current.trim());
        return result;
    }

    const headers = parseRow(headerLine, delimiter).map(h => h.toLowerCase().trim());

    const nameIdx    = headers.indexOf('name');
    const emailIdx   = headers.indexOf('email');
    const phoneIdx   = headers.indexOf('phone');
    const companyIdx = headers.indexOf('company');
    const websiteIdx = headers.indexOf('website');
    const notesIdx   = headers.indexOf('notes');
    const tagsIdx    = headers.indexOf('tags');

    if (nameIdx === -1) {
        return res.status(400).json({
            error: `Could not find a "Name" column. Headers detected: [${headers.join(', ')}]. Delimiter used: "${delimiter === ';' ? 'semicolon' : 'comma'}".`
        });
    }

    // Collect valid rows, skip blanks and rows without a name
    const rows = [];
    const skipped = [];
    for (let i = 1; i < lines.length; i++) {
        const values = parseRow(lines[i], delimiter);
        // Strip invisible/control characters from each value
        const clean = values.map(v => v.replace(/[\u00AD\u200B-\u200D\uFEFF]/g, '').trim());
        const name = nameIdx >= 0 ? (clean[nameIdx] || '') : '';
        if (!name) {
            skipped.push(i + 1);
            continue;
        }
        const rawCompany = companyIdx >= 0 ? (clean[companyIdx] || '') : '';
        const isUrl = /^https?:\/\//i.test(rawCompany);
        rows.push({
            name,
            email:   emailIdx   >= 0 ? (clean[emailIdx]   || '') : '',
            phone:   phoneIdx   >= 0 ? (clean[phoneIdx]   || '') : '',
            company: isUrl ? '' : rawCompany,
            website: websiteIdx >= 0 ? (clean[websiteIdx] || '') : (isUrl ? rawCompany : ''),
            notes:   notesIdx   >= 0 ? (clean[notesIdx]   || '') : '',
            tags:    tagsIdx    >= 0 ? (clean[tagsIdx]    || '') : ''
        });
    }

    if (rows.length === 0) {
        return res.status(400).json({
            error: 'No importable rows found. Every row is either empty or missing a Name value.',
            skippedRows: skipped
        });
    }

    // Insert rows sequentially to keep accurate counters (no race condition)
    let imported = 0, failed = 0;
    const errors = [];

    function insertRow(index) {
        if (index >= rows.length) {
            // All done — respond
            return res.json({
                imported,
                failed,
                skippedRows: skipped.length,
                delimiter: delimiter === ';' ? 'semicolon' : 'comma',
                ...(errors.length > 0 && { errors })
            });
        }

        const row = rows[index];
        const companyName = row.company || null;

        const doInsert = (companyId) => {
            db.run(
                `INSERT INTO contacts (name, email, phone, company, company_id, website, notes, tags, last_contact)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))`,
                [row.name, row.email, row.phone, companyName, companyId, row.website || null, row.notes, row.tags],
                (err) => {
                    if (err) {
                        failed++;
                        errors.push({ name: row.name, reason: err.message });
                    } else {
                        imported++;
                    }
                    insertRow(index + 1);
                }
            );
        };

        if (companyName) {
            db.get('SELECT id FROM companies WHERE LOWER(name) = LOWER(?)', [companyName], (err, existing) => {
                if (existing) {
                    doInsert(existing.id);
                } else {
                    db.run('INSERT OR IGNORE INTO companies (name) VALUES (?)', [companyName], function(err) {
                        if (err || !this.lastID) {
                            // May have been inserted by a concurrent call — fetch it
                            db.get('SELECT id FROM companies WHERE LOWER(name) = LOWER(?)', [companyName], (err2, row2) => {
                                doInsert(row2 ? row2.id : null);
                            });
                        } else {
                            doInsert(this.lastID);
                        }
                    });
                }
            });
        } else {
            doInsert(null);
        }
    }

    insertRow(0);
});

// Export full backup
app.get('/api/export/backup', (req, res) => {
    const backup = { exportDate: new Date().toISOString() };
    
    db.all('SELECT * FROM contacts', (err, contacts) => {
        backup.contacts = contacts;
        db.all('SELECT * FROM tasks', (err, tasks) => {
            backup.tasks = tasks;
            db.all('SELECT * FROM interactions', (err, interactions) => {
                backup.interactions = interactions;
                db.all('SELECT * FROM notes', (err, notes) => {
                    backup.notes = notes;
                    db.all('SELECT * FROM documents', (err, documents) => {
                        backup.documents = documents;
                        
                        res.setHeader('Content-Type', 'application/json');
                        res.setHeader('Content-Disposition', 'attachment; filename=crm-backup.json');
                        res.send(JSON.stringify(backup, null, 2));
                    });
                });
            });
        });
    });
});

// Start server
const server = app.listen(PORT, HOST, () => {
    console.log(`
    🚀 easyCRM Server is running!
    
    Open your browser and navigate to:
    👉 http://localhost:${PORT}
    
    Version: 2.0.0
    
    Press Ctrl+C to stop the server
    `);
});

server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
        console.error(`\n❌ Port ${PORT} is already in use. Is easyCRM already running?\n   Close the other easyCRM window and try again.\n`);
    } else {
        console.error('Server error:', err);
    }
    process.exit(1);
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\nShutting down gracefully...');
    db.close(() => {
        console.log('Database connection closed.');
        process.exit(0);
    });
});
