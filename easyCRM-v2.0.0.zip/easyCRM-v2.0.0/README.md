# easyCRM — Simple, Private, Local CRM

**Version 2.0.0** · MIT licence · free to use, personally and commercially

easyCRM is a small contact manager that runs entirely on your own computer.
No cloud, no account, no subscription: your data is a single file (`crm.db`) in the easyCRM folder.

## What it does

- **Contacts** with email, phone, website, company and tags
- **Companies**: contacts are linked to a company; click a company to see its people
- **Tasks** per contact, with due dates (overdue / today / upcoming / completed)
- **Interaction log**: calls, emails, meetings
- **Notes thread** per contact
- **Document links** per contact (Google Docs, Drive, or any web link)
- **Follow-up flag** 🔔 and **archive** 📦 to keep the list clean
- **Bulk actions**: tag, archive, flag, add tasks or delete several contacts at once
- **Search and filter** by text, tag, follow-up and archived
- **Grid and table views**
- **CSV import / export** and a **full JSON backup**

## Installation

You need **Node.js**, the free engine easyCRM runs on. Install the **LTS** version (the one marked "Recommended") from <https://nodejs.org>.

### Windows

1. Install Node.js LTS from <https://nodejs.org>. Keep the default options.
2. Download easyCRM: on the GitHub page click **Code → Download ZIP**, or download the ZIP from **Releases**.
3. Right-click the ZIP → **Extract All…** and choose a folder, e.g. `Documents\easyCRM`.
4. Open the extracted folder and double-click **`install.bat`**.
   If Windows shows "Windows protected your PC", click **More info → Run anyway**.
5. When the installation finishes, answer `y` to start easyCRM. Your browser opens at <http://localhost:3000>.

**Every day after that:** double-click **`start-easyCRM.bat`**. Keep the black window open while you use easyCRM; close it to stop.

### macOS

1. Install Node.js LTS from <https://nodejs.org>.
2. Download and double-click the ZIP to extract it, e.g. into `Documents`.
3. Open **Terminal**, type `cd ` (with a space), drag the easyCRM folder onto the Terminal window, press Enter, then run:
   ```bash
   ./install.sh
   ```
4. **Every day after that:** double-click **`start-easyCRM.command`**.
   The first time, macOS may block it: right-click the file → **Open** → **Open**.

### Linux

```bash
cd easyCRM
./install.sh
./start.sh
```

## Your data

- Everything lives in **`crm.db`** inside the easyCRM folder. To back up, copy that file somewhere safe (or use **💾 Backup** in the app).
- easyCRM only listens on your own computer (`127.0.0.1`); other devices on your network cannot open it.
- To start again from empty: close easyCRM, then run `npm run reset` in the folder (it asks you to type `YES`).

### Upgrading from version 1.x

Copy your old `crm.db` into the new easyCRM folder **before** the first start. easyCRM adds the new columns and tables automatically; your contacts are kept. Make a backup copy of `crm.db` first.

### Importing contacts (CSV)

The first row must hold column names. Recognised columns: `Name`, `Email`, `Phone`, `Company`, `Website`, `Notes`, `Tags`. Only `Name` is required. Comma- or semicolon-separated files both work.

```
Name,Email,Phone,Company,Website,Notes,Tags
Jane Doe,jane@example.com,+44 20 1234 5678,ACME Ltd,https://acme.example,Met at expo,"client,vip"
```

## Troubleshooting

| Problem | What to do |
|---|---|
| "Node.js is not installed" | Install Node.js LTS from nodejs.org, then close and reopen the installer. |
| Installation fails with red `gyp` / `sqlite3` errors | Your Node.js is too new or too old for the database component. Uninstall it, install the **LTS** version, delete the `node_modules` folder and run the installer again. |
| "Port 3000 is already in use" | easyCRM is probably already running in another window. Close it and start again. |
| The page doesn't open by itself | Open <http://localhost:3000> in your browser. |
| Changes don't show after an upgrade | Hard-refresh the page: `Ctrl+F5` (Windows) or `Cmd+Shift+R` (Mac). |

## Known limitations

- Single user, no login: anyone who can use your computer can open easyCRM.
- Tags cannot contain a comma (commas separate tags).
- All contacts load at once; comfortable up to a few thousand.

## Credits

Created by **Antonio Specchia** — <https://easycrm.me>
Built with Node.js, Express, SQLite and plain JavaScript.

Bug reports and ideas: <https://github.com/antoniospecchia/easyCRM/issues>
