# Changelog

## 2.0.0 — October 2026

### New
- **Companies**: contacts linked to companies; click a company to filter.
- **Archive** contacts instead of deleting them; archived view.
- **Notes thread** per contact (multiple dated notes).
- **Document links** per contact (Google Docs / Drive or any URL).
- **Website** field on contacts.
- **Bulk actions**: archive, follow-up flag, add task, add/remove tags.
- CSV import auto-detects comma or semicolon separators and reads a `Website` column.

### Fixed
- Tags or company names containing an apostrophe (e.g. `O'Brien`) broke buttons; text can no longer be interpreted as code.
- Editing a note or interaction that contained a line break failed.
- Only web and email links are opened from website and document fields.
- Tag filter matched partial words (`lead` matched `leader`).
- Switching views or reloading dropped the active tag/search filter.

### Changed
- easyCRM now listens only on your own computer (127.0.0.1) and no longer accepts requests from other websites.
- New one-click installers and start files for Windows (`install.bat`, `start-easyCRM.bat`) and macOS/Linux (`install.sh`, `start.sh`, `start-easyCRM.command`).
- `npm run reset` works on Windows and asks for confirmation.
- The setup wizard was removed: the database is created automatically on first start.
- Requires Node.js 18 or newer (LTS recommended).

### Upgrading
Copy your existing `crm.db` into the new folder before the first start; it is migrated automatically.
