/**
 * CRM Server - Clean Working Version
 * Version: 4.0.0
 * Date: December 9, 2025
 */

const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.text({ type: 'text/csv', limit: '10mb' }));
app.use(express.static('public'));

// Initialize SQLite database
const db = new sqlite3.Database(path.join(__dirname, 'crm.db'), (err) => {
    if (err) {
        console.error('Error opening database:', err);
    } else {
        console.log('Connected to SQLite database');
        initializeDatabase();
    }
});

// Initialize database tables
function initializeDatabase() {
    db.serialize(() => {
        // Contacts table with needs_follow_up field
        db.run(`
            CREATE TABLE IF NOT EXISTS contacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT,
                phone TEXT,
                company TEXT,
                notes TEXT,
                tags TEXT,
                last_contact DATE,
                needs_follow_up INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Tasks table
        db.run(`
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                contact_id INTEGER,
                title TEXT NOT NULL,
                description TEXT,
                due_date DATE,
                priority TEXT DEFAULT 'medium',
                status TEXT DEFAULT 'pending',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
            )
        `);

        // Interactions table
        db.run(`
            CREATE TABLE IF NOT EXISTS interactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                contact_id INTEGER,
                type TEXT NOT NULL,
                notes TEXT,
                date DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
            )
        `);

        // Notes table
        db.run(`
            CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                contact_id INTEGER,
                content TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
            )
        `);

        console.log('Database tables initialized');
    });
}

// Update follow-up flags based on last contact date
function updateFollowUpFlags() {
    const sql = `
        UPDATE contacts 
        SET needs_follow_up = CASE 
            WHEN last_contact IS NULL OR date(last_contact) < date('now', '-30 days') THEN 1 
            ELSE 0 
        END
    `;
    db.run(sql);
}

// ============ CONTACT ENDPOINTS ============

// Get all contacts
app.get('/api/contacts', (req, res) => {
    updateFollowUpFlags(); // Update flags before returning
    
    const search = req.query.search || '';
    const tag = req.query.tag || '';
    
    let sql = `
        SELECT * FROM contacts 
        WHERE (name LIKE ? OR email LIKE ? OR company LIKE ? OR notes LIKE ?)
    `;
    const params = [`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`];
    
    if (tag) {
        sql += ` AND tags LIKE ?`;
        params.push(`%${tag}%`);
    }
    
    sql += ` ORDER BY created_at DESC`;
    
    db.all(sql, params, (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// Get single contact with all related data
app.get('/api/contacts/:id', (req, res) => {
    const contactId = req.params.id;
    const response = {};
    
    db.get('SELECT * FROM contacts WHERE id = ?', [contactId], (err, contact) => {
        if (err || !contact) {
            res.status(404).json({ error: 'Contact not found' });
            return;
        }
        response.contact = contact;
        
        db.all('SELECT * FROM tasks WHERE contact_id = ? ORDER BY due_date', [contactId], (err, tasks) => {
            response.tasks = tasks || [];
            
            db.all('SELECT * FROM interactions WHERE contact_id = ? ORDER BY date DESC', [contactId], (err, interactions) => {
                response.interactions = interactions || [];
                
                db.all('SELECT * FROM notes WHERE contact_id = ? ORDER BY created_at DESC', [contactId], (err, notes) => {
                    response.notes = notes || [];
                    res.json(response);
                });
            });
        });
    });
});

// Create contact
app.post('/api/contacts', (req, res) => {
    const { name, email, phone, company, notes, tags } = req.body;
    
    const sql = `
        INSERT INTO contacts (name, email, phone, company, notes, tags, last_contact)
        VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
    `;
    
    db.run(sql, [name, email, phone, company, notes, tags], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ id: this.lastID, message: 'Contact created successfully' });
    });
});

// Update contact
app.put('/api/contacts/:id', (req, res) => {
    const { name, email, phone, company, notes, tags } = req.body;
    const contactId = req.params.id;
    
    const sql = `
        UPDATE contacts 
        SET name = ?, email = ?, phone = ?, company = ?, notes = ?, tags = ?, 
            updated_at = datetime('now')
        WHERE id = ?
    `;
    
    db.run(sql, [name, email, phone, company, notes, tags, contactId], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Contact updated successfully' });
    });
});

// Delete contact
app.delete('/api/contacts/:id', (req, res) => {
    db.run('DELETE FROM contacts WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Contact deleted successfully' });
    });
});

// Mark contact for follow-up
app.post('/api/contacts/mark-followup/:id', (req, res) => {
    const sql = `UPDATE contacts SET needs_follow_up = 1, last_contact = date('now', '-31 days') WHERE id = ?`;
    
    db.run(sql, [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Contact marked for follow-up' });
    });
});

// Unmark contact follow-up
app.post('/api/contacts/unmark-followup/:id', (req, res) => {
    const sql = `UPDATE contacts SET needs_follow_up = 0, last_contact = datetime('now') WHERE id = ?`;
    
    db.run(sql, [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Follow-up removed' });
    });
});

// Bulk delete
app.post('/api/contacts/bulk-delete', (req, res) => {
    const { ids } = req.body;
    
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
        res.status(400).json({ error: 'No contact IDs provided' });
        return;
    }
    
    const placeholders = ids.map(() => '?').join(',');
    const sql = `DELETE FROM contacts WHERE id IN (${placeholders})`;
    
    db.run(sql, ids, function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: `${this.changes} contacts deleted successfully` });
    });
});

// Bulk update tags
app.post('/api/contacts/bulk-update-tags', (req, res) => {
    const { ids, tags, action } = req.body;
    
    if (!ids || !Array.isArray(ids)) {
        res.status(400).json({ error: 'No contact IDs provided' });
        return;
    }
    
    const placeholders = ids.map(() => '?').join(',');
    
    if (action === 'replace') {
        const sql = `UPDATE contacts SET tags = ? WHERE id IN (${placeholders})`;
        db.run(sql, [tags, ...ids], function(err) {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            res.json({ message: 'Tags updated' });
        });
    } else {
        res.json({ message: 'Add tags not implemented yet' });
    }
});

// ============ TASK ENDPOINTS ============

// Get all tasks
app.get('/api/tasks', (req, res) => {
    const sql = `
        SELECT t.*, c.name as contact_name 
        FROM tasks t
        LEFT JOIN contacts c ON t.contact_id = c.id
        ORDER BY t.due_date ASC, t.priority DESC
    `;
    
    db.all(sql, [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// Get single task
app.get('/api/tasks/:id', (req, res) => {
    db.get('SELECT * FROM tasks WHERE id = ?', [req.params.id], (err, row) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        if (!row) {
            res.status(404).json({ error: 'Task not found' });
            return;
        }
        res.json(row);
    });
});

// Create task
app.post('/api/tasks', (req, res) => {
    const { contact_id, title, description, due_date, priority } = req.body;
    
    const sql = `
        INSERT INTO tasks (contact_id, title, description, due_date, priority, status)
        VALUES (?, ?, ?, ?, ?, 'pending')
    `;
    
    db.run(sql, [contact_id, title, description, due_date, priority || 'medium'], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ id: this.lastID, message: 'Task created successfully' });
    });
});

// Update task
app.put('/api/tasks/:id', (req, res) => {
    const { title, description, due_date, priority, status } = req.body;
    
    const sql = `
        UPDATE tasks 
        SET title = ?, description = ?, due_date = ?, priority = ?, status = ?
        WHERE id = ?
    `;
    
    db.run(sql, [title, description, due_date, priority, status, req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Task updated successfully' });
    });
});

// Update task status
app.patch('/api/tasks/:id/status', (req, res) => {
    const { status } = req.body;
    
    db.run('UPDATE tasks SET status = ? WHERE id = ?', [status, req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Task status updated' });
    });
});

// Delete task
app.delete('/api/tasks/:id', (req, res) => {
    db.run('DELETE FROM tasks WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Task deleted successfully' });
    });
});

// ============ INTERACTION ENDPOINTS ============

// Add interaction
app.post('/api/interactions', (req, res) => {
    const { contact_id, type, notes } = req.body;
    
    const sql = `INSERT INTO interactions (contact_id, type, notes) VALUES (?, ?, ?)`;
    
    db.run(sql, [contact_id, type, notes], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        // Update last contact date
        db.run('UPDATE contacts SET last_contact = datetime("now") WHERE id = ?', [contact_id]);
        
        res.json({ id: this.lastID, message: 'Interaction logged successfully' });
    });
});

// Update interaction
app.put('/api/interactions/:id', (req, res) => {
    const { type, notes } = req.body;
    
    db.run('UPDATE interactions SET type = ?, notes = ? WHERE id = ?', 
        [type, notes, req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Interaction updated' });
    });
});

// Delete interaction
app.delete('/api/interactions/:id', (req, res) => {
    db.run('DELETE FROM interactions WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Interaction deleted' });
    });
});

// ============ NOTE ENDPOINTS ============

// Add note
app.post('/api/notes', (req, res) => {
    const { contact_id, content } = req.body;
    
    db.run('INSERT INTO notes (contact_id, content) VALUES (?, ?)', 
        [contact_id, content], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ id: this.lastID, message: 'Note added' });
    });
});

// Update note
app.put('/api/notes/:id', (req, res) => {
    const { content } = req.body;
    
    db.run('UPDATE notes SET content = ? WHERE id = ?', [content, req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Note updated' });
    });
});

// Delete note
app.delete('/api/notes/:id', (req, res) => {
    db.run('DELETE FROM notes WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ message: 'Note deleted' });
    });
});

// ============ STATS ENDPOINT ============

app.get('/api/stats', (req, res) => {
    updateFollowUpFlags();
    
    const stats = {};
    
    db.get('SELECT COUNT(*) as count FROM contacts', (err, row) => {
        stats.totalContacts = row.count;
        
        db.get('SELECT COUNT(*) as count FROM tasks WHERE status = "pending"', (err, row) => {
            stats.tasksDue = row.count;
            
            db.get('SELECT COUNT(*) as count FROM contacts WHERE needs_follow_up = 1', (err, row) => {
                stats.needsFollowUp = row.count;
                res.json(stats);
            });
        });
    });
});

// ============ IMPORT/EXPORT ENDPOINTS ============

// Export contacts to CSV
app.get('/api/export/contacts', (req, res) => {
    db.all(`SELECT name, email, phone, company, notes, tags FROM contacts ORDER BY name`, [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        let csv = 'Name,Email,Phone,Company,Notes,Tags\n';
        rows.forEach(row => {
            csv += `"${row.name || ''}","${row.email || ''}","${row.phone || ''}","${row.company || ''}","${row.notes || ''}","${row.tags || ''}"\n`;
        });
        
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename=contacts.csv');
        res.send(csv);
    });
});

// Import contacts from CSV
app.post('/api/import/contacts', (req, res) => {
    const lines = req.body.split('\n');
    const headers = lines[0].toLowerCase().split(',').map(h => h.trim());
    
    let imported = 0, failed = 0;
    
    for (let i = 1; i < lines.length; i++) {
        if (!lines[i].trim()) continue;
        
        const values = lines[i].match(/(".*?"|[^,]+)(?=\s*,|\s*$)/g) || [];
        const cleanValues = values.map(v => v.replace(/^"(.*)"$/, '$1').trim());
        
        const name = cleanValues[headers.indexOf('name')] || '';
        if (!name) continue;
        
        const email = cleanValues[headers.indexOf('email')] || '';
        const phone = cleanValues[headers.indexOf('phone')] || '';
        const company = cleanValues[headers.indexOf('company')] || '';
        const notes = cleanValues[headers.indexOf('notes')] || '';
        const tags = cleanValues[headers.indexOf('tags')] || '';
        
        db.run(`INSERT INTO contacts (name, email, phone, company, notes, tags, last_contact) 
                VALUES (?, ?, ?, ?, ?, ?, datetime('now'))`,
            [name, email, phone, company, notes, tags], 
            (err) => {
                if (err) failed++;
                else imported++;
            }
        );
    }
    
    setTimeout(() => {
        res.json({ imported, failed });
    }, 500);
});

// Export full backup
app.get('/api/export/backup', (req, res) => {
    const backup = { exportDate: new Date().toISOString() };
    
    db.all('SELECT * FROM contacts', (err, contacts) => {
        backup.contacts = contacts;
        db.all('SELECT * FROM tasks', (err, tasks) => {
            backup.tasks = tasks;
            db.all('SELECT * FROM interactions', (err, interactions) => {
                backup.interactions = interactions;
                db.all('SELECT * FROM notes', (err, notes) => {
                    backup.notes = notes;
                    
                    res.setHeader('Content-Type', 'application/json');
                    res.setHeader('Content-Disposition', 'attachment; filename=crm-backup.json');
                    res.send(JSON.stringify(backup, null, 2));
                });
            });
        });
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`
    🚀 CRM Server is running!
    
    Open your browser and navigate to:
    👉 http://localhost:${PORT}
    
    Version: 4.0.0 - Clean Rebuild
    
    Press Ctrl+C to stop the server
    `);
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\nShutting down gracefully...');
    db.close(() => {
        console.log('Database connection closed.');
        process.exit(0);
    });
});
