#!/usr/bin/env node

/**
 * easyCRM Setup Script
 * Creates initial database and optional demo data
 */

const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');
const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

console.log(`
╔═══════════════════════════════════════╗
║                                       ║
║         easyCRM Setup Wizard          ║
║     Simple • Private • Powerful       ║
║                                       ║
╚═══════════════════════════════════════╝
`);

// Check if database already exists
if (fs.existsSync('crm.db')) {
    console.log('⚠️  Database already exists!');
    rl.question('Do you want to reset it? This will DELETE all data! (y/N): ', (answer) => {
        if (answer.toLowerCase() === 'y') {
            fs.unlinkSync('crm.db');
            console.log('✅ Old database removed');
            setupDatabase();
        } else {
            console.log('Setup cancelled. Your data is safe.');
            process.exit(0);
        }
    });
} else {
    setupDatabase();
}

function setupDatabase() {
    const db = new sqlite3.Database('crm.db');

    console.log('📦 Creating database structure...');

    db.serialize(() => {
        // Create tables
        db.run(`
            CREATE TABLE contacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT,
                phone TEXT,
                company TEXT,
                notes TEXT,
                tags TEXT,
                last_contact DATE,
                needs_follow_up INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        db.run(`
            CREATE TABLE tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                contact_id INTEGER,
                title TEXT NOT NULL,
                description TEXT,
                due_date DATE,
                priority TEXT DEFAULT 'medium',
                status TEXT DEFAULT 'pending',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
            )
        `);

        db.run(`
            CREATE TABLE interactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                contact_id INTEGER,
                type TEXT NOT NULL,
                notes TEXT,
                date DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
            )
        `);

        db.run(`
            CREATE TABLE notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                contact_id INTEGER,
                content TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
            )
        `);

        console.log('✅ Database structure created');

        rl.question('\nWould you like to add demo data? (y/N): ', (answer) => {
            if (answer.toLowerCase() === 'y') {
                addDemoData(db);
            } else {
                finishSetup(db);
            }
        });
    });
}

function addDemoData(db) {
    console.log('\n📝 Adding demo contacts...');

    const demoContacts = [
        {
            name: 'Sarah Johnson',
            email: 'sarah.j@techstartup.com',
            phone: '+1-555-0101',
            company: 'TechStartup Inc',
            notes: 'Met at networking event. Interested in our services.',
            tags: 'prospect,tech',
            last_contact: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
        },
        {
            name: 'Mike Chen',
            email: 'mike@designstudio.co',
            phone: '+1-555-0102',
            company: 'Design Studio Co',
            notes: 'Current client. Monthly retainer.',
            tags: 'client,design',
            last_contact: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString()
        },
        {
            name: 'Emma Williams',
            email: 'emma.w@marketing.pro',
            phone: '+1-555-0103',
            company: 'Marketing Pro',
            notes: 'Referred by Mike. Schedule introduction call.',
            tags: 'prospect,referral',
            last_contact: new Date(Date.now() - 35 * 24 * 60 * 60 * 1000).toISOString()
        },
        {
            name: 'John Davis',
            email: 'john@localbusiness.com',
            phone: '+1-555-0104',
            company: 'Local Business Ltd',
            notes: 'Long-term client. Very satisfied with service.',
            tags: 'client,vip',
            last_contact: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
        },
        {
            name: 'Lisa Anderson',
            email: 'lisa@startup.io',
            phone: '+1-555-0105',
            company: 'Startup.io',
            notes: 'Potential partnership opportunity.',
            tags: 'partner,prospect',
            last_contact: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString()
        }
    ];

    let contactsAdded = 0;
    
    demoContacts.forEach((contact, index) => {
        const sql = `INSERT INTO contacts (name, email, phone, company, notes, tags, last_contact, needs_follow_up)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
        
        const needsFollowUp = new Date(contact.last_contact) < new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) ? 1 : 0;
        
        db.run(sql, [
            contact.name,
            contact.email,
            contact.phone,
            contact.company,
            contact.notes,
            contact.tags,
            contact.last_contact,
            needsFollowUp
        ], function(err) {
            if (!err) {
                contactsAdded++;
                
                // Add demo tasks for some contacts
                if (index === 0) {
                    db.run(`INSERT INTO tasks (contact_id, title, description, due_date, priority)
                            VALUES (?, 'Follow up on proposal', 'Check if they received our proposal', date('now', '+2 days'), 'high')`,
                            [this.lastID]);
                }
                
                if (index === 2) {
                    db.run(`INSERT INTO tasks (contact_id, title, description, due_date, priority)
                            VALUES (?, 'Schedule introduction call', 'Set up 30-min intro call', date('now', '+1 day'), 'medium')`,
                            [this.lastID]);
                }
                
                // Add demo interaction
                if (index === 1) {
                    db.run(`INSERT INTO interactions (contact_id, type, notes)
                            VALUES (?, 'email', 'Sent monthly report')`,
                            [this.lastID]);
                }
            }
        });
    });

    setTimeout(() => {
        console.log(`✅ Added ${contactsAdded} demo contacts`);
        console.log('✅ Added sample tasks and interactions');
        finishSetup(db);
    }, 1000);
}

function finishSetup(db) {
    // Create sample CSV file
    const sampleCSV = `Name,Email,Phone,Company,Notes,Tags
Alice Brown,alice@example.com,+1-555-0201,Example Corp,Sample contact,sample
Bob Smith,bob@demo.com,+1-555-0202,Demo Inc,Another sample,sample
Carol White,carol@test.com,+1-555-0203,Test LLC,Test contact,sample,test`;

    fs.writeFileSync('sample-import.csv', sampleCSV);
    console.log('\n✅ Created sample-import.csv for testing imports');

    db.close(() => {
        console.log(`
╔═══════════════════════════════════════╗
║                                       ║
║     🎉 Setup Complete!                ║
║                                       ║
║     Start easyCRM with:               ║
║     npm start                         ║
║                                       ║
║     Then open your browser to:        ║
║     http://localhost:3000             ║
║                                       ║
╚═══════════════════════════════════════╝

Thank you for choosing easyCRM!
Your data stays private, on YOUR computer.
        `);
        rl.close();
        process.exit(0);
    });
}

process.on('SIGINT', () => {
    console.log('\n\nSetup cancelled.');
    process.exit(0);
});
