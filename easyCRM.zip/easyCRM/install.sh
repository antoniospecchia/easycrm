#!/bin/bash

# easyCRM Installation Script
# For macOS and Linux

echo "
╔═══════════════════════════════════════╗
║                                       ║
║      easyCRM Installation             ║
║   Simple • Private • Powerful         ║
║                                       ║
╚═══════════════════════════════════════╝
"

# Check for Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed!"
    echo "Please install Node.js from https://nodejs.org"
    exit 1
fi

echo "✅ Node.js detected: $(node -v)"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies"
    exit 1
fi

# Run setup
echo ""
echo "🔧 Running setup wizard..."
npm run setup

# Success message
echo ""
echo "╔═══════════════════════════════════════╗"
echo "║                                       ║"
echo "║   ✅ Installation Complete!           ║"
echo "║                                       ║"
echo "║   Start easyCRM with:                 ║"
echo "║   npm start                           ║"
echo "║                                       ║"
echo "║   Then open:                          ║"
echo "║   http://localhost:3000               ║"
echo "║                                       ║"
echo "╚═══════════════════════════════════════╝"
echo ""
echo "Would you like to start easyCRM now? (y/n)"
read -r response

if [[ "$response" =~ ^[Yy]$ ]]; then
    npm start
fi
