/**
 * CRM Frontend - Version 5.0
 * Complete rewrite with all fixes integrated
 * Date: December 9, 2025
 */

const API_URL = 'http://localhost:3000/api';

// Global state
let currentContacts = [];
let currentContactId = null;
let currentView = 'grid';
let selectedContacts = new Set();
let followUpOnly = false;

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    loadStats();
    loadContacts();
    
    // Refresh stats every 30 seconds
    setInterval(loadStats, 30000);
});

// Load dashboard statistics
async function loadStats() {
    try {
        const response = await fetch(`${API_URL}/stats`);
        const stats = await response.json();
        
        document.getElementById('stat-contacts').textContent = stats.totalContacts || 0;
        document.getElementById('stat-tasks').textContent = stats.tasksDue || 0;
        document.getElementById('stat-followup').textContent = stats.needsFollowUp || 0;
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// Load contacts
async function loadContacts() {
    try {
        const response = await fetch(`${API_URL}/contacts`);
        const contacts = await response.json();
        currentContacts = contacts;
        
        // Apply follow-up filter if active
        if (followUpOnly) {
            const filtered = contacts.filter(c => c.needs_follow_up === 1);
            displayContacts(filtered);
        } else {
            displayContacts(contacts);
        }
        
        populateTagFilter(contacts);
    } catch (error) {
        console.error('Error loading contacts:', error);
        showNotification('Error loading contacts', 'error');
    }
}

// Display contacts based on current view
function displayContacts(contacts) {
    const container = document.getElementById('contacts-container');
    
    if (currentView === 'table') {
        container.className = '';
        displayTable(contacts);
    } else {
        container.className = 'grid-view';
        displayGrid(contacts);
    }
}

// Display contacts in grid view - FIXED
function displayGrid(contacts) {
    const container = document.getElementById('contacts-container');
    
    if (!contacts || contacts.length === 0) {
        container.innerHTML = '<div class="empty-state">No contacts found</div>';
        return;
    }
    
    container.innerHTML = contacts.map(contact => {
        const needsFollowUp = contact.needs_follow_up === 1;
        
        return `
            <div class="contact-card ${needsFollowUp ? 'needs-followup' : ''}" onclick="showContactDetail(${contact.id})">
                <input type="checkbox" class="contact-checkbox" 
                    data-id="${contact.id}"
                    ${selectedContacts.has(contact.id) ? 'checked' : ''}
                    onclick="event.stopPropagation(); toggleSelection(${contact.id})">
                <h3>${escapeHtml(contact.name)}</h3>
                ${contact.email ? `<p>📧 <a href="mailto:${contact.email}" onclick="event.stopPropagation()">${escapeHtml(contact.email)}</a></p>` : ''}
                ${contact.phone ? `<p>📱 <a href="tel:${contact.phone}" onclick="event.stopPropagation()">${escapeHtml(contact.phone)}</a></p>` : ''}
                ${contact.company ? `<p>🏢 ${escapeHtml(contact.company)}</p>` : ''}
                <p>📅 Last: ${contact.last_contact ? new Date(contact.last_contact).toLocaleDateString() : 'Never'}</p>
                <div class="card-actions" onclick="event.stopPropagation()">
                    <button onclick="openEditModal(${contact.id})" class="btn-small">✏️</button>
                    <button onclick="quickAddTask(${contact.id})" class="btn-small">✅</button>
                    <button onclick="toggleFollowUp(${contact.id})" class="btn-small">${needsFollowUp ? '🔕' : '🔔'}</button>
                    <button onclick="deleteContact(${contact.id})" class="btn-small btn-danger">🗑️</button>
                </div>
            </div>
        `;
    }).join('');
}

// Display contacts in table view - FIXED
function displayTable(contacts) {
    const container = document.getElementById('contacts-container');
    
    if (!contacts || contacts.length === 0) {
        container.innerHTML = '<div class="empty-state">No contacts found</div>';
        return;
    }
    
    let html = `
        <table class="contacts-table">
            <thead>
                <tr>
                    <th><input type="checkbox" onclick="selectAll(this)"></th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Company</th>
                    <th>Last Interaction</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
    `;
    
    contacts.forEach(contact => {
        const needsFollowUp = contact.needs_follow_up === 1;
        const nameStyle = needsFollowUp ? 'color: #ffa436; font-weight: bold;' : '';
        
        html += `
            <tr onclick="showContactDetail(${contact.id})" style="cursor:pointer;" class="${needsFollowUp ? 'needs-followup' : ''}">
                <td onclick="event.stopPropagation()">
                    <input type="checkbox" class="contact-checkbox" 
                        data-id="${contact.id}"
                        ${selectedContacts.has(contact.id) ? 'checked' : ''}
                        onclick="toggleSelection(${contact.id})">
                </td>
                <td style="${nameStyle}">${escapeHtml(contact.name)}</td>
                <td>${contact.email ? `<a href="mailto:${escapeHtml(contact.email)}" onclick="event.stopPropagation()">${escapeHtml(contact.email)}</a>` : ''}</td>
                <td>${escapeHtml(contact.company) || ''}</td>
                <td>${contact.last_contact ? new Date(contact.last_contact).toLocaleDateString() : 'Never'}</td>
                <td onclick="event.stopPropagation()">
                    <button onclick="openEditModal(${contact.id})" class="btn-small">✏️</button>
                    <button onclick="quickAddTask(${contact.id})" class="btn-small">✅</button>
                    <button onclick="toggleFollowUp(${contact.id})" class="btn-small">${needsFollowUp ? '🔕' : '🔔'}</button>
                    <button onclick="deleteContact(${contact.id})" class="btn-small btn-danger">🗑️</button>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// Switch view between grid and table
function switchView(view) {
    currentView = view;
    
    // Update button states
    document.getElementById('btn-grid').classList.toggle('active', view === 'grid');
    document.getElementById('btn-table').classList.toggle('active', view === 'table');
    
    // Re-display contacts
    if (followUpOnly) {
        const filtered = currentContacts.filter(c => c.needs_follow_up === 1);
        displayContacts(filtered);
    } else {
        displayContacts(currentContacts);
    }
}

// Show all contacts (from stat box)
function showAllContacts() {
    followUpOnly = false;
    document.getElementById('main-view').style.display = 'block';
    document.getElementById('tasks-view').style.display = 'none';
    loadContacts();
}

// Show only follow-up contacts (from stat box)
function showFollowUpContacts() {
    followUpOnly = true;
    document.getElementById('main-view').style.display = 'block';
    document.getElementById('tasks-view').style.display = 'none';
    
    const filtered = currentContacts.filter(c => c.needs_follow_up === 1);
    displayContacts(filtered);
    showNotification(`Showing ${filtered.length} contacts needing follow-up`, 'info');
}

// Show tasks view (from stat box)
function showTasksView() {
    document.getElementById('main-view').style.display = 'none';
    document.getElementById('tasks-view').style.display = 'block';
    loadTasks();
}

// Load and display tasks
async function loadTasks() {
    try {
        const response = await fetch(`${API_URL}/tasks`);
        const tasks = await response.json();
        
        const container = document.getElementById('tasks-container');
        
        if (tasks.length === 0) {
            container.innerHTML = '<div class="empty-state">No tasks found</div>';
            return;
        }
        
        // Group tasks
        const overdue = tasks.filter(t => t.due_date && new Date(t.due_date) < new Date() && t.status === 'pending');
        const today = tasks.filter(t => {
            if (!t.due_date || t.status !== 'pending') return false;
            const d = new Date(t.due_date).toDateString();
            return d === new Date().toDateString();
        });
        const upcoming = tasks.filter(t => {
            if (!t.due_date || t.status !== 'pending') return false;
            return new Date(t.due_date) > new Date() && new Date(t.due_date).toDateString() !== new Date().toDateString();
        });
        const completed = tasks.filter(t => t.status === 'completed');
        
        let html = '';
        
        if (overdue.length > 0) {
            html += '<h3 style="color: #d70022;">⚠️ Overdue</h3>';
            html += overdue.map(t => renderTask(t)).join('');
        }
        
        if (today.length > 0) {
            html += '<h3 style="color: #0060df;">📅 Today</h3>';
            html += today.map(t => renderTask(t)).join('');
        }
        
        if (upcoming.length > 0) {
            html += '<h3>📌 Upcoming</h3>';
            html += upcoming.map(t => renderTask(t)).join('');
        }
        
        if (completed.length > 0) {
            html += '<h3 style="color: #058b00;">✅ Completed</h3>';
            html += completed.map(t => renderTask(t)).join('');
        }
        
        container.innerHTML = html;
    } catch (error) {
        console.error('Error loading tasks:', error);
    }
}

// Render single task
function renderTask(task) {
    return `
        <div class="task-item" onclick="showContactFromTask(${task.contact_id})">
            <strong>${escapeHtml(task.title)}</strong>
            ${task.contact_name ? ` - ${escapeHtml(task.contact_name)}` : ''}
            <br>
            <small>${task.due_date ? `Due: ${new Date(task.due_date).toLocaleDateString()}` : 'No due date'}</small>
            <div class="task-actions" onclick="event.stopPropagation()">
                <button onclick="openEditTaskModal(${task.id})" class="btn-small">✏️</button>
                ${task.status === 'pending' 
                    ? `<button onclick="completeTask(${task.id})" class="btn-small">✔️</button>`
                    : `<button onclick="reopenTask(${task.id})" class="btn-small">↩️</button>`
                }
                <button onclick="deleteTask(${task.id})" class="btn-small btn-danger">🗑️</button>
            </div>
        </div>
    `;
}

// Show contact from task
async function showContactFromTask(contactId) {
    if (!contactId) return;
    showAllContacts();
    setTimeout(() => showContactDetail(contactId), 100);
}

// Show contact detail modal
async function showContactDetail(contactId) {
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}`);
        const data = await response.json();
        
        currentContactId = contactId;
        
        document.getElementById('detail-name').textContent = data.contact.name;
        document.getElementById('detail-email').innerHTML = data.contact.email 
            ? `<a href="mailto:${data.contact.email}">${data.contact.email}</a>` 
            : 'N/A';
        document.getElementById('detail-phone').innerHTML = data.contact.phone 
            ? `<a href="tel:${data.contact.phone}">${data.contact.phone}</a>` 
            : 'N/A';
        document.getElementById('detail-company').textContent = data.contact.company || 'N/A';
        document.getElementById('detail-notes').textContent = data.contact.notes || 'N/A';
        
        // Display tasks
        const tasksHtml = data.tasks.length > 0 ? data.tasks.map(t => `
            <div class="detail-item">
                <strong>${escapeHtml(t.title)}</strong> - ${t.status}
                <div class="detail-item-actions">
                    <button onclick="openEditTaskModal(${t.id})" class="btn-small">✏️</button>
                </div>
            </div>
        `).join('') : '<p>No tasks</p>';
        document.getElementById('detail-tasks').innerHTML = tasksHtml;
        
        // Display interactions
        const interactionsHtml = data.interactions.length > 0 ? data.interactions.map(i => `
            <div class="detail-item">
                <strong>${i.type}</strong> - ${new Date(i.date).toLocaleDateString()}
                ${i.notes ? `<br>${escapeHtml(i.notes)}` : ''}
                <div class="detail-item-actions">
                    <button onclick="editInteraction(${i.id}, '${i.type}', '${escapeHtml(i.notes || '')}')" class="btn-small">✏️</button>
                    <button onclick="deleteInteraction(${i.id})" class="btn-small btn-danger">🗑️</button>
                </div>
            </div>
        `).join('') : '<p>No interactions</p>';
        document.getElementById('detail-interactions').innerHTML = interactionsHtml;
        
        // Display notes
        const notesHtml = data.notes.length > 0 ? data.notes.map(n => `
            <div class="detail-item">
                ${escapeHtml(n.content)}
                <div class="detail-item-actions">
                    <button onclick="editNote(${n.id}, '${escapeHtml(n.content)}')" class="btn-small">✏️</button>
                    <button onclick="deleteNote(${n.id})" class="btn-small btn-danger">🗑️</button>
                </div>
            </div>
        `).join('') : '<p>No notes</p>';
        document.getElementById('detail-notes').innerHTML = notesHtml;
        
        openModal('contact-detail-modal');
    } catch (error) {
        console.error('Error loading contact:', error);
        showNotification('Error loading contact details', 'error');
    }
}

// FIXED: Open edit contact modal (closes detail modal first)
async function openEditModal(contactId) {
    // Close contact detail modal if it's open
    closeModal('contact-detail-modal');
    
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}`);
        const data = await response.json();
        const contact = data.contact;
        
        document.getElementById('edit-id').value = contact.id;
        document.getElementById('edit-name').value = contact.name;
        document.getElementById('edit-email').value = contact.email || '';
        document.getElementById('edit-phone').value = contact.phone || '';
        document.getElementById('edit-company').value = contact.company || '';
        document.getElementById('edit-tags').value = contact.tags || '';
        document.getElementById('edit-notes').value = contact.notes || '';
        
        openModal('edit-contact-modal');
    } catch (error) {
        console.error('Error loading contact:', error);
        showNotification('Error loading contact', 'error');
    }
}

// FIXED: Save edited contact (and reopen detail if needed)
async function saveContact() {
    const contactId = document.getElementById('edit-id').value;
    const wasDetailOpen = currentContactId == contactId;
    
    const data = {
        name: document.getElementById('edit-name').value,
        email: document.getElementById('edit-email').value,
        phone: document.getElementById('edit-phone').value,
        company: document.getElementById('edit-company').value,
        tags: document.getElementById('edit-tags').value,
        notes: document.getElementById('edit-notes').value
    };
    
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            showNotification('Contact updated successfully', 'success');
            closeModal('edit-contact-modal');
            loadContacts();
            loadStats();
            
            // Reopen contact detail if it was open
            if (wasDetailOpen) {
                setTimeout(() => showContactDetail(contactId), 300);
            }
        }
    } catch (error) {
        showNotification('Error updating contact', 'error');
    }
}

// Add new contact
async function addContact(event) {
    event.preventDefault();
    
    const data = {
        name: document.getElementById('add-name').value,
        email: document.getElementById('add-email').value,
        phone: document.getElementById('add-phone').value,
        company: document.getElementById('add-company').value,
        tags: document.getElementById('add-tags').value,
        notes: document.getElementById('add-notes').value
    };
    
    try {
        const response = await fetch(`${API_URL}/contacts`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            showNotification('Contact added successfully', 'success');
            document.getElementById('add-contact-form').reset();
            closeModal('add-contact-modal');
            loadContacts();
            loadStats();
        }
    } catch (error) {
        showNotification('Error adding contact', 'error');
    }
}

// Delete contact
async function deleteContact(contactId) {
    if (!confirm('Delete this contact and all related data?')) return;
    
    try {
        const response = await fetch(`${API_URL}/contacts/${contactId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('Contact deleted', 'success');
            loadContacts();
            loadStats();
        }
    } catch (error) {
        showNotification('Error deleting contact', 'error');
    }
}

// Toggle follow-up status
async function toggleFollowUp(contactId) {
    const contact = currentContacts.find(c => c.id === contactId);
    const endpoint = contact?.needs_follow_up === 1 
        ? `/contacts/unmark-followup/${contactId}`
        : `/contacts/mark-followup/${contactId}`;
    
    try {
        const response = await fetch(`${API_URL}${endpoint}`, {
            method: 'POST'
        });
        
        if (response.ok) {
            showNotification(contact?.needs_follow_up === 1 ? 'Follow-up removed' : 'Marked for follow-up', 'success');
            loadContacts();
            loadStats();
        }
    } catch (error) {
        showNotification('Error updating follow-up status', 'error');
    }
}

// Quick add task
async function quickAddTask(contactId) {
    const title = prompt('Task title:');
    if (!title) return;
    
    const description = prompt('Description (optional):');
    const dueDate = prompt('Due date (YYYY-MM-DD, optional):');
    
    try {
        const response = await fetch(`${API_URL}/tasks`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contact_id: contactId,
                title: title,
                description: description || '',
                due_date: dueDate || null,
                priority: 'medium'
            })
        });
        
        if (response.ok) {
            showNotification('Task added', 'success');
            loadStats();
        }
    } catch (error) {
        showNotification('Error adding task', 'error');
    }
}

// Open add task modal
function openAddTaskModal(contactId = null) {
    if (contactId) {
        document.getElementById('task-contact-id').value = contactId;
    }
    openModal('add-task-modal');
}

// Save new task
async function saveTask(event) {
    event.preventDefault();
    
    const data = {
        contact_id: document.getElementById('task-contact-id').value || currentContactId,
        title: document.getElementById('task-title').value,
        description: document.getElementById('task-description').value,
        due_date: document.getElementById('task-due-date').value || null,
        priority: document.getElementById('task-priority').value
    };
    
    try {
        const response = await fetch(`${API_URL}/tasks`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            showNotification('Task added successfully', 'success');
            document.getElementById('add-task-form').reset();
            closeModal('add-task-modal');
            loadStats();
            if (currentContactId) {
                showContactDetail(currentContactId);
            }
        }
    } catch (error) {
        showNotification('Error adding task', 'error');
    }
}

// Open edit task modal
async function openEditTaskModal(taskId) {
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}`);
        const task = await response.json();
        
        document.getElementById('edit-task-id').value = task.id;
        document.getElementById('edit-task-title').value = task.title;
        document.getElementById('edit-task-description').value = task.description || '';
        document.getElementById('edit-task-due-date').value = task.due_date ? task.due_date.split('T')[0] : '';
        document.getElementById('edit-task-priority').value = task.priority;
        document.getElementById('edit-task-status').value = task.status;
        
        openModal('edit-task-modal');
    } catch (error) {
        showNotification('Error loading task', 'error');
    }
}

// Save edited task
async function saveEditedTask(event) {
    event.preventDefault();
    
    const taskId = document.getElementById('edit-task-id').value;
    const data = {
        title: document.getElementById('edit-task-title').value,
        description: document.getElementById('edit-task-description').value,
        due_date: document.getElementById('edit-task-due-date').value || null,
        priority: document.getElementById('edit-task-priority').value,
        status: document.getElementById('edit-task-status').value
    };
    
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            showNotification('Task updated', 'success');
            closeModal('edit-task-modal');
            loadTasks();
            loadStats();
            if (currentContactId) {
                showContactDetail(currentContactId);
            }
        }
    } catch (error) {
        showNotification('Error updating task', 'error');
    }
}

// Complete task
async function completeTask(taskId) {
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}/status`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: 'completed' })
        });
        
        if (response.ok) {
            showNotification('Task completed', 'success');
            loadTasks();
            loadStats();
        }
    } catch (error) {
        showNotification('Error completing task', 'error');
    }
}

// Reopen task
async function reopenTask(taskId) {
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}/status`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: 'pending' })
        });
        
        if (response.ok) {
            showNotification('Task reopened', 'success');
            loadTasks();
            loadStats();
        }
    } catch (error) {
        showNotification('Error reopening task', 'error');
    }
}

// Delete task
async function deleteTask(taskId) {
    if (!confirm('Delete this task?')) return;
    
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('Task deleted', 'success');
            loadTasks();
            loadStats();
        }
    } catch (error) {
        showNotification('Error deleting task', 'error');
    }
}

// Edit interaction
async function editInteraction(id, type, notes) {
    const newType = prompt('Type:', type);
    const newNotes = prompt('Notes:', notes.replace(/\\'/g, "'"));
    
    if (newType === null) return;
    
    try {
        const response = await fetch(`${API_URL}/interactions/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type: newType, notes: newNotes })
        });
        
        if (response.ok) {
            showNotification('Interaction updated', 'success');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error updating interaction', 'error');
    }
}

// Delete interaction
async function deleteInteraction(id) {
    if (!confirm('Delete this interaction?')) return;
    
    try {
        const response = await fetch(`${API_URL}/interactions/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('Interaction deleted', 'success');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error deleting interaction', 'error');
    }
}

// Edit note
async function editNote(id, content) {
    const newContent = prompt('Edit note:', content.replace(/\\'/g, "'"));
    
    if (newContent === null) return;
    
    try {
        const response = await fetch(`${API_URL}/notes/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content: newContent })
        });
        
        if (response.ok) {
            showNotification('Note updated', 'success');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error updating note', 'error');
    }
}

// Delete note
async function deleteNote(id) {
    if (!confirm('Delete this note?')) return;
    
    try {
        const response = await fetch(`${API_URL}/notes/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('Note deleted', 'success');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error deleting note', 'error');
    }
}

// Log interaction
async function logInteraction() {
    const type = document.getElementById('log-type').value;
    const notes = document.getElementById('log-notes').value;
    
    try {
        const response = await fetch(`${API_URL}/interactions`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contact_id: currentContactId,
                type: type,
                notes: notes
            })
        });
        
        if (response.ok) {
            showNotification('Interaction logged', 'success');
            document.getElementById('log-type').value = 'call';
            document.getElementById('log-notes').value = '';
            closeModal('log-interaction-modal');
            showContactDetail(currentContactId);
            loadContacts();
        }
    } catch (error) {
        showNotification('Error logging interaction', 'error');
    }
}

// Add note
async function addNote() {
    const content = document.getElementById('add-note-content').value;
    
    if (!content) return;
    
    try {
        const response = await fetch(`${API_URL}/notes`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contact_id: currentContactId,
                content: content
            })
        });
        
        if (response.ok) {
            showNotification('Note added', 'success');
            document.getElementById('add-note-content').value = '';
            closeModal('add-note-modal');
            showContactDetail(currentContactId);
        }
    } catch (error) {
        showNotification('Error adding note', 'error');
    }
}

// Toggle selection for bulk operations
function toggleSelection(contactId) {
    if (selectedContacts.has(contactId)) {
        selectedContacts.delete(contactId);
    } else {
        selectedContacts.add(contactId);
    }
    updateBulkBar();
}

// Select all contacts
function selectAll(checkbox) {
    if (checkbox.checked) {
        currentContacts.forEach(c => selectedContacts.add(c.id));
    } else {
        selectedContacts.clear();
    }
    
    document.querySelectorAll('.contact-checkbox').forEach(cb => {
        cb.checked = checkbox.checked;
    });
    
    updateBulkBar();
}

// Update bulk actions bar
function updateBulkBar() {
    const bar = document.getElementById('bulk-actions');
    if (selectedContacts.size > 0) {
        bar.style.display = 'flex';
        document.getElementById('selected-count').textContent = selectedContacts.size;
    } else {
        bar.style.display = 'none';
    }
}

// Bulk delete
async function bulkDelete() {
    if (!confirm(`Delete ${selectedContacts.size} contacts?`)) return;
    
    try {
        const response = await fetch(`${API_URL}/contacts/bulk-delete`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids: Array.from(selectedContacts) })
        });
        
        if (response.ok) {
            showNotification(`${selectedContacts.size} contacts deleted`, 'success');
            selectedContacts.clear();
            updateBulkBar();
            loadContacts();
            loadStats();
        }
    } catch (error) {
        showNotification('Error deleting contacts', 'error');
    }
}

// Clear selection and reload
function clearSelectionAndReload() {
    selectedContacts.clear();
    updateBulkBar();
    loadContacts();
}

// Search and filter
function searchContacts() {
    const searchTerm = document.getElementById('search-input').value.toLowerCase();
    const tagFilter = document.getElementById('tag-filter').value;
    
    let filtered = currentContacts.filter(contact => {
        const matchesSearch = !searchTerm || 
            contact.name.toLowerCase().includes(searchTerm) ||
            (contact.email && contact.email.toLowerCase().includes(searchTerm)) ||
            (contact.company && contact.company.toLowerCase().includes(searchTerm));
        
        const matchesTag = !tagFilter || 
            (contact.tags && contact.tags.includes(tagFilter));
        
        const matchesFollowUp = !followUpOnly || contact.needs_follow_up === 1;
        
        return matchesSearch && matchesTag && matchesFollowUp;
    });
    
    displayContacts(filtered);
}

// Populate tag filter
function populateTagFilter(contacts) {
    const tags = new Set();
    contacts.forEach(c => {
        if (c.tags) {
            c.tags.split(',').forEach(t => tags.add(t.trim()));
        }
    });
    
    const select = document.getElementById('tag-filter');
    const current = select.value;
    select.innerHTML = '<option value="">All Tags</option>';
    
    Array.from(tags).sort().forEach(tag => {
        const option = document.createElement('option');
        option.value = tag;
        option.textContent = tag;
        if (tag === current) option.selected = true;
        select.appendChild(option);
    });
}

// Export contacts
function exportContacts() {
    window.location.href = `${API_URL}/export/contacts`;
}

// Export backup
function exportBackup() {
    window.location.href = `${API_URL}/export/backup`;
}

// Import CSV
async function importCSV() {
    const fileInput = document.getElementById('import-file');
    const file = fileInput.files[0];
    
    if (!file) {
        showNotification('Please select a file', 'warning');
        return;
    }
    
    const text = await file.text();
    
    try {
        const response = await fetch(`${API_URL}/import/contacts`, {
            method: 'POST',
            headers: { 'Content-Type': 'text/csv' },
            body: text
        });
        
        const result = await response.json();
        showNotification(`Imported ${result.imported} contacts`, 'success');
        fileInput.value = '';
        closeModal('import-modal');
        loadContacts();
        loadStats();
    } catch (error) {
        showNotification('Import failed', 'error');
    }
}

// FIXED: Modal functions with proper centering
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.add('show');
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('show');
}

// Close modal on outside click
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.classList.remove('show');
    }
}

// Show notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Escape HTML
function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.toString().replace(/[&<>"']/g, m => map[m]);
}
